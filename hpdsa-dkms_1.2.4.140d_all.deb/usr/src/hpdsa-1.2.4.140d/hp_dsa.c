/*
 *    Disk Array driver for HP SA Controllers
 *    Copyright 2014-2015 PMC-Sierra, Inc.
 *    Portions Copyright 2008-2014 Hewlett-Packard Development Company, L.P.
 *
 *
 *    HP End User License Agreement – Enterprise Version (the "Agreement")
 *    governs the use of accompanying software, unless it is subject to a
 *    separate agreement between you and Hewlett-Packard Company and its
 *    subsidiaries ("HP").
 *
 *    Please refer to the terms and conditions of this software in the
 *    separate "EULA.txt" file, which governs the use of this software.
 *
 *    By downloading, copying, or using the software you agree to
 *    this Agreement.
 *
 *    Questions/Comments/Bugfixes to iss_storagedev@hp.com
 *
 */

#include <linux/module.h>
#include <linux/interrupt.h>
#include <linux/pci.h>
#include <linux/pm.h>
#include <linux/miscdevice.h>
#include <linux/proc_fs.h>
#include <linux/blkdev.h>
#include <linux/dma-mapping.h>
#include <linux/slab.h>
#include <linux/efi.h>

#if !defined(SLES10)
#include <linux/uaccess.h>
#endif

#include <scsi/scsi.h>
#include <scsi/scsi_cmnd.h>
#include <scsi/scsi_device.h>
#include <scsi/scsi_host.h>
#include <scsi/scsi_ioctl.h>

#if !defined(SLES10)
#include <linux/irqreturn.h>
#endif

#include "hpdsa_cciss_ioctl.h"
#include "hpdsa.h"
#include "hpdsa_cmd.h"
#include "hpdsa_kernel_compat.h"

/* Embedded module documentation macros - see modules.h */
MODULE_AUTHOR("Hewlett-Packard Company");
MODULE_DESCRIPTION("HP raidstack firmware version " HPVSA_DRIVER_VERSION " (d40/s175/r1678)");
MODULE_SUPPORTED_DEVICE("HP raidstack devices");
MODULE_VERSION(HPVSA_DRIVER_VERSION);
MODULE_LICENSE("HP");

/*
 * spanning device
 */
static DEFINE_PCI_DEVICE_TABLE(hpdsa_ctlr_pci_device_id) = {
	{0x103c, 0x193f, 0x103c, 0x3381}, /* B140i */
	{0,}
};

/*
 * ahci devices
 */
static DEFINE_PCI_DEVICE_TABLE(hpdsa_ahci_pci_device_id) = {
	{0x8086, 0xa107, 0x1590, 0x00c0}, /* 8 port */
	{0x8086, 0xa106, 0x1590, 0x00c0}, /* 8 port */
	{0x8086, 0x8d06, 0x1590, 0x009c}, /* 6 port */
	{0x8086, 0x8d66, 0x1590, 0x009d}, /* 4 port */
	{0,}
};

/*
 * someday a cache device
 */
static DEFINE_PCI_DEVICE_TABLE(hpdsa_cache_pci_device_id) = {
	{0x1590, 0x005f, 0x1590, 0x005f},
	{0,}
};

MODULE_DEVICE_TABLE(pci, hpdsa_ctlr_pci_device_id);

void interrupt_control(int flag, int msix_vector);

#ifndef U8
#	define U8        unsigned char
#	define U16       unsigned short int
#	ifdef SW_RAID
#		define U32      unsigned int
#	else
#		define U32      unsigned long
#	endif
#endif

#define DEBUGPRINT(X) HpDebugPrint X
#define DEBUG_PRINT_LOCATION \
	printk(KERN_ERR "failure at %s:%d/%s()!\n", __FILE__, __LINE__, \
			__func__)

#define HPDSA_TIMEOUT (HZ * 30)
#define VPD_PAGE (1 << 8)

/*
 * Global variables
 */

struct pci_dev *cache_pdev = NULL;
struct pci_dev *ahci_8_pdev = NULL;
struct pci_dev *ahci_6_pdev = NULL;
struct pci_dev *ahci_4_pdev = NULL;
struct ctlr_info *cache_ctlr_info = NULL;
struct ctlr_info *ahci_8_ctlr_info = NULL;
struct ctlr_info *ahci_6_ctlr_info = NULL;
struct ctlr_info *ahci_4_ctlr_info = NULL;
struct ctlr_info *b140i_ctlr_info = NULL;
struct storage_adapters adapters;
struct pci_dev *hba_pdev = NULL;
int found_disk_adapter = 0;
int found_ahci_4 = 0;
int found_ahci_6 = 0;
int found_ahci_8 = 0;
int found_b140i = 0;
int cache_adapter_init_passed;
struct raidstack_function_table raidstack;
void *last_completion_addr = NULL;
int flag_hpdsa_shutdown_started = 0;
int raid_shutting_down = 0;
int cache_flushed = 0;
spinlock_t cache_flush_lock;

/*
 * Seems the background task is using the cache adapter and if we shutdown
 * the cache adapter before the raidstack, we have problems.
 *
 * For times when cache_shutdown is called before reidstack_shutdown.
 */
int hpdsa_remove_one_calls_cache_shutdown;

/*
 * For spanning
 */
struct storage_adapters {
	void *controllers[MAX_CTLRS];
	int count;
};

/*
 * Report information about this controller.
 */
#define ENG_GIG 1000000000
#define ENG_GIG_FACTOR (ENG_GIG/512)
#define RAID_UNKNOWN 6
#define RAIDDRVR_PCI_CONFIG_SIZE 256
#define CHECK_IOMMU_ON_MASK 0xFFFFFFFF00000000

static struct proc_dir_entry *proc_hpdsa;
static struct proc_dir_entry *pde;
static struct proc_dir_entry *pde_sob;

#define SELF_SCSI_ID (HPVSA_MAX_SCSI_DEVS_PER_HBA-1)
#define SCSI_HPDSA_CAN_QUEUE (MAX_CMDS-10)
#define HBA_INQUIRY_BYTE_COUNT 64

/*
 * Function prototypes
 */
void raid_application_define(void);
void stop_background_ios(void);
void CISS_NewCommand(struct CommandList *c);
void linux_SaCompleteSrb(struct ctlr_info  *h, struct CommandList *c);
void (*remove_function)(struct pci_dev *pdev);
static void hpdsa_submit_command(struct ctlr_info *h, struct CommandList *c);
static int hpdsa_alloc_sg_chain_blocks(struct ctlr_info *h);
static int hpdsa_alloc_sg_virtual_addresses(struct ctlr_info *h);
static int hpdsa_alloc_scatterlist_buffers(struct ctlr_info *h);
static void hpdsa_free_scatterlist_buffers(struct ctlr_info *h);
static void hpdsa_free_sg_chain_blocks(struct ctlr_info *h);
static void hpdsa_free_sg_virtual_addresses(struct ctlr_info *h);
static void hpdsa_shutdown_raidstack_and_cleanup(struct ctlr_info *h);

DECLARE_INTERRUPT_HANDLER(do_hpdsa_hw_intr);
DECLARE_INTERRUPT_HANDLER(do_hpdsa_ioapic_hw_intr);
DECLARE_INTERRUPT_HANDLER(do_hpdsa_b140i_hw_intr);
DECLARE_INTERRUPT_HANDLER(process_cache_adapter_msix_intr0);
DECLARE_INTERRUPT_HANDLER(process_cache_adapter_msix_intr1);
DECLARE_INTERRUPT_HANDLER(process_cache_adapter_ioapic_intr);
struct scsi_device *hpdsa_find_scsi_device(struct ctlr_info *h);

static int do_hpdsa_passthru(struct ctlr_info *ci, void __user *arg);
static int do_hpdsa_big_passthru(struct ctlr_info *ci, void __user *arg);
static int do_ioctl(struct scsi_device *dev, unsigned cmd, void __user *arg);
static int hpdsa_compat_ioctl(struct scsi_device *dev, int cmd,
				void __user *arg);
int hpdsa_ioctl(struct scsi_device *scsidev, int cmd, void __user *arg);
static int hpdsa_eh_device_reset_handler(struct scsi_cmnd *cmd);
void hpdsa_cleanup_irq(struct ctlr_info *h);
static void hpdsa_procinit(void);
static void hpdsa_cleanup_procfs(void);
static void set_config_data(struct ctlr_info *c);
static int linux_hpdsa_scsi_do_inquiry_one(struct ctlr_info *h, __u8 cmd,
					__u8 *scsi3addr,
					__u8 *buf,
					int bufsize,
					__u16 page,
					int cmd_type);
static int hpdsa_do_report_phys_luns(struct ctlr_info *h,
					int bufsize, char *buf);
static int hpdsa_do_report_log_luns(struct ctlr_info *h, int bufsize,
					unsigned char *buf);
static inline struct CommandList *alloc_command(struct ctlr_info *h, int type);
static void populate_cmd(struct CommandList *c, u8 cmd, struct ctlr_info *h,
			unsigned char *buf, size_t size,
			u16 page_code, unsigned char *scsi3addr,
			int cmd_type);
unsigned long hpdsa_lock(struct ctlr_info *h);
void hpdsa_unlock(struct ctlr_info *h, unsigned long flags);
static void hpdsa_scan_start(struct Scsi_Host *);
static int hpdsa_scan_finished(struct Scsi_Host *sh,
				unsigned long elapsed_time);
void hpdsa_flush_cache(struct ctlr_info *h);
static void hpdsa_ctlr_remove_one(struct pci_dev *pdev_disk);
static void hpdsa_ahci_remove_one(struct pci_dev *pdev_disk);
static void hpdsa_remove_ctlr(struct ctlr_info *h);
static void hpdsa_cache_remove_one(struct pci_dev *pdev_disk);
static int hpdsa_init_scsi_driver(struct pci_dev *pdev, struct ctlr_info *h);
static int hpdsa_init_raidstack(struct ctlr_info *h);
static void hpdsa_init_error_cleanup(struct pci_dev *pdev, struct ctlr_info *h);
static void hpdsa_cleanup_interrupts_and_msix(struct ctlr_info *h);
void hpdsa_fill_out_pci_config_space(struct ctlr_info *h, unsigned char *cs);
static inline u32 hpdsa_tag_contains_index(u32 tag);
static inline u32 hpdsa_tag_to_index(u32 tag);
unsigned long long hpdsa_smbios_get_raid_resources(char *type, u32 *length);
static unsigned long hpdsa_completed(struct ctlr_info *h);
static void hpdsa_intr_mask(struct ctlr_info *h, unsigned long val);
static unsigned long hpdsa_fifo_full(struct ctlr_info *h);
static  int hpdsa_intr_pending(struct ctlr_info *h);
static u32 get_board_id(struct pci_dev *pdev);
u32 get_disk_board_id(void);
u32 get_disk_num_msix_vectors(void);

extern int host_cli_pass_through(char *buff_ptr, unsigned int buff_len);

static struct access_method hpdsa_access = {
	hpdsa_submit_command,
	hpdsa_intr_mask,
	hpdsa_fifo_full,
	hpdsa_intr_pending,
	hpdsa_completed,
	hpdsa_lock,
	hpdsa_unlock,
};

extern u32 PAL_AHCI_HwInterrupt(void *pPalRoot, u32 MSIVector);
extern DWORD HAL_LISR_MSIX(BYTE adapter_num, DWORD vector);

int iommu_is_enabled;
int hpdsa_get_iommu_enabled(void)
{
	return iommu_is_enabled;
}

#if defined(RHEL5)
#define DMA_MAPPING_ERROR(d, a) dma_mapping_error(a)
#else
#define DMA_MAPPING_ERROR(d, a) dma_mapping_error(d, a)
#endif

#define BUF_SIZE PAGE_SIZE
int is_iommu_enabled(struct ctlr_info *h1, struct ctlr_info *h2)
{
	char *buf;
	dma_addr_t addr1 = 0;
	dma_addr_t addr2 = 0;
	u64 virt_addr = 0;
	int iommu_on = 0;

	buf = kzalloc(BUF_SIZE, GFP_KERNEL);
	if (!buf)
		goto iommu_check_complete;

	addr1 = pci_map_single(h1->pdev, buf, BUF_SIZE, PCI_DMA_TODEVICE);
	if (DMA_MAPPING_ERROR(&h1->pdev->dev, addr1))
		goto iommu_check_complete;

	addr2 = pci_map_single(h2->pdev, buf, BUF_SIZE, PCI_DMA_TODEVICE);
	if (DMA_MAPPING_ERROR(&h2->pdev->dev, addr2))
		goto iommu_check_complete;

	printk("%s: buf=%llx addr1=%llx addr2=%llx %llx/%llx\n",
		__func__, (u64)buf, addr1, addr2,
		(u64)buf & 0xFFFFFFFFF, addr1 & 0xFFFFFFFFF);

	/*
	 * if (addr1 == addr2)
	 * Blatently assuming that if IOMMU is enabled that
	 * mapped addresses are 32bit.
	 */
	//if (addr1 == addr2)
		//goto iommu_check_complete;

	/*
	 * The theory is that without IOMMU the lower 32bits will be the same
	 */
	virt_addr = (u64)buf & 0xFFFFFFFFF;
	if (virt_addr == (addr2 & 0xFFFFFFFFF))
		goto iommu_check_complete;
	//if (addr2 & CHECK_IOMMU_ON_MASK)
		//goto iommu_check_complete;

	iommu_on = 1;

iommu_check_complete:

	if (addr1)
		pci_unmap_single(h1->pcidev,
				(dma_addr_t) addr1,
				BUF_SIZE, PCI_DMA_TODEVICE);
	if (addr2)
		pci_unmap_single(h2->pcidev,
				(dma_addr_t) addr2,
				BUF_SIZE, PCI_DMA_TODEVICE);
	kfree(buf);

	return iommu_on;

} /* is_iommu_enabled */

static int xmargin = 8;
static int amargin = 60;

/**
 * @brief This is a debugging function used to print bytes in hex or asccii.
 * @tag Debugging
 */

static void
print_bytes(unsigned char *c, int len, int hex, int ascii)
{

	int i;
	unsigned char *x;

	if (hex) {
		x = c;
		for (i = 0; i < len; i++) {
			if ((i % xmargin) == 0 && i > 0)
				printk("\n");
			if ((i % xmargin) == 0)
				printk("0x%04x:", i);
			printk(" %02x", *x);
			x++;
		}
		printk("\n");
	}
	if (ascii) {
		x = c;
		for (i = 0; i < len; i++) {
			if ((i % amargin) == 0 && i > 0)
				printk("\n");
			if ((i % amargin) == 0)
				printk("0x%04x:", i);
			if (*x > 26 && *x < 128)
				printk("%c", *x);
			else
				printk(".");
			x++;
		}
		printk("\n");
	}
}

/*
 * @brief Prints all the fields of a command.
 * @tag Debugging
 */
static void
print_cmd(struct CommandList *cp)
{
	int i;
	unsigned char *uc;

	printk("queue:%d\n", cp->Header.ReplyQueue);
	printk("sglist:%d\n", cp->Header.SGList);
	printk("sgtot:%d\n", cp->Header.SGTotal);
	printk("Tag:0x%08x/0x%08x\n", cp->Header.Tag.upper,
			cp->Header.Tag.lower);
	printk("LUN:0x%02x%02x%02x%02x%02x%02x%02x%02x\n",
		cp->Header.LUN.LunAddrBytes[0],
		cp->Header.LUN.LunAddrBytes[1],
		cp->Header.LUN.LunAddrBytes[2],
		cp->Header.LUN.LunAddrBytes[3],
		cp->Header.LUN.LunAddrBytes[4],
		cp->Header.LUN.LunAddrBytes[5],
		cp->Header.LUN.LunAddrBytes[6],
		cp->Header.LUN.LunAddrBytes[7]);
	printk("CDBLen:%d\n", cp->Request.CDBLen);
	printk("Type:%d\n", cp->Request.Type.Type);
	printk("Attr:%d\n", cp->Request.Type.Attribute);
	printk("Dir:%d\n", cp->Request.Type.Direction);
	printk("Timeout:%d\n", cp->Request.Timeout);
	printk("CDB: %02x %02x %02x %02x %02x %02x %02x %02x"
		" %02x %02x %02x %02x %02x %02x %02x %02x\n",
		cp->Request.CDB[0], cp->Request.CDB[1],
		cp->Request.CDB[2], cp->Request.CDB[3],
		cp->Request.CDB[4], cp->Request.CDB[5],
		cp->Request.CDB[6], cp->Request.CDB[7],
		cp->Request.CDB[8], cp->Request.CDB[9],
		cp->Request.CDB[10], cp->Request.CDB[11],
		cp->Request.CDB[12], cp->Request.CDB[13],
		cp->Request.CDB[14], cp->Request.CDB[15]),
	printk("edesc.Addr: 0x%08x/0%08x, Len  = %d\n",
		cp->ErrDesc.Addr.upper, cp->ErrDesc.Addr.lower,
		cp->ErrDesc.Len);
	printk("sgs..........Errorinfo:\n");
	for (i = 0; i < cp->Header.SGList; i++) {
		uc = (unsigned char *) &cp->SG[i].Addr;
		printk("SG[%d] Addr = %02x%02x%02x%02x%02x%02x%02x%02x Len ="
				"0x%x\n", i, uc[0], uc[1], uc[2], uc[3], uc[4],
				uc[5], uc[6], uc[7], cp->SG[i].Len);
	}

	printk("scsistatus:%d\n", cp->err_info->ScsiStatus);
	printk("senselen:%d\n", cp->err_info->SenseLen);
	printk("cmd status:%d\n", cp->err_info->CommandStatus);
	printk("resid cnt:%d\n", cp->err_info->ResidualCnt);
	printk("offense size:%d\n",
			cp->err_info->MoreErrInfo.Invalid_Cmd.offense_size);
	printk("offense byte:%d\n",
			cp->err_info->MoreErrInfo.Invalid_Cmd.offense_num);
	printk("offense value:%d\n",
			cp->err_info->MoreErrInfo.Invalid_Cmd.offense_value);
}

DECLARE_QUEUECOMMAND(hpdsa_scsi_queue_command);
DECLARE_QUEUECOMMAND_WRAPPER(hpdsa_scsi_queue_command);
static const char *raid_label[] = { "0", "4", "1(1+0)", "5", "5+1", "ADG",
	"UNKNOWN"
};

/**
 * @brief returns a pointer the ctlr_info struct for the controller
 * @param[in] sh a pointer to the scsi_host instance (our driver, from mid
 * layers POV)
 */
static inline struct ctlr_info *shost_to_hba(struct Scsi_Host *sh)
{
	unsigned long *priv = shost_priv(sh);
	return (struct ctlr_info *) *priv;
}

/**
 * @brief returns a pointer the ctlr_info struct for the controller
 * @param[in] sdev a pointer to struct scsi_device (defined in midlayer
 * scsi_device.h in the kernel)
 */
static inline struct ctlr_info *scsi_device_to_hba(struct scsi_device *sdev)
{
	unsigned long *priv = shost_priv(sdev->host);
	return (struct ctlr_info *) *priv;
}

/* sysfs Functions */
static inline int is_logical_dev_addr_mode(unsigned char scsi3addr[])
{
	return (scsi3addr[3] & 0xC0) == 0x40;
}
/**
 * @brief Shows the raid level of an attached device
 * @tag sysfs function
 */
static ssize_t raid_level_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	ssize_t l = 0;
	unsigned char rlevel;
	struct ctlr_info *h;
	struct scsi_device *sdev;
	struct hpdsa_scsi_dev_t *hdev;
	unsigned long flags;

	sdev = to_scsi_device(dev);
	h = scsi_device_to_hba(sdev);
	spin_lock_irqsave(&h->lock, flags);
	hdev = sdev->hostdata;
	if (!hdev) {
		spin_unlock_irqrestore(&h->lock, flags);
		return -ENODEV;
	}
	if (!is_logical_dev_addr_mode(hdev->scsi3addr)) {
		spin_unlock_irqrestore(&h->lock, flags);
		l = snprintf(buf, PAGE_SIZE, "N/A\n");
		return l;
	}
	rlevel = hdev->raid_level;
	spin_unlock_irqrestore(&h->lock, flags);
	if (rlevel > RAID_UNKNOWN)
		rlevel = RAID_UNKNOWN;
	l = snprintf(buf, PAGE_SIZE, "RAID %s\n", raid_label[rlevel]);
	return l;
}

/**
 * @brief Shows the lun id of an attached device
 * @tag sysfs function
 */
static ssize_t lunid_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	struct ctlr_info *h;
	struct scsi_device *sdev;
	struct hpdsa_scsi_dev_t *hdev;
	unsigned long flags;
	unsigned char lunid[8];

	sdev = to_scsi_device(dev);
	h = scsi_device_to_hba(sdev);
	spin_lock_irqsave(&h->lock, flags);
	hdev = sdev->hostdata;
	if (!hdev) {
		spin_unlock_irqrestore(&h->lock, flags);
		return -ENODEV;
	}
	memcpy(lunid, hdev->scsi3addr, sizeof(lunid));
	spin_unlock_irqrestore(&h->lock, flags);
	return snprintf(buf, 20, "0x%02x%02x%02x%02x%02x%02x%02x%02x\n",
			lunid[0], lunid[1], lunid[2], lunid[3],
			lunid[4], lunid[5], lunid[6], lunid[7]);
}

/**
 * @brief Shows the unique ID of an attached device
 * @tag sysfs function
 */
static ssize_t unique_id_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	struct ctlr_info *h;
	struct scsi_device *sdev;
	struct hpdsa_scsi_dev_t *hdev;
	unsigned long flags;
	unsigned char sn[16];

	sdev = to_scsi_device(dev);
	h = scsi_device_to_hba(sdev);
	spin_lock_irqsave(&h->lock, flags);
	hdev = sdev->hostdata;
	if (!hdev) {
		spin_unlock_irqrestore(&h->lock, flags);
		return -ENODEV;
	}
	memcpy(sn, hdev->device_id, sizeof(sn));
	spin_unlock_irqrestore(&h->lock, flags);
	return snprintf(buf, 16 * 2 + 2,
			"%02X%02X%02X%02X%02X%02X%02X%02X"
			"%02X%02X%02X%02X%02X%02X%02X%02X\n",
			sn[0], sn[1], sn[2], sn[3],
			sn[4], sn[5], sn[6], sn[7],
			sn[8], sn[9], sn[10], sn[11],
			sn[12], sn[13], sn[14], sn[15]);
}

/**
 * @brief shows the number of outstanding commands for the
 * controller.
 * @tag sysfs function
 */
DECLARE_DEVATTR_SHOW_FUNC(host_show_commands_outstanding)
{
	struct Scsi_Host *shost = class_to_shost(dev);
	struct ctlr_info *h = shost_to_hba(shost);

	return snprintf(buf, 20, "%d\n", h->commands_outstanding);
}

/**
 * @brief Shows the firmware revision of the attached controller
 * @tag sysfs function
 */
DECLARE_DEVATTR_SHOW_FUNC(host_show_firmware_revision)
{
	struct ctlr_info *h;
	struct Scsi_Host *shost = class_to_shost(dev);
	unsigned char *fwrev;

	h = shost_to_hba(shost);
	if (!h->hba_inquiry_data)
		return 0;
	fwrev = &h->hba_inquiry_data[32];
	return snprintf(buf, 20, "%c%c%c%c%c\n",
			fwrev[0], fwrev[1], fwrev[2], fwrev[3], fwrev[4]);
}

/**
 * @brief Shows the transport mode of the controller, always performant
 * @tag sysfs function
 */
/* Hpvsa only has 1 mode */
DECLARE_DEVATTR_SHOW_FUNC(host_show_transport_mode)
{
	return snprintf(buf, 20, "%s\n", "performant");
}

/**
 * @brief Shows that the controller is not ressetable
 * @tag sysfs function
 */
DECLARE_DEVATTR_SHOW_FUNC(host_show_resettable)
{
	return snprintf(buf, 20, "%d\n", 0);
}
/* sysfs Attribs */
static DEVICE_ATTR(raid_level, S_IRUGO, raid_level_show, NULL);
static DEVICE_ATTR(lunid, S_IRUGO, lunid_show, NULL);
static DEVICE_ATTR(unique_id, S_IRUGO, unique_id_show, NULL);
DECLARE_HOST_DEVICE_ATTR(firmware_revision, S_IRUGO,
		host_show_firmware_revision, NULL);
DECLARE_HOST_DEVICE_ATTR(commands_outstanding, S_IRUGO,
		host_show_commands_outstanding, NULL);
DECLARE_HOST_DEVICE_ATTR(transport_mode, S_IRUGO,
		host_show_transport_mode, NULL);
DECLARE_HOST_DEVICE_ATTR(resettable, S_IRUGO,
		host_show_resettable, NULL);

/**
 * @brief Array of type device_attribute used to pass device attributes to sysfs
 * filesystem. Also passed to the scsi host template.
 */
static struct device_attribute *hpdsa_sdev_attrs[] = {
	&dev_attr_raid_level,
	&dev_attr_lunid,
	&dev_attr_unique_id,
	NULL,
};

/**
 * @brief Array of structs used to pass host attributes to sysfs,type depends on
 * kernel age. Also passed the the scsi host template.
 */
DECLARE_HOST_ATTR_LIST(hpdsa_shost_attrs) = {
	&dev_attr_firmware_revision,
	&dev_attr_commands_outstanding,
	&dev_attr_transport_mode,
	&dev_attr_resettable,
	NULL,
};
	/*end sysfs functions */

/**
 * @struct hpdsa_scsi
 * @brief An array of structs of type hpdsa_scsi_hba_t. This is the array were
 * we store the pointer that the scsi mid layer knows us by, we use it when we
 * need to communicate to and from the mid layer or get info from the mid
 * layer's struct. E.g scsi3addr and setting the raid_level.
 */
static struct hpdsa_scsi_hba_t hpdsa_scsi[HPVSA_MAX_SCSI_DEVS_PER_HBA] = {
	{ .name = DRIVERNAME "0", .ndevices = 0 },
	{ .name = DRIVERNAME "1", .ndevices = 0 },
	{ .name = DRIVERNAME "2", .ndevices = 0 },
	{ .name = DRIVERNAME "3", .ndevices = 0 },
	{ .name = DRIVERNAME "4", .ndevices = 0 },
	{ .name = DRIVERNAME "5", .ndevices = 0 },
	{ .name = DRIVERNAME "6", .ndevices = 0 },
	{ .name = DRIVERNAME "7", .ndevices = 0 },
	{ .name = DRIVERNAME "8", .ndevices = 0 },
};
/**
 * @brief returns the controller pointer from the array of controller ptrs.
 * @param[in] h pointer to controller struct
 * @param[in] bus,target,lun identifiers of the device
 */
static struct hpdsa_scsi_dev_t *lookup_hpdsa_scsi_dev(struct ctlr_info *h,
						int bus, int target, int lun)
{
	int i;
	struct hpdsa_scsi_dev_t *sd;

	for (i = 0; i < hpdsa_scsi[h->ctlr_num].ndevices; i++) {
		sd = &hpdsa_scsi[h->ctlr_num].dev[i];
		if (sd->bus == bus && sd->target == target && sd->lun == lun)
			return sd;
	}
	return NULL;
}

/**
 * @brief scsi_host_template function, called by mid-layer after a successful
 * scan_host.
 * @param[in] sdev scsi_device instance passed in from mid-layer
 */
static int hpdsa_slave_alloc(struct scsi_device *sdev)
{
	struct hpdsa_scsi_dev_t *sd;
	unsigned long flags;
	struct ctlr_info *h;

	h = scsi_device_to_hba(sdev);
	spin_lock_irqsave(&h->lock, flags);
	sd = lookup_hpdsa_scsi_dev(h, sdev_channel(sdev),
		sdev_id(sdev), sdev->lun);
	if (sd != NULL) {
		sdev->hostdata = sd;

		if (sd->devtype == TYPE_ROM) {
			printk("hpdsa: Setting ODD queue depth to 1\n");
			scsi_adjust_queue_depth(sdev, 0, 1);
		}
	}
	spin_unlock_irqrestore(&h->lock, flags);

	return 0;
}
/**
 * @var hpdsa_driver_template
 * @brief This is the template required by the mid-layer. A pointer to this
 * template is passed to the scsi mid-layer through the call to scsi_host_alloc.
 * This is defined in scsi/hosts.c in the kernel. These are mostly function
 * pointers that are passed to the mid-layer so it can communicate with this
 * driver.
 */
static struct scsi_host_template hpdsa_driver_template = {
	.module				= THIS_MODULE,
	.name				= DRIVERNAME,
	.proc_name			= DRIVERNAME,
	.queuecommand			= hpdsa_scsi_queue_command,
	INITIALIZE_SCAN_START(hpdsa_scan_start)
	INITIALIZE_SCAN_FINISHED(hpdsa_scan_finished)
	.this_id			= -1,
	.use_clustering			= ENABLE_CLUSTERING,
	.eh_device_reset_handler	= hpdsa_eh_device_reset_handler,
	.sdev_attrs			= hpdsa_sdev_attrs,
	.shost_attrs			= hpdsa_shost_attrs,
	.slave_alloc			= hpdsa_slave_alloc,
	.ioctl				= hpdsa_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl			= hpdsa_compat_ioctl,
#endif
#ifdef USE_NO_SCSI_WRITE_SAME
	.no_write_same			= 1, /* Not supported yet */
#endif
};



struct ctlr_info *hpdsa_hba[MAX_CTLRS] = { NULL };
int cache_hba_number = -1;
struct ctlr_info *disk_h_ptr;
struct ctlr_info *cache_h_ptr;
int raid_application_loaded;
int found_sas_adapter;
int found_ahci_adapter;
int found_cache_adapter;
int initialized_cache_adapter;
int hpdsa_driver_loaded;

#define NUM_CPUS 128
spinlock_t vsa_lock;
spinlock_t *vsa_lock_addr;

#ifdef CONFIG_PCI_MSI
struct msix_entry cache_msix_entries[2] = { {0, 0}, {0, 1} };
#endif

/* external variables */

/* external(RAID stack) functions */

void HpDebugPrint(unsigned int DebugPrintLevel, char *DebugMessage, ...);

unsigned long get_disk_paddr(void)
{
	return disk_h_ptr->paddr;
} /* get_paddr */

void __iomem *get_disk_vaddr(void)
{
	return disk_h_ptr->vaddr;
} /* get_vaddr */

int get_controller_board_id(void *controller)
{
	return get_board_id(((struct ctlr_info *)controller)->pdev);
} /* get_controller_board_id */

void *get_controller_pcidev(void *controller)
{
	return ((struct ctlr_info *)controller)->pcidev;
}

u32 get_disk_board_id(void)
{
	return disk_h_ptr->board_id;
} /* get_disk_board_id */

u32 get_disk_num_msix_vectors(void)
{
	return disk_h_ptr->num_msix_vectors;
} /* get_disk_num_msix_vectors */

void *get_disk_h_ptr(void)
{
	return (void *)disk_h_ptr;
} /* get_disk_h_ptr */

void *get_ahci6_h_ptr(void)
{
	return (void *) ahci_6_ctlr_info;
} /* get_ahci6_h_ptr */

void *get_ahci4_h_ptr(void)
{
	return (void *) ahci_4_ctlr_info;
} /* get_ahci4_h_ptr */

int is_b140i(void)
{
	return disk_h_ptr->is_b140i;
}

void initialize_storage_adapters(void)
{

	if (ahci_8_ctlr_info)
		adapters.controllers[adapters.count++] = ahci_8_ctlr_info;
	if (ahci_6_ctlr_info)
		adapters.controllers[adapters.count++] = ahci_6_ctlr_info;
	if (ahci_4_ctlr_info)
		adapters.controllers[adapters.count++] = ahci_4_ctlr_info;
}

unsigned char get_num_secondary_adapters(void)
{
   return (unsigned char) adapters.count;
}

unsigned long get_secondary_adapter_ssid(unsigned char index)
{
   struct ctlr_info *ctrl;
   __u32 ssid = 0x00001234; // something bogus

   if(index < MAX_CTLRS) {
      ctrl = adapters.controllers[index];
      ssid = ctrl->board_id;
   }

   return (unsigned long) ssid;
}

/*
 * This routine called by RAID stack for soft intr completion
 */
void ciss_cmd_completion(void *ciss_cmd)
{
	unsigned long flags = 0;
	struct ctlr_info *h = disk_h_ptr;
	linux_SaCompleteSrb(h, ciss_cmd);
}

int get_cache_hba_number(void)
{
	return cache_hba_number;
} /* get_cache_hba_number */

void *get_cache_h_ptr(void)
{
	return (void *)cache_h_ptr;
} /* get_cache_h_ptr */

void __iomem *get_cache_vaddr(void)
{
	return cache_h_ptr->vaddr;
} /* get_cache_vaddr */

void set_virtual_pal_root(void *adapter, void *virtual_pal_root)
{
	struct ctlr_info *controller = (struct ctlr_info *) adapter;
	controller->pal_root = virtual_pal_root;
}

void hpdsa_save_isr(void *controller, void *isr)
{
	if (controller)
		((struct ctlr_info *) controller)->isr = isr;
	else
		printk(DRIVERNAME ": could not set isr.\n");
} /* hpdsa_save_isr */

char *get_hpdsa_driver_version(void)
{
	return HPVSA_DRIVER_VERSION;
}

void __iomem *get_virtual_address(void *adapter)
{
	struct ctlr_info *controller = (struct ctlr_info *) adapter;
	return controller->vaddr;
}

/*
 * Helper functions
 */
int is_cache_adapter(unsigned int board_id)
{
	if ((board_id == CACHE_PCI_SUBSYS_ID))
		return 1;
	else
		return 0;
} /* is_cache_adapter */

int is_b140i_adapter(unsigned int board_id)
{
	printk("%s: checking 0x%x against 0x%x\n", __func__,
		board_id, B140I_PCI_SUBSYS_ID);

	if (board_id == B140I_PCI_SUBSYS_ID)
		return 1;
	else
		return 0;
} /* is_b140i_adapter */

inline int is_sas_adapter(unsigned int board_id)
{
	if ((board_id == LSI_EMBEDDED_PCI_SUBSYS_ID) ||
		(board_id == LSI_DAUGHTER_PCI_SUBSYS_ID) ||
		((board_id & 0xffff) == PCI_VENDOR_ID_LSI))
		/* remove this G6 support later */
		return 1;
	else
		return 0;
} /* is_sas_adapter */

inline int is_ahci_adapter(unsigned int board_id)
{
	if ((board_id == AHCI_8P_PCI_SUBSYS_ID) ||
		(board_id == AHCI_8P_PCI_SUBSYS_ID_ES2) ||
		(board_id == AHCI_4P_PCI_SUBSYS_ID) ||
		(board_id == PATSBURG_PCI_SUBSYS_ID) ||
		(board_id == COUGAR_POINT_PCI_SUBSYS_ID) ||
		(board_id == LYNX_POINT_PCI_SUBSYS_ID)  ||
		(board_id == AHCI_6P_PCI_SUBSYS_ID))
		return 1;
	else
		return 0;
} /* is_ahci_adapter */

inline int is_ahci_8(unsigned int board_id)
{
	if ( (board_id == AHCI_8P_PCI_SUBSYS_ID) || (board_id == AHCI_8P_PCI_SUBSYS_ID_ES2))
		return 1;
	else
		return 0;
} /* is_ahci_8 */

inline int is_ahci_6(unsigned int board_id)
{
	return (board_id == AHCI_6P_PCI_SUBSYS_ID);
} /* is_ahci_6 */

inline int is_ahci_4(unsigned int board_id)
{
	return (board_id == AHCI_4P_PCI_SUBSYS_ID);
} /* is_ahci_4 */

inline int is_ahci_adapter_ahci(unsigned int board_id)
{
	printk("%s: checking 0x%x [0x%x 0x%x 0x%x 0x%x]\n",
		__func__, board_id,
		AHCI_8P_PCI_SUBSYS_ID,
		AHCI_8P_PCI_SUBSYS_ID_ES2,
		AHCI_6P_PCI_SUBSYS_ID,
		AHCI_4P_PCI_SUBSYS_ID);

	if (	(board_id == AHCI_8P_PCI_SUBSYS_ID) ||
		(board_id == AHCI_8P_PCI_SUBSYS_ID_ES2) ||
		(board_id == AHCI_6P_PCI_SUBSYS_ID) ||
		(board_id == AHCI_4P_PCI_SUBSYS_ID))
		return 1;
	else
		return 0;
}

inline int is_disk_adapter(unsigned int board_id)
{
	if ((is_b140i_adapter(board_id)) || (is_sas_adapter(board_id)) ||
		(is_ahci_adapter(board_id)))
		return 1;
	else
		return 0;
} /* is_disk_adapter */

struct pci_dev *pci_discovery_storage_adapter(int vendor_id, int device_id,
						int subsystem_id,
						int subsystem_device)
{
	struct pci_dev *dev;

	printk("%s: Looking for 0x%x 0x%x 0x%x 0x%x\n", __func__,
		vendor_id, device_id, subsystem_id, subsystem_device);
	dev = pci_get_subsys(vendor_id, device_id, subsystem_id, subsystem_device, NULL);
	if (dev)
		return dev;

	printk("%s: Returning NULL\n", __func__);
	return NULL;

} /* pci_discovery_storage_adapter */

struct pci_dev *pci_discovery_found_cache_adapter(void)
{
	struct pci_dev *dev;

	dev = pci_get_subsys(PCI_VENDOR_ID_HP_NEW, CACHE_PCI_DEVICE_ID,
				PCI_VENDOR_ID_HP_NEW, CACHE_PCI_DEVICE_ID,
				 NULL);
	if (dev)
		return dev;

	return NULL;
} /* pci_discovery_found_cache_adapter */

/*
 * Having issues with pci_free_consistent with XEN kernels. What a mess
 */
#if defined(COMPILE_XEN)
static inline struct CommandList *xen_alloc_command(struct ctlr_info *h,
		int type)
{

	static struct CommandList	*c;
	static ErrorInfo_struct		*e;
	static dma_addr_t		cmd_dma_handle;
	static dma_addr_t		err_dma_handle;
	union u64bit 			temp_val64;
	void				*t = NULL;

	if (type) {
		pci_free_consistent(h->pcidev, sizeof(*c), c,
				(dma_addr_t)cmd_dma_handle);
		pci_free_consistent(h->pcidev, sizeof(*e), e,
				(dma_addr_t)err_dma_handle);
		return NULL;
	}

	if (!c)
		c = (struct CommandList *)pci_alloc_consistent(h->pcidev,
				sizeof(*c), &cmd_dma_handle);

	if (!c)
		return NULL;

	t = c->sg_buffer;
	memset(c, 0, sizeof(*c));
	c->sg_buffer = t;

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK) || !defined(CPU_64_BIT)
	if (!c->sg_buffer)
		c->sg_buffer = kmalloc(XEN_32_SG_BUFSIZE, GFP_KERNEL);
	if (!c->sg_buffer)
		return NULL;
	memset(c->sg_buffer, 0, XEN_32_SG_BUFSIZE);
#endif

	c->cmdindex = -1;

	if (!e)
		e = (ErrorInfo_struct *) pci_alloc_consistent(h->pcidev,
				sizeof(*c->err_info), &err_dma_handle);
	if (!e)
		return NULL;
	memset(e, 0, sizeof(*c->err_info));

	c->cmd_dma_handle = cmd_dma_handle;
	c->busaddr = cmd_dma_handle;
	c->err_dma_handle = err_dma_handle;

	temp_val64.val = (u64) err_dma_handle;
	c->ErrDesc.Addr.lower = temp_val64.val32.lower;
	c->ErrDesc.Addr.upper = temp_val64.val32.upper;
	c->ErrDesc.Len = sizeof(*c->err_info);
	c->err_info = e;
	c->h = h;

	PTR_TO_U64(c->Header.Tag, c);

	return c;

} /* xen_alloc_command */
static void xen_free_hpdsa_command(struct ctlr_info *h,
					struct CommandList *c, int type)
{
	return; /* Do nothing */

} /* xen_free_hpdsa_command */
#endif
/*
* Locate an open command slot.
* Expected to be called with spin_lock held.
*/
static inline struct CommandList *alloc_command(struct ctlr_info *h, int type)
{

	struct CommandList	*c = NULL;
	ErrorInfo_struct	*e = NULL;
	int			i = 0;
	dma_addr_t		cmd_dma_handle = (dma_addr_t)NULL;
	dma_addr_t		err_dma_handle = (dma_addr_t)NULL;
	union u64bit 		temp_val64;
#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK) || !defined(CPU_64_BIT)
	void			*t = NULL;
#endif

	switch (type) {
	case 0: /* allocate command dynamically (for ioctls) */
		c = (struct CommandList *)pci_alloc_consistent(h->pcidev,
				sizeof(*c), &cmd_dma_handle);
		if (!c)
			return NULL;
		memset(c, 0, sizeof(*c));

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK) || !defined(CPU_64_BIT)
		c->sg_buffer = kzalloc(XEN_32_SG_BUFSIZE, GFP_KERNEL);
		if (!c->sg_buffer)
			return NULL;
#endif

		c->cmdindex = -1;

		e = (ErrorInfo_struct *) pci_alloc_consistent(h->pcidev,
				sizeof(*c->err_info), &err_dma_handle);
		if (!e) {
			pci_free_consistent(h->pcidev, sizeof(*c), c,
					(dma_addr_t)cmd_dma_handle);
			return NULL;
		}
		memset(e, 0, sizeof(*c->err_info));

		c->cmd_dma_handle = cmd_dma_handle;
		c->busaddr = cmd_dma_handle;
		c->err_dma_handle = err_dma_handle;

		temp_val64.val = (u64) err_dma_handle;
		c->ErrDesc.Addr.lower = temp_val64.val32.lower;
		c->ErrDesc.Addr.upper = temp_val64.val32.upper;
		c->ErrDesc.Len = sizeof(*c->err_info);
		c->err_info = e;
		c->h = h;

		PTR_TO_U64(c->Header.Tag, c);

		return c;
		break;
	case 1: /* Get from existing pool of commands */
		do {
			i = find_first_zero_bit(h->pool_bits, h->nr_cmds);
			if (i >= h->nr_cmds)
				return NULL;
		} while (test_and_set_bit(i & (BITS_PER_LONG - 1),
				h->pool_bits + (i/BITS_PER_LONG)) != 0);

		if (i >= h->nr_cmds)
			return NULL;
		/*
		 *Sets C to the memory address inside of the cmd_pool
		 *could use the array notation here as well
		 *the memory address is used for direct lookup
		 */
		c = h->cmd_pool + i;

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK) || !defined(CPU_64_BIT)
		t = c->sg_buffer;
		memset(c, 0, sizeof(*c));
		c->sg_buffer = t;
#else
		memset(c, 0, sizeof(*c));
#endif
		c->cmdindex = i;

		c->err_info = h->errinfo_pool + i;
		memset(c->err_info, 0, sizeof(*c->err_info));

		cmd_dma_handle = h->CommandList_dhandle + (i * sizeof(*c));
		c->busaddr = (u32) cmd_dma_handle;

		err_dma_handle = h->ErrorInfo_dhandle + (i * sizeof(*c->err_info));
		temp_val64.val = (u64) err_dma_handle;
		c->ErrDesc.Addr.lower = temp_val64.val32.lower;
		c->ErrDesc.Addr.upper = temp_val64.val32.upper;
		c->ErrDesc.Len = sizeof(*c->err_info);

		c->h = h;

		c->Header.Tag.upper = 0x00;
		c->Header.Tag.lower = (c->cmdindex << DIRECT_LOOKUP_SHIFT);
		c->Header.Tag.lower |= DIRECT_LOOKUP_BIT;

		return c;

		break;
	default:
		printk("alloc_command: unknown flag passed\n");
	} /* switch */

	return NULL;
} /* alloc_command */

/*
* Free a command slot
* Call with spin_lock held
*
*/
static void free_hpdsa_command(struct ctlr_info *h, struct CommandList *c,
		 int type)
{
	int	i = 0;

	switch (type) {
	case 0:	/* Dynamically allocated. */
		if (c) {
#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK) || !defined(CPU_64_BIT)
			kfree(c->sg_buffer);
#endif
			if (c->err_info)
				pci_free_consistent(h->pcidev,
					sizeof(*c->err_info), c->err_info,
					(dma_addr_t)c->err_dma_handle);
			pci_free_consistent(h->pcidev, sizeof(*c), c,
				(dma_addr_t)c->cmd_dma_handle);
		}
		break;
	case 1:
		i = c - h->cmd_pool;
		clear_bit(i & (BITS_PER_LONG - 1), h->pool_bits + (i / BITS_PER_LONG));
		break;
	} /* switch */
}

struct CommandList *hpdsa_get_command_from_tag(U64 Tag, u32 *index)
{
	struct CommandList *c = NULL;

	if (hpdsa_tag_contains_index(Tag.lower)) { /* Direct lookup command */
		*index = hpdsa_tag_to_index(Tag.lower);
		c = disk_h_ptr->cmd_pool + *index;
	} else { /* IOCTL command */
		c = U64_TO_PTR(Tag);
	} /* else IOCTL command */

	return c;
}

#define OS_FLAG_LOGICAL_DATABUFFER 0x00000001
#define OS_FLAG_LOGICAL_ERRORBUFFER 0x00000002

void *OS_GetCissBufferVirtAddr(U64 Tag, unsigned long flag, U32 sg_num)
{

	struct CommandList *c = NULL;
	u32 index = 0;

	c = hpdsa_get_command_from_tag(Tag, &index);

	switch (flag) {
	case OS_FLAG_LOGICAL_DATABUFFER:
		if (c->cmdindex == -1) { /* IOCTL */
			return (void *)c->ioctl_sg_virtual_addresses[sg_num];
		} else {
			return (void *)disk_h_ptr->sg_virtual_addresses[c->cmdindex][sg_num];
		}
	case OS_FLAG_LOGICAL_ERRORBUFFER:
		if (c->cmdindex == -1) { /* IOCTL */
			return (void *)c->err_info;
		} else {
			return (void *)(disk_h_ptr->errinfo_pool + index);
		}
	default:
		printk("%s: Unhandled case\n", __func__);
		return 0;
	}

} /* OS_GetCissBufferVirtualAddress */

static void hpdsa_cleanup_memory(struct ctlr_info *h)
{

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK) || !defined(CPU_64_BIT)
	/*
	 * Had issues with 32bit XEN kernels. So I made my own local bounce
	 * buffers so the raidstack could access the data buffers without
	 * kmap_atomic calls.
	 */
	int i = 0;
	struct CommandList *c;

	if (h->cmd_pool == NULL)
		return;

	for (i = 0; i < h->nr_cmds; i++) {
		c = h->cmd_pool + i;
		kfree(c->sg_buffer);
	}
#endif
	hpdsa_free_sg_chain_blocks(h);
	hpdsa_free_sg_virtual_addresses(h);
	hpdsa_free_scatterlist_buffers(h);

	/*
	 * Free cmd_pool
	 */
	if (h->cmd_pool)
		pci_free_consistent(h->pcidev,
				sizeof(struct CommandList) * h->nr_cmds,
				h->cmd_pool,
				(dma_addr_t)h->CommandList_dhandle);
	/*
	 * Free error info pool
	 */
	if (h->errinfo_pool)
		pci_free_consistent(h->pcidev,
					sizeof(ErrorInfo_struct) * h->nr_cmds,
					h->errinfo_pool,
					(dma_addr_t)h->ErrorInfo_dhandle);
	if (h->pool_bits)
		kfree(h->pool_bits);

	if (h->hba_inquiry_data) {
		kfree(h->hba_inquiry_data);
		h->hba_inquiry_data = NULL;
	}
#if defined(COMPILE_XEN)
	/*
	 * Free static command buffers
	 */
	xen_alloc_command(h, 1);
#endif

	if (h->cfgtable)
		kfree(h->cfgtable);

} /* hpdsa_cleanup_memory */

/*
 * Map (physical) PCI mem into (virtual) kernel space
 *
 * Note: Only pci registers need to be mapped using nocache.
 *
 * Raidstack can remap using cache because DMA operations
 * are snooped and are thus considered safe to allow caching.
 */
static inline void __iomem *ioremap_mem(ulong base, ulong size)
{
	ulong page_base = ((ulong) base) & PAGE_MASK;
	ulong page_offs = ((ulong) base) - page_base;
	void __iomem *page_remapped = ioremap_nocache(page_base, page_offs + size);

	return page_remapped ? (page_remapped + page_offs) : NULL;
}

void print_hpdsa_scsi(char *str, int ndevices, struct hpdsa_scsi_dev_t *csd)
{
	int i;
	int buflen = 0;
	int cntl_num = 0;

	for (i = 0; i < ndevices; i++) {
		struct hpdsa_scsi_dev_t *sd = &csd[i];
		if (!sd)
			continue;
		printk(DRIVERNAME " %s - b%02dt%02dl%02d %02d "
			"[0x%02x%02x%02x%02x%02x%02x%02x%02x] scsi2addr[%04x]\n",
			str,
			sd->bus, sd->target, sd->lun,
			sd->devtype,
			sd->scsi3addr[0], sd->scsi3addr[1],
			sd->scsi3addr[2], sd->scsi3addr[3],
			sd->scsi3addr[4], sd->scsi3addr[5],
			sd->scsi3addr[6], sd->scsi3addr[7],
			sd->scsi2addr);
	}
} /* print_hpdsa_scsi */

#define PRINT_BUF_SIZE 512
void print_scsi_sg_list(char *msg, struct CommandList *c, struct scsi_cmnd *sc)
{
	struct scatterlist *sg;
	int use_sg = 0, i = 0;
	int j = 0;
	char buf[PRINT_BUF_SIZE];

	memset(buf, 0, PRINT_BUF_SIZE);
#if defined(RHEL6) || defined(RHEL7)
	scsi_sg_copy_to_buffer(sc, buf, PRINT_BUF_SIZE);
#endif

	printk("%s: Starting\n", __func__);
	for (j = 0; j < PRINT_BUF_SIZE; j++)
		printk("%c", buf[j]);
	printk("\n");
	printk("%s: Ending\n", __func__);
}

void print_scsi_cmd_and_error(const char *msg, struct CommandList *c,
				struct scsi_cmnd *sc)
{
	ErrorInfo_struct *ei = NULL;
	struct scsi_cmnd *cmd = NULL;
	struct ctlr_info *h = NULL;
	u64bit addr64;
	u64bit *paddr64;
	unsigned long flags = 0;
	int i;

	unsigned char sense_key = 0;
	unsigned char asc = 0;      /* additional sense code */
	unsigned char ascq = 0;     /* additional sense code qualifier */

	cmd = sc;
	h = c->h;
	ei = c->err_info;

	sense_key = 0xf & ei->SenseInfo[2];
	asc = ei->SenseInfo[12];
	ascq = ei->SenseInfo[13];

	printk("%s: scsi cmd errors\n", msg);
	printk("LunAddrBytes = [%02x%02x%02x%02x%02x%02x%02x%02x]\n",
				c->Header.LUN.LunAddrBytes[0],
				c->Header.LUN.LunAddrBytes[1],
				c->Header.LUN.LunAddrBytes[2],
				c->Header.LUN.LunAddrBytes[3],
				c->Header.LUN.LunAddrBytes[4],
				c->Header.LUN.LunAddrBytes[5],
				c->Header.LUN.LunAddrBytes[6],
				c->Header.LUN.LunAddrBytes[7]);

	printk("Command Direction: 0x%x (%s)\n",  c->Request.Type.Direction,
		c->Request.Type.Direction == XFER_READ ? "XFER_READ" :
		c->Request.Type.Direction == XFER_WRITE ? "XFER_WRITE" :
		c->Request.Type.Direction == XFER_NONE ? "XFER_NONE" : "BIDIR");

	printk("   SCSI Direction: 0x%x (%s)\n", cmd->sc_data_direction,
		cmd->sc_data_direction == DMA_BIDIRECTIONAL ? "DMA_BIDIRECTIONAL" :
		cmd->sc_data_direction == DMA_TO_DEVICE ? "DMA_TO_DEVICE" :
		cmd->sc_data_direction == DMA_FROM_DEVICE ? "DMA_FROM_DEVICE" : "DMA_NONE");

	printk("CCISS CDB:");
	for (i = 0; i < 16; i++)
		printk("%02x", c->Request.CDB[i]);
	printk("\n");
	printk(" SCSI CDB:");
	for (i = 0; i < 16; i++)
		printk("%02x", cmd->cmnd[i]);
	printk("\n");
#if 0
	printk("cmd_flags:\n");
	printk("                    REQ_RW:%04x\n", REQ_RW);
	printk("              REQ_FAILFAST:%04x\n", REQ_FAILFAST_DEV);
	printk("    REQ_FAILFAST_TRANSPORT:%04x\n", REQ_FAILFAST_TRANSPORT);
	printk("       REQ_FAILFAST_DRIVER:%04x\n", REQ_FAILFAST_DRIVER);
	printk("               REQ_DISCARD:%04x\n", REQ_DISCARD);
	printk("                REQ_SORTED:%04x\n", REQ_SORTED);
	printk("           REQ_SOFTBARRIER:%04x\n", REQ_SOFTBARRIER);
	printk("           REQ_HARDBARRIER:%04x\n", REQ_HARDBARRIER);
	printk("                   REQ_FUA:%04x\n", REQ_FUA);
	printk("               REQ_NOMERGE:%04x\n", REQ_NOMERGE);
	printk("               REQ_STARTED:%04x\n", REQ_STARTED);
	printk("              REQ_DONTPREP:%04x\n", REQ_DONTPREP);
	printk("                REQ_QUEUED:%04x\n", REQ_QUEUED);
	printk("               REQ_ELVPRIV:%04x\n", REQ_ELVPRIV);
	printk("                REQ_FAILED:%04x\n", REQ_FAILED);
	printk("                 REQ_QUIET:%04x\n", REQ_QUIET);
	printk("               REQ_PREEMPT:%04x\n", REQ_PREEMPT);
	printk("         REQ_ORDERED_COLOR:%04x\n", REQ_ORDERED_COLOR);
	printk("               REQ_RW_SYNC:%04x\n", REQ_RW_SYNC);
	printk("               REQ_ALLOCED:%04x\n", REQ_ALLOCED);
	printk("               REQ_RW_META:%04x\n", REQ_RW_META);
	printk("             REQ_COPY_USER:%04x\n", REQ_COPY_USER);
	printk("             REQ_INTEGRITY:%04x\n", REQ_INTEGRITY);
	printk("scsi request:\n");
	printk("             cmd_type = 0x%x\n", cmd->request->cmd_type);
	printk("                flags = 0x%x\n", cmd->request->cmd_flags);
	printk("     nr_phys_segments = 0x%x\n", cmd->request->nr_phys_segments);
	printk("                  tag = 0x%x\n", cmd->request->tag);
	printk("            ref_count = 0x%x\n", cmd->request->ref_count);
	printk("              cmd_len = 0x%x\n", cmd->request->cmd_len);
#endif

	printk("CommandStatus = 0x%x\n", ei->CommandStatus);
	printk("SenseKey: 0x%x asc = 0x%x ascq = 0x%x\n", sense_key, asc, ascq);
	printk("ScsiStatus = 0x%x\n", ei->ScsiStatus);
	printk("ResidualCnt = 0x%x\n", ei->ResidualCnt);
	for (i = 0; i < ei->SenseLen; i++)
		printk("%02x", ei->SenseInfo[i]);
	printk("\n");
} /* print_scsi_cmd_and_error */

/*
* Get logical lun report
*
* This command does not go beyond the raidstack. (No real DMA to/from a device)
*/

static int hpdsa_get_device_id(struct ctlr_info *h, unsigned char *scsi3addr,
				unsigned char *device_id, int buflen)
{
	int rc;
	unsigned char *buf;

	if (buflen > 16)
		buflen = 16;
	buf = kzalloc(64, GFP_KERNEL);
	if (!buf)
		return -1;

	rc = linux_hpdsa_scsi_do_inquiry_one(h, HPVSA_INQUIRY, scsi3addr,
						buf, 64, VPD_PAGE | 0x83, TYPE_CMD);
	if (rc == 0)
		memcpy(device_id, &buf[8], buflen);
	kfree(buf);
	return rc != 0;
} /* hpdsa_get_device_id */

static int hpdsa_do_report_log_luns(struct ctlr_info *h,
					int bufsize, unsigned char *buf)
{
	struct CommandList *c;
	ErrorInfo_struct *ei;
	DECLARE_COMPLETION_ONSTACK(wait);
	unsigned long flags = 0;
	union u64bit tmp_addr64;
	int rc = 0;
	spin_lock_irqsave(&h->lock, flags);
#if defined(COMPILE_XEN)
	c = xen_alloc_command(h, 0);
#else
	c = alloc_command(h, 0);
#endif

	spin_unlock_irqrestore(&h->lock, flags);

	if (!c) {
		printk("%s: Could not get command\n", __func__);
		return -1;
	}

	populate_cmd(c, HPVSA_REPORT_LOG, h, buf, bufsize, 0, RAID_CTLR_LUNID, TYPE_CMD);

#if !defined(UBUNTU14)
	INIT_COMPLETION(wait);
#endif
	c->waiting = &wait;

	h->access.submit_command(h, c);

	/* and now we wait; */
	wait_for_completion(&wait);

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
	/*
	 * 32bit XEN kernels make it hard to change from a bus address back
	 * to a virtual address. So I avoid making a bus address.
	 * No DMA is done anyway.
	 */
#else
	if (likely(!iommu_is_enabled)) {
		tmp_addr64.val32.upper = c->SG[0].Addr.upper;
		tmp_addr64.val32.lower = c->SG[0].Addr.lower;
		pci_unmap_single(h->pcidev, (dma_addr_t) tmp_addr64.val, bufsize, c->direction);
	}
#endif

	ei = c->err_info;
	if (ei->CommandStatus != 0 && ei->CommandStatus != CMD_DATA_UNDERRUN) {
		/* hpdsa_scsi_interpret_error(c); */
		rc = -1;
	}

#if defined(COMPILE_XEN)
	xen_free_hpdsa_command(h, c, 0);
#else
	free_hpdsa_command(h, c, 0);
#endif

#if 0
	{
		int j = 0;
		printk("hpdsa_scsi_report_phys: "
				"ScsiStatus:0x%x CommandStatus:0x%x ",
				c->err_info->ScsiStatus,
				c->err_info->CommandStatus);
		for (j = 0; j < c->err_info->SenseLen; j++)
			printk("%02x", c->err_info->SenseInfo[j]);
		printk("\n");

		printk("============BUF==============\n");
		for (j = 0; j < bufsize; j++)
			printk("%02x", buf[j]);
		printk("\n");
	}
#endif
	return rc;

} /* hpdsa_do_report_log_luns */

/*
* Get phyical lun report
*/
static int hpdsa_do_report_phys_luns(struct ctlr_info *h,
					int bufsize, char *buf)
{
	struct CommandList *c;
	ErrorInfo_struct *ei;
	DECLARE_COMPLETION_ONSTACK(wait);
	unsigned long flags = 0;
	union u64bit tmp_addr64;
	int rc = 0;

	spin_lock_irqsave(&h->lock, flags);
#if defined(COMPILE_XEN)
	c = xen_alloc_command(h, 0);
#else
	c = alloc_command(h, 0);
#endif
	spin_unlock_irqrestore(&h->lock, flags);

	if (!c) {
		printk("%s: Could not allocate a command\n", __func__);
		return -1;
	}

	populate_cmd(c, HPVSA_REPORT_PHYS, h, buf, bufsize, 0, RAID_CTLR_LUNID, TYPE_CMD);

#if !defined(UBUNTU14)
	INIT_COMPLETION(wait);
#endif
	c->waiting = &wait;

	hpdsa_submit_command(h, c);

	/* and now we wait; */
	wait_for_completion(&wait);

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
	/*
	 * 32bit XEN kernels make it hard to change from a bus address back
	 * to virtual address. So I avoid making a bus address.
	 * No DMA is done anyway.
	 */
#else
	if (likely(!iommu_is_enabled)) {
		tmp_addr64.val32.upper = c->SG[0].Addr.upper;
		tmp_addr64.val32.lower = c->SG[0].Addr.lower;
		pci_unmap_single(h->pcidev, (dma_addr_t) tmp_addr64.val,
				bufsize, c->direction);
	}
#endif

	ei = c->err_info;
	if (ei->CommandStatus != 0 && ei->CommandStatus != CMD_DATA_UNDERRUN) {
		/* hpdsa_scsi_interpret_error(c); */
		rc = -1;
	}

#if defined(COMPILE_XEN)
	xen_free_hpdsa_command(h, c, 0);
#else
	free_hpdsa_command(h, c, 0);
#endif

	return rc;
} /* hpdsa_do_report_phys_luns */

/*
 * =====================================================================
 * Do an inquiry
 * =====================================================================
 */

static int linux_hpdsa_scsi_do_inquiry_one(struct ctlr_info *h, __u8 cmd,
					__u8 *scsi3addr,
					__u8 *buf,
					int bufsize,
					__u16 page,
					int cmd_type)
{
	struct CommandList *c;
	ErrorInfo_struct *ei;
	DECLARE_COMPLETION_ONSTACK(wait);
	unsigned long flags = 0;
	u64bit tmp_addr64;
	int rc = 0;

	if (NULL == h) {
		printk("%s: Contoller is NULL\n", __func__);
		return -1;
	}

	if (NULL == buf) {
		printk("%s: Buffer is NULL\n", __func__);
		bufsize = 0;
		return -1;
	}

	if (NULL == scsi3addr) {
		printk("%s: scsi3addr is NULL\n", __func__);
		return -1;
	}

	spin_lock_irqsave(&h->lock, flags);
#if defined(COMPILE_XEN)
	c = xen_alloc_command(h, 0);
#else
	c = alloc_command(h, 0);
#endif
	spin_unlock_irqrestore(&h->lock, flags);

	if (NULL == c) {
		printk("%s: Command is NULL\n", __func__);
		return -1;
	}

	populate_cmd(c, cmd, h, buf, bufsize, page, scsi3addr, cmd_type);

#if !defined(UBUNTU14)
	INIT_COMPLETION(wait);
#endif
	c->waiting = &wait;

	PTR_TO_U64(c->Header.Tag, c);
#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
	if (cmd == HPVSA_CACHE_FLUSH)
		c->Header.Tag.upper = 0x02;
#endif

	hpdsa_submit_command(h, c);

	rc = wait_for_completion_timeout(&wait, HPDSA_TIMEOUT);

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
	/*
	 * 32bit XEN kernels make it hard to change from a bus address back
	 * a to virtual address. So I avoid making a bus address.
	 * No DMA is done anyway.
	 */
#else
	if (likely(!iommu_is_enabled)) {
		if (bufsize > 0) {
			tmp_addr64.val32.upper = c->SG[0].Addr.upper;
			tmp_addr64.val32.lower = c->SG[0].Addr.lower;
			pci_unmap_single(h->pcidev, (dma_addr_t) tmp_addr64.val,
				bufsize, c->direction);
		}
	}
#endif
	if (rc == 0) { /* we did not get a response back */
		printk("%s: the command timed out\n", __func__);
		rc = -1;
	} else {
		rc = 0;
	}

	ei = c->err_info;
	if (ei->CommandStatus != 0 && ei->CommandStatus != CMD_DATA_UNDERRUN) {
		/*hpdsa_scsi_interpret_error(c); */
		printk("%s: cmdstatus = %d CMD_DATA_UNDERRUN = %d\n",
			__func__, ei->CommandStatus, CMD_DATA_UNDERRUN);
		rc = -1;
	}

#if defined(COMPILE_XEN)
	xen_free_hpdsa_command(h, c, 0);
#else
	free_hpdsa_command(h, c, 0);
#endif

	return rc;
} /* linux_hpdsa_scsi_do_inquiry_one */

static int hpdsa_wait_for_ready(struct ctlr_info *h, unsigned char *scsi3addr)
{
	int wait_time = 1;
	int current_attempts = 0;
	int retry_attempts = 20;
	int max_wait_seconds = 30;

	while (current_attempts < retry_attempts) {
		msleep(1000*wait_time);
		current_attempts++;

		if (wait_time < max_wait_seconds)
			wait_time = wait_time * 2;

		if (linux_hpdsa_scsi_do_inquiry_one(h, TEST_UNIT_READY,
					RAID_CTLR_LUNID,
					0, 0, 0, TYPE_CMD) == 0) {
			printk("hpdsa: Device has been successfully reset");
			return 0;
		}
	}
	printk("hpdsa: Device failed to become ready");
	return -1;
}

static int hpdsa_eh_device_reset_handler(struct scsi_cmnd *cmd)
{
	/*
	 * This is currently not supported on AHCI devices
	 */
#if 0
	int err_reset;
	int err_ready;
	struct ctlr_info *h;
	struct hpdsa_scsi_dev_t *scsi_dev;

	struct scsi_device	*scsidev = cmd->device;
	struct Scsi_Host	*shost = scsidev->host;


	h = (struct ctlr_info *) shost_priv(shost);

	scsi_dev = cmd->device->hostdata;

	if (!scsi_dev)
		return -1;

	err_reset = linux_hpdsa_scsi_do_inquiry_one(h, HPVSA_DEVICE_RESET_MSG,
			scsi_dev->scsi3addr, NULL, 0, 0, TYPE_MSG);
	err_ready = hpdsa_wait_for_ready(h, scsi_dev->scsi3addr);

	if (err_reset || err_ready)
		return -1;
#endif

	return SUCCESS;
}

/*
 * find an unused bus, target, lun for a new device.
 * assumes lock is held.
 */
static int
find_bus_target_lun(struct ctlr_info *h, int *bus, int *target, int *lun,
			 char *scsi3addr)
{
	int			i = 0;
	int			found = 0;
	unsigned char		target_taken[(HPVSA_MAX_SCSI_DEVS_PER_HBA)];

	memset(&target_taken[0], 0, (HPVSA_MAX_SCSI_DEVS_PER_HBA));

	target_taken[SELF_SCSI_ID] = 1;
	for (i = 0; i < hpdsa_scsi[h->ctlr_num].ndevices; i++)
		target_taken[hpdsa_scsi[h->ctlr_num].dev[i].target] = 1;

	for (i = 0; i < HPVSA_MAX_SCSI_DEVS_PER_HBA; i++) {
		if (!target_taken[i]) {
			if (memcmp(scsi3addr, RAID_CTLR_LUNID, 8) == 0) {
				*bus = 1;
				*target = 0;
				*lun = 0;
			} /* else if (scsi3addr[3] == 0) {
				printk("%d Setting bus to 2, target to %d\n", i, dvd_target);
				*bus = 1;
				*target = 0;
				*lun = ++ dvd_target; }*/
			 else {
				*bus = 0;
				*target = i;
				*lun = 0;
			}

			found = 1;
			break;
		}
	}
	return !found;
} /* find_bus_target_lun */

/* =============================================================================
 *  Add scsi device.
 * =============================================================================
 */
static int
hpdsa_scsi_add_entry(struct ctlr_info *h, int hostno,
		unsigned char *scsi3addr, unsigned char *device_id,
		int devtype, struct scsi2map *added, int *nadded,
		unsigned char raid_level)
{
	int n = hpdsa_scsi[h->ctlr_num].ndevices; /* empty slot */
	struct hpdsa_scsi_dev_t	*sd;

	if ((n >= HPVSA_MAX_SCSI_DEVS_PER_HBA) || (n < 0)) {
		printk(DRIVERNAME "%d: Too many devices, some will be"
				" inaccessible. (%d)\n", h->ctlr_num, n);
		return -1;
	}

	sd = &hpdsa_scsi[h->ctlr_num].dev[n];
	if (find_bus_target_lun(h, &sd->bus, &sd->target, &sd->lun,
				scsi3addr) != 0) {
		printk(DRIVERNAME "%d: find_bus_target_lun failed\n",
				h->ctlr_num);
		return -1;
	}
	memcpy(&sd->scsi3addr[0], scsi3addr, 8);
	memcpy(&sd->device_id, device_id, sizeof(sd->device_id));
	sd->devtype = devtype;
	sd->raid_level = raid_level;
	hpdsa_scsi[h->ctlr_num].ndevices++;
	sd->scsi2addr = ((sd->bus&0xFF) << 16) | ((sd->target&0xFF) << 8) |
		(sd->lun&0xFF);

	added[*nadded].bus = sd->bus;
	added[*nadded].target = sd->target;
	added[*nadded].lun = sd->lun;
	(*nadded)++;

	if (hostno != -1)
		printk(DRIVERNAME "%d: %s device added (b%dt%dl%d).\n",
				h->ctlr_num, DEVICETYPE(sd->devtype), sd->bus,
				sd->target, sd->lun);

	return 0;
} /* hpdsa_scsi_add_entry */
/* =============================================================================
* Fix botched adds.
* Called when scsi_add_device fails in order to re-adjust hpdsa_scsi[]
* to match the mid-layers view.
* ==============================================================================
*/
static void fixup_botched_add(struct ctlr_info *h, char *scsi3addr)
{
	unsigned long		flags;
	int			i;
	int			j;

	spin_lock_irqsave(&h->lock, flags);
	for (i = 0; i < hpdsa_scsi[h->ctlr_num].ndevices; i++) {
		if (memcmp(scsi3addr, hpdsa_scsi[h->ctlr_num].dev[i].scsi3addr, 8) == 0) {
			for (j = i; j < hpdsa_scsi[h->ctlr_num].ndevices - 1;
					j++)
				hpdsa_scsi[h->ctlr_num].dev[j] =
					hpdsa_scsi[h->ctlr_num].dev[j+1];
			hpdsa_scsi[h->ctlr_num].ndevices--;
			break;
		}
	}
	spin_unlock_irqrestore(&h->lock, flags);
}
/*
 * =============================================================================
 * Remove a scsi entry
 * Assumes lock is held
 * =============================================================================
 */
static void
hpdsa_scsi_remove_entry(struct ctlr_info *h, int hostno, int entry,
				struct scsi2map *removed, int *nremoved)
{
	int					i = 0;
	struct hpdsa_scsi_dev_t	*sd;

	if (entry < 0 || entry >= HPVSA_MAX_SCSI_DEVS_PER_HBA) {
		printk(DRIVERNAME "%d: invalid entry marked for deletion"
				" [%d].\n", h->ctlr_num, entry);
		return;
	}

	sd = &hpdsa_scsi[h->ctlr_num].dev[entry];

	removed[*nremoved].bus = sd->bus;
	removed[*nremoved].target = sd->target;
	removed[*nremoved].lun = sd->lun;
	(*nremoved)++;

	for (i = entry; i < hpdsa_scsi[h->ctlr_num].ndevices - 1; i++)
		hpdsa_scsi[h->ctlr_num].dev[i] =
			hpdsa_scsi[h->ctlr_num].dev[i+1];
	hpdsa_scsi[h->ctlr_num].ndevices--;

	printk(DRIVERNAME "%d %s setting device b%dt%dl%d for removal.\n",
			h->ctlr_num, DEVICETYPE(sd->devtype), sd->bus,
			sd->target, sd->lun);
} /* hpdsa_scsi_remove_entry */

static void hpdsa_map_single(struct ctlr_info *h, struct CommandList *c,
	unsigned char *buf, size_t buflen, u32 data_direction)
{

	u64bit tmp_addr64;
	struct pci_dev *pdev = h->pdev;

	if ((buflen == 0) || (data_direction == PCI_DMA_NONE)) {
		c->Header.SGList = 0;
		c->Header.SGTotal = 0;
		return;
	}
#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
	/*
	 * 32bit XEN kernels make it hard to change from a bus address back
	 * to avirtual address. So I avoid making a bus address.
	 * No DMA is done anyway.
	 */
	tmp_addr64.val = virt_to_bus(buf);
#else
	if (likely(!iommu_is_enabled)) {
		tmp_addr64.val = (u64) pci_map_single(pdev, buf, buflen, data_direction);
		DMA_MAPPING_ERROR(&pdev->dev, tmp_addr64.val);
	} else
		tmp_addr64.val = (u64) buf;
#endif

	c->ioctl_sg_virtual_addresses[0] = (unsigned long *)buf;

	c->SG[0].Addr.upper = tmp_addr64.val32.upper;
	c->SG[0].Addr.lower = tmp_addr64.val32.lower;
	c->SG[0].Len = buflen;
	c->SG[0].Ext = 0;

	c->Header.SGList = (u8) 1;
	c->Header.SGTotal = (u16) 1;

	PTR_TO_U64(c->Header.Tag, c);

} /* hpdsa_map_single */
/*
* ==============================================================================
* populate_cmd
* ==============================================================================
*/
static void populate_cmd(struct CommandList *c, u8 cmd, struct ctlr_info *h,
	unsigned char *buf, size_t size, u16 page_code, unsigned char *scsi3addr,
	int cmd_type)
{
	int pci_dir = XFER_NONE;

	c->cmd_type = CMD_IOCTL_PEND;
	c->Header.ReplyQueue = 0;
	if (buf != NULL && size > 0) {
		c->Header.SGList = 1;
		c->Header.SGTotal = 1;
	} else {
		c->Header.SGList = 0;
		c->Header.SGTotal = 0;
	}

	memcpy(c->Header.LUN.LunAddrBytes, scsi3addr, 8);

	c->Request.Type.Type = cmd_type;
	if (cmd_type == TYPE_CMD) {
		switch (cmd) {
		case HPVSA_INQUIRY:
			if (page_code & VPD_PAGE) {
				c->Request.CDB[1] = 0x01;
				c->Request.CDB[2] = (page_code & 0xff);
			}
			c->Request.CDBLen = 6;
			c->Request.Type.Attribute = ATTR_SIMPLE;
			c->Request.Type.Direction = XFER_READ;
			c->Request.Timeout = 0;
			c->Request.CDB[0] = HPVSA_INQUIRY;
			c->Request.CDB[4] = size & 0xFF;
			break;
		case HPVSA_REPORT_LOG:
		case HPVSA_REPORT_PHYS:
			/* It's a physical command
			 * mode = 00 target = 0.  Nothing to write.
			 */
			c->Request.CDBLen = 12;
			c->Request.Type.Attribute = ATTR_SIMPLE;
			c->Request.Type.Direction = XFER_READ;
			c->Request.Timeout = 0;
			c->Request.CDB[0] = cmd;
			c->Request.CDB[6] = (size >> 24) & 0xFF;
			c->Request.CDB[7] = (size >> 16) & 0xFF;
			c->Request.CDB[8] = (size >> 8) & 0xFF;
			c->Request.CDB[9] = size & 0xFF;
			break;
		case HPVSA_CACHE_FLUSH:
			c->Request.CDBLen = 12;
			c->Request.Type.Attribute = ATTR_SIMPLE;
			c->Request.Type.Direction = XFER_WRITE;
			c->Request.Timeout = 0;
			c->Request.CDB[0] = BMIC_WRITE;
			c->Request.CDB[6] = BMIC_CACHE_FLUSH;
			c->Request.CDB[7] = (size >> 8) & 0xFF;
			c->Request.CDB[8] = size & 0xFF;
			break;
		case TEST_UNIT_READY:
			c->Request.CDBLen = 6;
			c->Request.Type.Attribute = ATTR_SIMPLE;
			c->Request.Type.Direction = XFER_NONE;
			c->Request.Timeout = 0;
			break;
		default:
			printk(KERN_WARNING "unknown command 0x%c\n", cmd);
			BUG();
			return;
		}
	} else if (cmd_type == TYPE_MSG) {
		switch (cmd) {

		case  HPVSA_DEVICE_RESET_MSG:
			c->Request.CDBLen = 16;
			c->Request.Type.Type =  1; /* It is a MSG not a CMD */
			c->Request.Type.Attribute = ATTR_SIMPLE;
			c->Request.Type.Direction = XFER_NONE;
			c->Request.Timeout = 0; /* Don't time out */
			memset(&c->Request.CDB[0], 0, sizeof(c->Request.CDB));
			c->Request.CDB[0] =  cmd;
			c->Request.CDB[1] = 0x03;  /* Reset target above */
			/* If bytes 4-7 are zero, it means reset the */
			/* LunID device */
			c->Request.CDB[4] = 0x00;
			c->Request.CDB[5] = 0x00;
			c->Request.CDB[6] = 0x00;
			c->Request.CDB[7] = 0x00;
		break;

		default:
			printk(KERN_WARNING "unknown message type %d\n",
				cmd);
			BUG();
		}
	} else {
		printk(KERN_WARNING "unknown command type %d\n", cmd_type);
		BUG();
	}

	switch (c->Request.Type.Direction) {
	case XFER_READ:
		pci_dir = PCI_DMA_FROMDEVICE;
		break;
	case XFER_WRITE:
		pci_dir = PCI_DMA_TODEVICE;
		break;
	case XFER_NONE:
		pci_dir = PCI_DMA_NONE;
		break;
	default:
		pci_dir = PCI_DMA_BIDIRECTIONAL;
	}

	c->direction = pci_dir;

#if 0
{
	int j = 0;
	printk("============POP BEFORE INQ BUF==============\n");
	for (j = 0; j < size; j++)
		printk("%02x", buf[j]);
	printk("\n");
}
#endif
	hpdsa_map_single(h, c, buf, size, pci_dir);

	return;
} /* populate_cmd */
/*
* =============================================================================
* Update the list of scsi devices.
* =============================================================================
*/
static int
adjust_hpdsa_scsi_table(struct ctlr_info *h, int hostno,
				struct hpdsa_scsi_dev_t sd[],
				int nsds)
{
	int					i = 0;
	int					j = 0;
	int					found;
	int					changes = 0;
	struct hpdsa_scsi_dev_t			*csd = NULL;
	struct scsi2map				*added = NULL;
	struct scsi2map				*removed = NULL;
	struct Scsi_Host			*sh = NULL;
	int					nadded;
	int					nremoved;
	unsigned long				flags = 0;


	added = kzalloc(sizeof(*added) * HPVSA_MAX_SCSI_DEVS_PER_HBA,
			GFP_KERNEL);
	removed = kzalloc(sizeof(*removed) * HPVSA_MAX_SCSI_DEVS_PER_HBA,
			GFP_KERNEL);
	if (!added || !removed) {
		printk(DRIVERNAME "%d: Out of memory in adjust_hpdsa_scsi"
				"_table.\n", h->ctlr_num);
		goto free_and_out;
	}

	memset(added, 0, sizeof(*added) * HPVSA_MAX_SCSI_DEVS_PER_HBA);
	memset(removed, 0, sizeof(*added) * HPVSA_MAX_SCSI_DEVS_PER_HBA);

	spin_lock_irqsave(&h->lock, flags);

	if (hostno != -1) /* not the first time. */
		sh = h->scsi_host;

	DEBUGPRINT((0, "adjust_hpdsa_scsi_table: shost[%p]\n", sh));

	nremoved = 0;
	nadded = 0;
	while (i < hpdsa_scsi[h->ctlr_num].ndevices) {
		csd = &hpdsa_scsi[h->ctlr_num].dev[i];
		found = 0;
		for (j = 0; j < nsds; j++) {
			if (SCSI3ADDR_EQ(sd[j].scsi3addr, csd->scsi3addr)) {
				if (sd[j].devtype == csd->devtype)
					found = 2;
				else
					found = 1;
				break;
			}
		}

		if (found == 0) { /* device no longer present */
			changes++;
			printk(DRIVERNAME "%d  %s device removed "
					"[%02x%02x%02x%02x%02x%02x%02x%02x]\n",
					h->ctlr_num, DEVICETYPE(csd->devtype),
					csd->scsi3addr[0], csd->scsi3addr[1],
					csd->scsi3addr[2], csd->scsi3addr[3],
					csd->scsi3addr[4], csd->scsi3addr[5],
					csd->scsi3addr[6], csd->scsi3addr[7]);
			hpdsa_scsi_remove_entry(h, hostno, i, removed,
					&nremoved);
		} else if (found == 1) { /* device is different */
			changes++;
			printk(DRIVERNAME "%d: %s device changed.\n",
					h->ctlr_num, DEVICETYPE(csd->devtype));
			hpdsa_scsi_remove_entry(h, hostno, i, removed,
					 &nremoved);
			if (hpdsa_scsi_add_entry(h, hostno,
						&sd[j].scsi3addr[0],
						sd[j].device_id,
						sd[j].devtype,
						added,
						&nadded,
						sd[j].raid_level) != 0)
				BUG();
			csd->devtype = sd[j].devtype;
		} else
			i++; /* move along, move along... */
	} /* while */

	/* Now make sure that every device listed in sd[] is also listed in
	 * hpdsa_scsi, adding them if they are not found.
	*/

	for (i = 0; i < nsds; i++) {
		found = 0;
		for (j = 0; j < hpdsa_scsi[h->ctlr_num].ndevices; j++) {
			csd = &hpdsa_scsi[h->ctlr_num].dev[j];
			if (SCSI3ADDR_EQ(sd[i].scsi3addr, csd->scsi3addr)) {
				if (sd[i].devtype == csd->devtype)
					found = 2;
				else
					found = 1;
				break;
			}
		}
		if (!found) {
			changes++;
			if (hpdsa_scsi_add_entry(h, hostno,
						&sd[i].scsi3addr[0],
						sd[i].device_id,
						sd[i].devtype,
						added,
						&nadded,
						sd[i].raid_level) != 0) {
				printk(DRIVERNAME ": Error adding scsi entry\n");
				break;
			}
			DEBUGPRINT((0, "Called hpdsa_scsi_add_entry nadded[%d]\n", nadded));
		} else if (found == 1) { /* should never happen */
			changes++;
			printk(DRIVERNAME "%d: unexpected device type change.\n", h->ctlr_num);
		}
	} /* for */

	spin_unlock_irqrestore(&h->lock, flags);

	if (hostno == -1 || !changes) {
		printk(DRIVERNAME "%d:%sdevice changes detected.\n",
			 h->ctlr_num, ((changes) ? " " : " No "));
		goto free_and_out;
	}

	/* Notify scsi mid layer of any removed devices */
	for (i = 0; i < nremoved; i++) {
		DEBUGPRINT((0, "adjust_hpdsa_scsi_table:"
				" calling scsi_device_lookup shost[%p]"
				" bus[%02x target[%02x] lun[%02x]\n",
				sh, removed[i].bus, removed[i].target,
				removed[i].lun));
		struct scsi_device *sdev = scsi_device_lookup(sh,
				removed[i].bus, removed[i].target,
				removed[i].lun);
		if (sdev != NULL) {
			scsi_remove_device(sdev);
			scsi_device_put(sdev);
		} else {
			/*
			 * we do not expect to get here.
			 * future commands will get a selection timeout.
			*/
			printk(DRIVERNAME "%d did not find device b%dt%dl%d"
					" for removal.\n", h->ctlr_num,
					removed[i].bus, removed[i].target,
					removed[i].lun);
		} /* else */
	} /* for */

	/*
	 * Notify scsi mid layer of any added devices.
	 * printk("nadded[%d]\n", nadded);
	 */
	for (i = 0; i < nadded; i++) {
		int rc;
		if (sh == NULL)
			printk(DRIVERNAME ":Adding drive with no scsi host!\n");

		DEBUGPRINT((0, "%s: calling scsi_add_device\n", __func__));
		DEBUGPRINT((0, "%s: sh=%p\n", __func__, sh));
		DEBUGPRINT((0, "%s: bus=%d\n", __func__, added[i].bus));
		DEBUGPRINT((0, "%s: target=%d\n", __func__, added[i].target));
		DEBUGPRINT((0, "%s: lun=%d\n", __func__, added[i].lun));
		rc = scsi_add_device(sh, added[i].bus, added[i].target,
				added[i].lun);
		DEBUGPRINT((0, "%s: after calling scsi_add_device rc[%d]\n",
					__func__, rc));
		if (rc == 0) {
			struct scsi_device *sdev = scsi_device_lookup(sh,
					added[i].bus, added[i].target,
					added[i].lun);
			DEBUGPRINT((0, DRIVERNAME "%d: shost[%p]"
					" looked up sdev[%p] b%dt%dl%d\n",
					h->ctlr_num, sh, sdev, added[i].bus,
					added[i].target, added[i].lun));
			if (sdev) {
				/* If DVD, allow only 1 command to be queued. */
				if (sdev->type == TYPE_ROM) {
					scsi_adjust_queue_depth(sdev, 0, 1);
				}
				scsi_device_put(sdev);
			}

			printk(DRIVERNAME "%d: shost[%p] added b%dt%dl%d\n",
					h->ctlr_num, sh,
					added[i].bus, added[i].target,
					added[i].lun);

			continue;
		}
		printk(DRIVERNAME "%d: scsi_add_device of b%dt%dl%d failed.\n",
				h->ctlr_num, added[i].bus, added[i].target,
				added[i].lun);
		/* Now remove it from hpdsa_scsi[] since it is not in
		 * mid layer
		 */
		fixup_botched_add(h, added[i].scsi3addr);
	} /* for */

free_and_out:

	kfree(added);
	kfree(removed);

	return 0;
} /* adjust_hpdsa_scsi_table */
/*
* =============================================================================
* Update the map that translates from linux scsi to SA.
* =============================================================================
*/
static int hpdsa_adjust_scsi_device_map(struct ctlr_info *h)
{
	int			rc = 0;
	int			i = 0;
	u8			buf[HPVSA_MAX_SCSI_DEVS_PER_HBA * 8];
	u32			bufsize = sizeof(buf);
	u32			*pnumLuns;
	unsigned long		flags = 0;
	struct CommandList	*d;

	hpdsa_scsi[h->ctlr_num].ndevices = 0;

	spin_lock_irqsave(&h->lock, flags);
#if defined(COMPILE_XEN)
	d = xen_alloc_command(h, 0);
#else
	d = alloc_command(h, 0);
#endif
	spin_unlock_irqrestore(&h->lock, flags);

	if (!d) {
		printk("%s: Could not get a command\n", __func__);
		return -1;
	}

	memset(buf, 0, sizeof(buf));
	rc = hpdsa_do_report_log_luns(h, bufsize, buf);
	if (rc != 0)
		return rc;

	pnumLuns = (__u32 *) buf;
	*pnumLuns = __be32_to_cpu(*pnumLuns) >> 3;

	hpdsa_scsi[h->ctlr_num].ndevices = *pnumLuns + 1;

	if (hpdsa_scsi[h->ctlr_num].ndevices >
			HPVSA_MAX_SCSI_DEVS_PER_HBA) {
		printk(KERN_WARNING DRIVERNAME ": too many luns %d\n",
				hpdsa_scsi[h->ctlr_num].ndevices);
		hpdsa_scsi[h->ctlr_num].ndevices =
			HPVSA_MAX_SCSI_DEVS_PER_HBA;
	}

	DEBUGPRINT((0, "%s: nlogical_devices[%d] MAX_LUNS[%d]\n",
		__func__, hpdsa_scsi[h->ctlr_num].ndevices, MAX_LUNS));

	/*
	 * Add in luns starting at second row.
	 */
	for (i = 0; i < *pnumLuns; i++) {
		memcpy(hpdsa_scsi[h->ctlr_num].dev[i+1].scsi3addr,
				&buf[(i+1)*8], 8);
		hpdsa_scsi[h->ctlr_num].dev[i+1].scsi2addr = (i + 1) << 8;
	}

	/*
	 * Controller is first device in the list
	 */
	memset(hpdsa_scsi[h->ctlr_num].dev[0].scsi3addr, 0, 8);

	if (d) {
#if !defined(PROTECT_CMD_ALLOCATION)
		spin_lock_irqsave(&h->lock, flags);
#endif
#if defined(COMPILE_XEN)
		xen_free_hpdsa_command(h, d, 0);
#else
		free_hpdsa_command(h, d, 0);
#endif
#if !defined(PROTECT_CMD_ALLOCATION)
		spin_unlock_irqrestore(&h->lock, flags);
#endif
	}

	LINUX_DEBUG_PRINT("hpdsa_adjust_scsi_device_map: exiting\n");
	return rc;
} /* hpdsa_adjust_scsi_device_map */
/*
* =============================================================================
* Translate from linux scsi lun to SA lun
* =============================================================================
*/
static int
lookup_scsi3addr(struct ctlr_info *h, int bus, int target, int lun,
		char *scsi3addr)
{
	int i;

	__u32 scsi2addr = ((bus&0xFF) << 16) | ((target & 0xFF) << 8) | (lun & 0xFF);

	if (hpdsa_scsi[h->ctlr_num].ndevices >
			HPVSA_MAX_SCSI_DEVS_PER_HBA) {
		printk(KERN_WARNING DRIVERNAME ":lookup_scsi3addr:"
				" too many luns %d\n",
		hpdsa_scsi[h->ctlr_num].ndevices);
		hpdsa_scsi[h->ctlr_num].ndevices =
			HPVSA_MAX_SCSI_DEVS_PER_HBA;
	}

	/* May need to lock here if online ACU */
	for (i = 0; i < hpdsa_scsi[h->ctlr_num].ndevices; i++) {
		if (scsi2addr == hpdsa_scsi[h->ctlr_num].dev[i].scsi2addr) {
			memcpy(scsi3addr,
				hpdsa_scsi[h->ctlr_num].dev[i].scsi3addr, 8);
			/* May need to unlock here */
			return 0;
		}
	}
	/* may need to unlock here */
	return -1;
}
/*
 * =============================================================================
 * Update drivers list of disks
 * =============================================================================
 */
static inline int is_scsi_rev_5(struct ctlr_info *h)
{
	if (!h->hba_inquiry_data)
		return 0;
	if ((h->hba_inquiry_data[2] & 0x07) == 5)
		return 1;
	return 0;
}

#define SIZECCISSINQ 120
#define DEVIDLEN 16
static int hpdsa_update_disk_devices(struct ctlr_info *h, int hostno)
{
	int					rc = 0;
	int					i = 0;
	int					j = 0;
	int					nlogical_devices = 0;
	int					controller_index = 0;
	int					ncurrent = 0;
	unsigned long				flags = 0;
	u8					scsi3addr[8];
	u8					*inq_buff = NULL;
	u8					*raid_lvl_buf = NULL;
	ReportLunData_struct			*ld_buff = NULL;
	ReportLunData_struct			*phys_buff = NULL;
	ReportLunData_struct			*temp_buff = NULL;
	int					reportlunsize = PAGE_SIZE;
	struct hpdsa_scsi_dev_t			*currentsd = NULL;
	int					*pnumLuns;
	int					*p_phys_numLuns;
	int					count_dvd = 0;
	unsigned char				*raid_buffer = NULL;
	unsigned char				device_id[DEVIDLEN];

	spin_lock_irqsave(&h->lock, flags);
	if (h->busy_configuring) {
		printk(DRIVERNAME "%d: already configuring devices.\n",
				h->ctlr_num);
		spin_unlock_irqrestore(&h->lock, flags);
		return -1;
	}
	h->busy_configuring = 1;
	spin_unlock_irqrestore(&h->lock, flags);

	inq_buff = kmalloc(SIZECCISSINQ, GFP_KERNEL);
	if (!inq_buff)
		goto update_disk_devices_err;

	ld_buff = kmalloc(reportlunsize, GFP_KERNEL);
	if (!ld_buff)
		goto update_disk_devices_err;

	phys_buff = kmalloc(reportlunsize, GFP_KERNEL);
	if (!phys_buff)
		goto update_disk_devices_err;

	temp_buff = kmalloc(reportlunsize, GFP_KERNEL);
	if (!temp_buff)
		goto update_disk_devices_err;

	raid_buffer = kzalloc(SIZECCISSINQ, GFP_KERNEL);
	if (!raid_buffer)
		goto update_disk_devices_err;

	raid_lvl_buf = kzalloc(SIZECCISSINQ, GFP_KERNEL);
	if (!raid_lvl_buf)
		goto update_disk_devices_err;

	currentsd = kmalloc(sizeof(struct hpdsa_scsi_dev_t) *
			 HPVSA_MAX_SCSI_DEVS_PER_HBA, GFP_KERNEL);
	if (!currentsd)
		goto update_disk_devices_err;

	memset(currentsd, 0, sizeof(struct hpdsa_scsi_dev_t) *
			 HPVSA_MAX_SCSI_DEVS_PER_HBA);
	memset(ld_buff, 0, reportlunsize);
	memset(phys_buff, 0, reportlunsize);
	memset(inq_buff, 0, SIZECCISSINQ);

	/* Look for CD/DVD ROM devices. */

	DEBUGPRINT((0, "%s: Calling hpdsa_do_report_phys_luns\n", __func__));
	rc = hpdsa_do_report_phys_luns(h, reportlunsize, (char *)phys_buff);
	if (rc != 0) {
		printk(DRIVERNAME "%d: report physical failed\n", h->ctlr_num);
		spin_lock_irqsave(&h->lock, flags);
		h->busy_configuring = 0;
		spin_unlock_irqrestore(&h->lock, flags);
		if (inq_buff)
			kfree(inq_buff);
		if (ld_buff)
			kfree(ld_buff);
		if (phys_buff)
			kfree(phys_buff);
		if (currentsd)
			kfree(currentsd);
		if (temp_buff)
			kfree(temp_buff);
		if (raid_buffer)
			kfree(raid_buffer);
		if (raid_lvl_buf)
			kfree(raid_lvl_buf);
		return rc;
	}

	p_phys_numLuns = (__u32 *) &phys_buff->LUNListLength[0];
	*p_phys_numLuns = __be32_to_cpu(*p_phys_numLuns) >> 3;
	DEBUGPRINT((0, "Called report physical num = %d\n", *p_phys_numLuns));
	count_dvd = 0;
	for (i = 0; i < *p_phys_numLuns; i++) {
		DEBUGPRINT((0, "phys_buff[%d]->LUN[3] = %x\n", i,
					phys_buff->LUN[i][3]));
		if (phys_buff->LUN[i][3] == 0)
			++count_dvd;
	} /* for */

	/* Find all logical devices. */
	rc = hpdsa_do_report_log_luns(h, reportlunsize, (char *)ld_buff);
	if (rc != 0) {
		printk(DRIVERNAME "%d: report logical failed\n", h->ctlr_num);
		spin_lock_irqsave(&h->lock, flags);
		h->busy_configuring = 0;
		spin_unlock_irqrestore(&h->lock, flags);
		if (inq_buff)
			kfree(inq_buff);
		if (ld_buff)
			kfree(ld_buff);
		if (phys_buff)
			kfree(phys_buff);
		if (currentsd)
			kfree(currentsd);
		if (temp_buff)
			kfree(temp_buff);
		if (raid_buffer)
			kfree(raid_buffer);
		if (raid_lvl_buf)
			kfree(raid_lvl_buf);
		return rc;
	}

	pnumLuns = (__u32 *) &ld_buff->LUNListLength[0];
	*pnumLuns = __be32_to_cpu(*pnumLuns) >> 3;

	printk(DRIVERNAME "%d: Found %d scsi device(s)\n", h->ctlr_num, *
			pnumLuns);

	/* Add controller device */
	nlogical_devices = *pnumLuns + 1;

	if (nlogical_devices > HPVSA_MAX_SCSI_DEVS_PER_HBA) {
		printk(KERN_WARNING DRIVERNAME ": too many luns %d\n",
				nlogical_devices);
		nlogical_devices = HPVSA_MAX_SCSI_DEVS_PER_HBA;
	}

	/* Put in disks first for faster lookup, then CD/DVD devices,
	 *  then controller
	 */

	printk(DRIVERNAME ": Number of DVDs found %d\n", count_dvd);
	if (count_dvd) {

		/*
		 * Put Logical volumes at top
		 * Keep OS drives consistent.
		 *  Also during I/O lv lookups will be faster.
		*/
		for (i = 0; i < *pnumLuns; i++)
			memcpy(&temp_buff->LUN[i], &ld_buff->LUN[i],
					sizeof(ld_buff->LUN[0]));

		/* Add DVDs next */
		for (j = 0; j < *p_phys_numLuns; j++) {
			if (phys_buff->LUN[j][3] == 0) {
				memcpy(&temp_buff->LUN[i], &phys_buff->LUN[j],
						sizeof(ld_buff->LUN[0]));
				++i;
			}
		} /* for */

		/* Put the combined temp list back into the orig list. */
		nlogical_devices += count_dvd;
		for (i = 0; i < nlogical_devices; i++)
			memcpy(&ld_buff->LUN[i], &temp_buff->LUN[i],
				 sizeof(ld_buff->LUN[0]));
	} /* if */

	controller_index = nlogical_devices - 1;

	/* Put controller last in the list. */
	memset(&ld_buff->LUN[controller_index], 0, sizeof(ld_buff->LUN[0]));

	/* Inquire about each device. */
	ncurrent = 0;
	for (i = 0; i < nlogical_devices; i++) {
		int devtype = 0;

		/*
		 * Find out about each LUN.
		*/
		memset(inq_buff, 0, SIZECCISSINQ);
		memcpy(&scsi3addr[0], (char *)(ld_buff) + 8 + i * 8, 8);

		memset(inq_buff, 0xBB, SIZECCISSINQ);
		rc = linux_hpdsa_scsi_do_inquiry_one(h, HPVSA_INQUIRY,
				scsi3addr, inq_buff, SIZECCISSINQ, 0, TYPE_CMD);
		DEBUGPRINT((0, "%s: Called hpdsa_scsi_do_inquiry[%d] %x\n",
					__func__, rc, inq_buff[0]));
		if (rc != 0) {
			printk(DRIVERNAME ": inquiry failed\n");
			continue;
		}

		currentsd[ncurrent].devtype = devtype = (inq_buff[0] & 0x1f);

		memset(currentsd[ncurrent].device_id, ' ',
				sizeof(currentsd[ncurrent].device_id));
		if (devtype != 5) {
			rc = hpdsa_get_device_id(h, scsi3addr, device_id, DEVIDLEN);
			if (rc == 0)
				memcpy(currentsd[ncurrent].device_id,
					device_id,
					sizeof(currentsd[ncurrent].device_id));
		}

		memcpy(currentsd[ncurrent].scsi3addr, scsi3addr,
				sizeof(currentsd[ncurrent].scsi3addr));
		memcpy(currentsd[ncurrent].vendor, &inq_buff[8],
				sizeof(currentsd[ncurrent].vendor));
		memcpy(currentsd[ncurrent].model, &inq_buff[16],
				sizeof(currentsd[ncurrent].model));
		switch (devtype) {
		case 0:
			printk(DRIVERNAME "%d: Disk found[type=%d]\n",
					h->ctlr_num, devtype);
			/*Is this a logical device?*/
			if ((scsi3addr[3] & 0xC0) == 0x40) {
				rc = linux_hpdsa_scsi_do_inquiry_one(h,
						HPVSA_INQUIRY, scsi3addr,
						raid_lvl_buf, SIZECCISSINQ,
						0xC1, TYPE_CMD);
				if (rc != 0) {
					printk(DRIVERNAME ": inq failed\n");
					goto update_disk_devices_err;
				}

				currentsd[ncurrent].raid_level =
								raid_lvl_buf[8];

			} else {
				currentsd[ncurrent].raid_level = RAID_UNKNOWN;
			}

			break;
		case 3:
			printk(DRIVERNAME "%d: Processor found[type=%d]\n",
					h->ctlr_num, devtype);
			break;
		case 5:
			printk(DRIVERNAME "%d: Optical device found[type=%d]\n",
					h->ctlr_num, devtype);
			break;
		case 0x0C:
			printk(DRIVERNAME "%d: Controller found[type=%d]\n",
					h->ctlr_num, devtype);
			break;
		default:
			printk(DRIVERNAME "%d: bad device found[type=%d]\n",
					h->ctlr_num, devtype);
			continue;
		}

		if ((devtype != 0) && (devtype != 0x0C) && (devtype != 5)) {
			printk(DRIVERNAME "%d: Unsupported device type[%d]\n",
					h->ctlr_num, devtype);
			continue;
		}

		memcpy(&currentsd[ncurrent].scsi3addr[0], &scsi3addr[0], 8);
		currentsd[ncurrent].scsi2addr = -1;
		currentsd[ncurrent].devtype = devtype;
		currentsd[ncurrent].bus = -1;
		currentsd[ncurrent].target = -1;
		currentsd[ncurrent].lun = -1;

		ncurrent++;
	} /* for */

	adjust_hpdsa_scsi_table(h, hostno, currentsd, ncurrent);

update_disk_devices_err:
	if (inq_buff)
		kfree(inq_buff);
	if (ld_buff)
		kfree(ld_buff);
	if (phys_buff)
		kfree(phys_buff);
	if (currentsd)
		kfree(currentsd);
	if (temp_buff)
		kfree(temp_buff);
	if (raid_buffer)
		kfree(raid_buffer);
	if (raid_lvl_buf)
		kfree(raid_lvl_buf);

	spin_lock_irqsave(&h->lock, flags);
	h->busy_configuring = 0;
	spin_unlock_irqrestore(&h->lock, flags);

	return 0;
} /* hpdsa_update_disk_devices */
/*
 * AHCI init code
 */

/* fill out the HBA_REGISTER structs */

/* fill out the HBA_REGISTER structs */
static int hpdsa_set_ahci_memory_BAR(struct ctlr_info *c, int do_hba_reset)
{
	uint		abar_flags = 0UL;
	uint		flags_0 = 0UL;
	uint		flags_1 = 0UL;
	uint		flags_2 = 0UL;
	uint		flags_3 = 0UL;
	uint		flags_4 = 0UL;
	uint		abar_start_address = 0;
	uint		abar_end_address = 0;
	uint		abar_length = 0;

	flags_0 = pci_resource_flags(c->pdev, 0); /* PCI_BASE_ADDRESS_0); */
	flags_1 = pci_resource_flags(c->pdev, 1); /* PCI_BASE_ADDRESS_1); */
	flags_2 = pci_resource_flags(c->pdev, 2); /* PCI_BASE_ADDRESS_2); */
	flags_3 = pci_resource_flags(c->pdev, 3); /* PCI_BASE_ADDRESS_3); */
	flags_4 = pci_resource_flags(c->pdev, 4); /* PCI_BASE_ADDRESS_4); */
	abar_flags = pci_resource_flags(c->pdev, 5); /*PCI_BASE_ADDRESS_5); */
	abar_start_address = pci_resource_start(c->pdev, 5);
	abar_end_address = pci_resource_end(c->pdev, 5);

	if ((abar_start_address == 0) || (abar_end_address == 0)) {
		printk(DRIVERNAME "%d: Cannot get ABAR\n", c->ctlr);
		return -1;
	}

	/* Setup memory BAR for AHCI */
	c->paddr = abar_start_address;
	if (c->paddr == 0) {
		printk(DRIVERNAME "%d: Cannot map abar.\n", c->ctlr);
		return -1;
	}

	c->vaddr = ioremap_mem(abar_start_address,
				abar_end_address-abar_start_address+1);

	if (NULL == c->vaddr) {
		printk(DRIVERNAME "%d: Cannot map pci memory start[0x%08x]"
				" end[0x%08x]\n", c->ctlr, abar_start_address,
				abar_end_address);
		return -1;
	}

	return 0;
} /* hpdsa_set_ahci_memory_BAR */

/*
 * set commonly used config table values
 */
void set_config_data(struct ctlr_info *c)
{

	c->max_commands = (c->cfgtable)->CmdsOutMaxSimple;
	c->maxsgentries = (c->cfgtable)->Max_SG_Elements;

	/*
	 * BARF: No config table has been created yet for Hamer
	 *	AHCI only supports 32 s/g elements
	 */
	c->max_commands = 1024;
	c->maxsgentries = 32;

	DEBUGPRINT((0, DRIVERNAME "maxsgentries from config table[%d] \n",
				c->maxsgentries));

	c->max_cmd_sg_entries = MAXSGENTRIES;
	/*
	 * Stupid AHCI controller can only do 32 scatter/gather entries
	 */
	if (is_ahci_adapter(c->board_id)) {
		c->maxsgentries = MAXSGENTRIES;
		c->chainsize = 0;
	} else {
		c->chainsize = c->maxsgentries - c->max_cmd_sg_entries + 1;
	}
	c->nr_cmds = c->max_commands - 4;
#if defined(COMPILE_XEN)
	if (c->max_commands > 256)
		c->max_commands = 256;
	if (c->maxsgentries > 128)
		c->maxsgentries = 128;
	c->nr_cmds = c->max_commands - 4;
	c->chainsize = c->maxsgentries - c->max_cmd_sg_entries + 1;
#endif

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK) || !defined(CPU_64_BIT)
	c->max_commands = 256;
	c->nr_cmds = c->max_commands - 4;
	c->maxsgentries = MAXSGENTRIES;
	c->chainsize = 0;
#endif

	printk("%s: max_commands: %d \n maxsgentries %d \n", __func__,
			c->max_commands, c->maxsgentries);

	return;
}

static int hpdsa_ahci_interrupt_mode(struct ctlr_info *h)
{
	int		pos = 0;
	int		i = 0;
	int		err = -1;
	__u32		pci_check = 0x02;
	u16		control;

	for (i = 0; i < MAX_INTERRUPTS; i++) {
		h->hpdsa_msix_entries[i].vector = 0;
		h->hpdsa_msix_entries[i].entry = i;
		h->q[i] = (u8) i;
	}

#ifdef CONFIG_PCI_MSI

	pos = pci_find_capability(h->pdev, PCI_CAP_ID_MSIX);
	if (pos) {
		pci_read_config_word(h->pdev, msi_control_reg(pos), &control);
		h->num_msix_vectors = multi_msix_capable(control);

hpdsa_enable_ahci_msix:

		/*
		 * Need only enought msi-x vectors for each CPU
		 * May get less.
		 */
		h->num_msix_vectors = min(h->num_msix_vectors,
				(unsigned int) num_online_cpus());

		printk("%s: ctlr:%d number of msix entries is %d\n",
			DRIVERNAME, h->ctlr_num, h->num_msix_vectors);

		err = pci_enable_msix(h->pdev, h->hpdsa_msix_entries,
			h->num_msix_vectors);
		if (!err) {
			h->msix_vector = 1;
		} else if (err > 0) {
			h->num_msix_vectors = err;
			goto hpdsa_enable_ahci_msix;
		} else {
			printk(DRIVERNAME ": MSI-X init failed %d\n", err);
			h->num_msix_vectors = 0;
			h->msix_vector = 0;
			h->msi_vector = 0;
		}

		if (h->msix_vector) {
			printk(DRIVERNAME ": using MSIX\n");
			for (i = 0; i < h->num_msix_vectors; i++) {
				h->intr[i] = h->hpdsa_msix_entries[i].vector;
			}
			return 0;
		}
	} /* if (pci_find_capability(pdev, PCI_CAP_ID_MSIX)) */

	if (pci_find_capability(h->pdev, PCI_CAP_ID_MSI)) {
		if (!pci_enable_msi(h->pdev)) {
			printk(DRIVERNAME ": Using MSI\n");
			h->msi_vector = 1;
			h->msix_vector = 0;
			h->intr[h->intr_mode] = h->pdev->irq;
			h->num_msix_vectors = 0;
			return 0;
		} else {
			printk(DRIVERNAME ": MSI init failed\n");
		}
	}
#endif

	printk(DRIVERNAME "%d using IOAPIC\n", h->ctlr_num);
	h->num_msix_vectors = 0;
	h->msix_vector = 0;
	h->msi_vector = 0;
	h->intr[h->intr_mode] = h->pdev->irq;

	return 0;
} /* hpdsa_ahci_interrupt_mode */

int hpdsa_ahci_pci_init(struct ctlr_info *h)
{
	ushort		command = 0;
	int		err = -1;
	int		pos = 0;
	int		i = 0;
	__u32		pci_check = 0x02;
	u16		control;
	char		region[10];
	int		dac;

	if (!h->pdev) {
		printk(DRIVERNAME " %s: Could not get a pdev.\n", __func__);
		return -ENODEV;
	}

	err = pci_enable_device(h->pdev);
	if (err) {
		printk(DRIVERNAME " %s: Could not enable device.\n", __func__);
		return -ENODEV;
	}

	pci_set_master(h->pdev);

	sprintf(region, "hpdsa%01d", h->ctlr_num);
	err = pci_request_regions(h->pdev, AHCI_DRIVER_NAME);
	if (err) {
		printk(DRIVERNAME "%s: pci_request_regions failure", __func__);
		pci_disable_device(h->pdev);
		return -ENODEV;
	}

	h->product_name = "B140i";
	h->access = hpdsa_access;
	h->busy_initializing = 1;

	printk(DRIVERNAME ": subsystem vendor id[%x]\n",
						h->pdev->subsystem_vendor);
	printk(DRIVERNAME ": subsystem device[%x]\n",
						h->pdev->subsystem_device);

	err = hpdsa_ahci_interrupt_mode(h);
	if (err < 0) {
		err =  -ENODEV;
		goto err_out_disable_pdev;
	}

	err = hpdsa_set_ahci_memory_BAR(h, 0);
	if (err < 0) {
		err =  -ENODEV;
		goto err_out_disable_pdev;
	}

	err = hpdsa_ahci_request_irq(h);
	if (err < 0) {
		err =  -ENODEV;
		goto err_out_disable_pdev;
	}

	err = pci_set_dma_mask(h->pdev, DMA_BIT_MASK(64));
	if (err == 0) {
		dac = 1;
		printk("%s: Using 64bit DMA for %s\n", __func__, region);
	} else {
		err = pci_set_dma_mask(h->pdev, DMA_BIT_MASK(32));
		if (err == 0) {
			printk("%s: Using 32bit DMA\n", __func__);
			dac = 0;
		} else {
			printk("no suitable DMA available\n");
			goto err_out_disable_pdev;
		}
	} /* else */

	pci_set_drvdata(h->pdev, h);

	found_ahci_adapter = 1;

	return 0;

err_out_disable_pdev:

	return -1;
} /* hpdsa_ahci_pci_init */

static void hpdsa_hba_inquiry(struct ctlr_info *h)
{
	int rc = 0;

	if (!h->hba_inquiry_data)
		return;

	rc = linux_hpdsa_scsi_do_inquiry_one(h,
						HPVSA_INQUIRY,
						RAID_CTLR_LUNID,
						h->hba_inquiry_data,
						HBA_INQUIRY_BYTE_COUNT,
						0, TYPE_CMD);

}

int hpdsa_ahci_request_irq(struct ctlr_info *h)
{
	int			i;
	int			err = 0;

#ifdef CONFIG_PCI_MSI
	if (h->msix_vector) {
		printk("%s: Setting msix interrupts\n", __func__);
		for (i = 0; i < h->num_msix_vectors; i++) {
			if (request_irq(h->intr[i], do_hpdsa_hw_intr,
						SATA_MSIX_REQUEST_IRQ_FLAGS,
						h->devname, &h->q[i])) {
				printk(DRIVERNAME ": Unable to get msix" " irq %d for %s\n",
						h->intr[i], h->devname);
				goto cleanup;
			}
			printk("%s: h:%p Got msix irq %d for board id 0x%x name=%s\n",
				__func__, h, h->intr[i], h->board_id, h->devname);
		}
	} else if (h->msi_vector) {
			printk("%s: Setting msi interrupts\n", __func__);
			if (request_irq(h->intr[h->intr_mode],
					do_hpdsa_hw_intr,
					0,
					h->devname,
					&h->q[h->intr_mode])) {
				printk(DRIVERNAME ": Unable to get msi irq %d for %s\n",
						h->intr[h->intr_mode], h->devname);
				goto cleanup;
			}
			printk("%s: h:%p Got msi irq %d for board id 0x%x name=%s\n",
				__func__, h, h->intr[h->intr_mode], h->board_id, h->devname);
	} else { /* IOAPIC */
#endif
		printk(DRIVERNAME "%d: IOAPIC interrupts %d board_id=0x%x\n",
					h->ctlr_num, h->intr[h->intr_mode],
					h->board_id);
		if (request_irq(h->intr[h->intr_mode],
					do_hpdsa_ioapic_hw_intr,
					REQUEST_IRQ_FLAGS,
					h->devname,
					&h->q[h->intr_mode])) {
			printk(DRIVERNAME "Unable to get irq\n");
			goto cleanup;
		}

		printk("%s: h:%p Got legacy irq %d for board id 0x%x name=%s\n",
			__func__, h, h->intr[h->intr_mode],
			h->board_id, h->devname);
#ifdef CONFIG_PCI_MSI
	}
#endif

	return 1; /* succeed */

cleanup:
	return -ENODEV;
} /* hpdsa_ahci_request_irq */

/*
 * Handle HW interrupts
 */
static struct ctlr_info *vect_to_hba(unsigned char *vect)
{
	return container_of((vect - *vect), struct ctlr_info, q[0]);
}

DECLARE_INTERRUPT_HANDLER(do_hpdsa_b140i_hw_intr)
{
	struct ctlr_info *h = vect_to_hba(dev_id);
	unsigned char vect = *(unsigned char *) dev_id;
	u32 is_our_interrupt = 0;

	/* This is a real hardware interrupt */

#if defined(OSUSE11SP1)
	vect = 0;
#endif
	if (h->msix_vector)
		is_our_interrupt = HAL_LISR_MSIX(0, vect);
	else {
		/*
		 * This is a legacy hardware interrupt
		 * and we need the raidstack to be initialized
		 * before it can be processed.
		 */
		if (unlikely(!raid_application_loaded))
			return IRQ_NONE;
		is_our_interrupt = HAL_LISR_LEGACY(0, vect);
	}

	if (is_our_interrupt)
		return IRQ_HANDLED;
	else
		return IRQ_NONE;

} /* do_hpdsa_b140i_hw_intr */

DECLARE_INTERRUPT_HANDLER(do_hpdsa_ioapic_hw_intr)
{
	struct ctlr_info *h = vect_to_hba(dev_id);
	unsigned char vect = *(unsigned char *) dev_id;
	u32 is_our_interrupt = 0;
	/* This is a real hardware interrupt */
	if (unlikely(!raid_application_loaded))
		return IRQ_NONE;

	is_our_interrupt = h->isr(h->pal_root, 0xff);

	if (is_our_interrupt)
		return IRQ_HANDLED;
	else
		return IRQ_NONE;
} /* do_hpdsa_ioapic_hw_intr */

DECLARE_INTERRUPT_HANDLER(do_hpdsa_hw_intr)
{
	struct ctlr_info *h = vect_to_hba(dev_id);
	unsigned char vect = *(unsigned char *) dev_id;
	u32 is_our_interrupt = 0;

	/* This is a real hardware interrupt */
	if (unlikely(!raid_application_loaded))
		return IRQ_NONE;

#if defined(OSUSE11SP1)
	vect = 0;
#endif
	/*is_our_interrupt = PAL_AHCI_HwInterrupt(h->pal_root, vect);*/
	is_our_interrupt = h->isr(h->pal_root, vect);

	if (is_our_interrupt)
		return IRQ_HANDLED;
	else
		return IRQ_NONE;

} /* do_hpdsa_hw_intr */

struct scsi_device *hpdsa_find_scsi_device(struct ctlr_info *h)
{
	int i;
	unsigned long flags;
	struct hpdsa_scsi_dev_t *dev = NULL;
	struct scsi_device *scsi_dev;
	spin_lock_irqsave(&h->lock, flags);
	for (i = 0; i < hpdsa_scsi[h->ctlr_num].ndevices; i++) {
		if (memcmp(hpdsa_scsi[h->ctlr_num].dev[i].scsi3addr, RAID_CTLR_LUNID, 8) == 0) {
			dev = &hpdsa_scsi[h->ctlr_num].dev[i];
			break;
		}
	}
	spin_unlock_irqrestore(&h->lock, flags);
	if (NULL == dev) {
		printk(KERN_DEBUG "%s: could not find controller\n", __func__);
		return NULL;
	}

	scsi_dev = scsi_device_lookup(h->scsi_host, 1, dev->target, dev->lun);

	return scsi_dev;
}

void hpdsa_fill_out_pci_config_space(struct ctlr_info *h,
	 unsigned char *cs)
{
	int i;
	u8 v = '\0';

	for (i = 0; i < RAIDDRVR_PCI_CONFIG_SIZE; i++) {
		pci_read_config_byte(h->pdev, i, &v);
		cs[i] = (unsigned char) v;
	} /* for */

} /* hpdsa_fill_out_pci_config_space */

#define ONEGB 0x40000000ULL
#define FOURGB (ONEGB * 4ULL)
#define TWOGB (ONEGB * 2ULL)

#include <asm/processor.h>
int phys_addr_valid(resource_size_t addr)
{
#if !defined(SLES10)
#ifdef CONFIG_PHYS_ADDR_T_64BIT
	return !(addr >> boot_cpu_data.x86_phys_bits);
#else
	return 1;
#endif
#else /* It is SLES10 */
	return 1;
#endif /* SLES10 */
}

static int do_hpdsa_passthru(struct ctlr_info *ci, void __user *arg)
{
	IOCTL_Command_struct	iocommand;
	struct CommandList	*d;
	char			*buff = NULL;
	u64bit			temp64 = { {0, 0} };
	u64bit			*paddr64;
	unsigned long		flags;
	int			rc = 0;
	void __user 		*argp = (void __user *)arg;
	DECLARE_COMPLETION(wait);

	if (!arg)
		return -EINVAL;

	if (!capable(CAP_SYS_RAWIO))
		return -EPERM;

	if (copy_from_user
		(&iocommand, argp, sizeof(IOCTL_Command_struct)))
		return -EFAULT;

	if ((iocommand.buf_size < 1) &&
		(iocommand.Request.Type.Direction != XFER_NONE)) {
		return -EINVAL;
	}

	if (iocommand.buf_size > 0) {
		buff = kmalloc(iocommand.buf_size, GFP_KERNEL);
		if (buff == NULL)
			return -EFAULT;
	}

	if (iocommand.Request.Type.Direction & XFER_WRITE) {
		/* Copy the data into the buffer we created */
		if (copy_from_user
			(buff, iocommand.buf, iocommand.buf_size)) {
			kfree(buff);
			return -EFAULT;
		}
	} else {
		memset(buff, 0, iocommand.buf_size);
	}

	spin_lock_irqsave(&ci->lock, flags);
#if defined(COMPILE_XEN)
	d = xen_alloc_command(ci, 0);
#else
	d = alloc_command(ci, 0);
#endif
	spin_unlock_irqrestore(&ci->lock, flags);

	if (!d) {
		printk(DRIVERNAME ": Could not get cmd for ioctl\n");
		kfree(buff);
		return -ENOMEM;
	}

	d->cmd_type = CMD_TYPE_IOCTL;
	d->scsi_cmnd = buff;
	memcpy(d->Header.LUN.LunAddrBytes, iocommand.LUN_info.LunAddrBytes, 8);
	memcpy(&d->Request, &iocommand.Request, sizeof(d->Request));

	if (iocommand.buf_size > 0)	/* buffer to fill */
		d->Header.SGList = d->Header.SGTotal = 1;
	else				/* no buffers to fill */
		d->Header.SGList = d->Header.SGTotal = 0;

	/* Need to check cdb transfer size with buffer size. */
	d->SG[0].Len = iocommand.buf_size;

	/* Fill in the scatter gather information */
	if (iocommand.buf_size > 0) {
#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
		/*
		 * Using a special flag in the raidstack to just use memcpy
		 * instead of kmap_atomic to get a mapping to the virtual
		 * data buffer segments.
		 */
		temp64.val = virt_to_bus(buff);
#else
		d->Header.Tag.upper = 0x00;
		if (likely(!iommu_is_enabled)) {
			temp64.val = pci_map_single(ci->pcidev, buff,
						iocommand.buf_size,
						PCI_DMA_BIDIRECTIONAL);
			DMA_MAPPING_ERROR(&ci->pdev->dev, temp64.val);
		} else {
			temp64.val = (u64) buff;
		}
#endif
		d->ioctl_sg_virtual_addresses[0] = (unsigned long *)buff;
		d->SG[0].Addr.upper = temp64.val32.upper;
		d->SG[0].Addr.lower = temp64.val32.lower;
		d->SG[0].Len = iocommand.buf_size;
		d->SG[0].Ext = 0;
	}

	PTR_TO_U64(d->Header.Tag, d);

#if !defined(UBUNTU14)
	INIT_COMPLETION(wait);
#endif
	d->waiting = &wait;

	hpdsa_submit_command(ci, d);
	wait_for_completion(&wait);

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
#else
	/* unlock the buffers from DMA */
	if (likely(!iommu_is_enabled)) {
		pci_unmap_single(ci->pcidev, (dma_addr_t) temp64.val,
				iocommand.buf_size,
				PCI_DMA_BIDIRECTIONAL);
	}
#endif

	/* Copy the error information out */
	iocommand.error_info.ScsiStatus = d->err_info->ScsiStatus;
	iocommand.error_info.SenseLen = d->err_info->SenseLen;
	iocommand.error_info.CommandStatus = d->err_info->CommandStatus;
	iocommand.error_info.ResidualCnt = d->err_info->ResidualCnt;
	memcpy(&iocommand.error_info.MoreErrInfo,
		&d->err_info->MoreErrInfo, 8);
	memcpy(iocommand.error_info.SenseInfo,
		d->err_info->SenseInfo, 32);

	if (copy_to_user
		(argp, &iocommand, sizeof(IOCTL_Command_struct))) {
		rc = -EFAULT;
		goto complete_passthru_ioctl;
	}

	if (iocommand.Request.Type.Direction & XFER_READ) {
		/* Copy the data out of the buffer we created */
		if (copy_to_user
			(iocommand.buf, buff, iocommand.buf_size)) {
			rc = -EFAULT;
			goto complete_passthru_ioctl;
		}
	}

complete_passthru_ioctl:
	kfree(buff);
#if defined(COMPILE_XEN)
	xen_free_hpdsa_command(ci, d, 0);
#else
	free_hpdsa_command(ci, d, 0);
#endif
	return rc;
} /* do_hpdsa_passthru */

static int do_hpdsa_big_passthru(struct ctlr_info *ci, void __user *arg)
{
	void __user 		*argp = (void __user *)arg;
	BIG_IOCTL_Command_struct	*ioc;
	struct CommandList		*d = NULL;
	unsigned char			**buff = NULL;
	int				*buff_size = NULL;
	u64bit				temp64;
	u64bit				*paddr64;
	BYTE				sg_used = 0;
	int				status = 0;
	int				i;
	int				map = 0;
	__u32				left = 0;
	__u32				sz = 0;
	unsigned long			flags = 0;
	BYTE __user			*data_ptr;
	DECLARE_COMPLETION_ONSTACK(wait);

	if (!arg)
		return -EINVAL;
	if (!capable(CAP_SYS_RAWIO))
		return -EPERM;
	ioc = (BIG_IOCTL_Command_struct *)
		kmalloc(sizeof(*ioc), GFP_KERNEL);
	if (!ioc) {
		status = -ENOMEM;
		goto cleanup1;
	}
	if (copy_from_user(ioc, argp, sizeof(*ioc))) {
		status = -EFAULT;
		goto cleanup1;
	}
	if ((ioc->buf_size < 1) &&
		(ioc->Request.Type.Direction != XFER_NONE)) {
		status = -EINVAL;
		goto cleanup1;
	}
	/* Check kmalloc limits  using all SGs */
	if (ioc->malloc_size > MAX_KMALLOC_SIZE) {
		status = -EINVAL;
		goto cleanup1;
	}
	if (ioc->buf_size > ioc->malloc_size * MAXSGENTRIES) {
		status = -EINVAL;
		goto cleanup1;
	}

	spin_lock_irqsave(&ci->lock, flags);
#if defined(COMPILE_XEN)
	d = xen_alloc_command(ci, 0);
#else
	d = alloc_command(ci, 0);
#endif
	spin_unlock_irqrestore(&ci->lock, flags);

	if (!d) {
		printk(DRIVERNAME ": Could not get cmd for ioctl\n");
		kfree(buff);
		kfree(ioc);
		return -ENOMEM;
	}

	d->cmd_type = CMD_TYPE_IOCTL;
	memcpy(d->Header.LUN.LunAddrBytes, ioc->LUN_info.LunAddrBytes, 8);
	d->direction = ioc->Request.Type.Direction;
	memcpy(&d->Request, &ioc->Request, sizeof(d->Request));

	buff = kzalloc(MAXSGENTRIES * sizeof(char *), GFP_KERNEL);
	if (!buff) {
		status = -ENOMEM;
		goto cleanup1;
	}
	buff_size = (int *)kzalloc(MAXSGENTRIES * sizeof(int), GFP_KERNEL);
	if (!buff_size) {
		status = -ENOMEM;
		goto cleanup1;
	}

	left = ioc->buf_size;
	data_ptr = ioc->buf;
	sg_used = 0;
	while (left) {
		sz = (left > ioc->malloc_size) ? ioc->malloc_size : left;
		buff_size[sg_used] = sz;
		buff[sg_used] = kmalloc(sz, GFP_KERNEL);
		if (buff[sg_used] == NULL) {
			status = -ENOMEM;
			goto cleanup1;
		}
		if (ioc->Request.Type.Direction & XFER_WRITE) {
			if (copy_from_user
			(buff[sg_used], data_ptr, sz)) {
				status = -ENOMEM;
				goto cleanup1;
			}
		} else {
			memset(buff[sg_used], 0, sz);
		}
		left -= sz;
		data_ptr += sz;
		sg_used++;
	} /* while */
	d->scsi_cmnd = &buff[0];

	if (ioc->buf_size > 0)
		d->Header.SGList = d->Header.SGTotal = sg_used;
	else
		d->Header.SGList = d->Header.SGTotal = 0;


	/* Fill in the scatter gather information */
	if (ioc->buf_size > 0) {
		for (i = 0; i < sg_used; i++) {
#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
			/*
			 * Using a special flag in the raidstack to just use
			 * memcpy instead of kmap_atomic to get a mapping to
			 * the virtual data buffer segments.
			 */
			temp64.val = virt_to_bus(buff[i]);
#else
			d->Header.Tag.upper = 0x00;
			if (likely(!iommu_is_enabled)) {
				temp64.val = pci_map_single(ci->pcidev, buff[i],
						buff_size[i],
						PCI_DMA_BIDIRECTIONAL);
				DMA_MAPPING_ERROR(&ci->pdev->dev, temp64.val);
			} else
				temp64.val = (u64) buff[i];
#endif
			d->ioctl_sg_virtual_addresses[i] = (unsigned long *)buff[i];
			d->SG[i].Addr.upper = temp64.val32.upper;
			d->SG[i].Addr.lower = temp64.val32.lower;
			d->SG[i].Len = buff_size[i];
			d->SG[i].Ext = 0;
		} /* for */
	}

#if !defined(UBUNTU14)
	INIT_COMPLETION(wait);
#endif
	d->waiting = &wait;

	PTR_TO_U64(d->Header.Tag, d);
	hpdsa_submit_command(ci, d);
	wait_for_completion(&wait);

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
#else
	/* unlock the buffers from DMA */
	if (likely(!iommu_is_enabled)) {
		for (i = 0; i < sg_used; i++) {
			temp64.val32.upper = d->SG[i].Addr.upper;
			temp64.val32.lower = d->SG[i].Addr.lower;
			pci_unmap_single(ci->pcidev, (dma_addr_t) temp64.val,
					buff_size[i], PCI_DMA_BIDIRECTIONAL);
		}
	}
#endif

	/* Copy the error information out */
	ioc->error_info.ScsiStatus = d->err_info->ScsiStatus;
	ioc->error_info.SenseLen = d->err_info->SenseLen;
	ioc->error_info.CommandStatus = d->err_info->CommandStatus;
	ioc->error_info.ResidualCnt = d->err_info->ResidualCnt;
	memcpy(&ioc->error_info.MoreErrInfo, &d->err_info->MoreErrInfo, 8);
	memcpy(ioc->error_info.SenseInfo, d->err_info->SenseInfo, 32);
	if (copy_to_user(argp, ioc, sizeof(*ioc))) {
		free_hpdsa_command(ci, d, 0);
		d = NULL;
		status = -EFAULT;
		goto cleanup1;
	}
	if (ioc->Request.Type.Direction & XFER_READ) {
		/* Copy the data out of the buffer we created */
		BYTE __user *ptr = ioc->buf;
		for (i = 0; i < sg_used; i++) {
			if (copy_to_user
			(ptr, buff[i], buff_size[i])) {
				free_hpdsa_command(ci, d, 0);
				d = NULL;
				status = -EFAULT;
				goto cleanup1;
			}
			ptr += buff_size[i];
		} /* for */
}

cleanup1:
	if (d) {
#if defined(COMPILE_XEN)
		xen_free_hpdsa_command(ci, d, 0);
#else
		free_hpdsa_command(ci, d, 0);
#endif
	}


	if (buff) {
			for (i = 0; i < sg_used; i++)
				kfree(buff[i]);

			kfree(buff);

			kfree(buff_size);
	}
	kfree(ioc);

	return status;
} /* do_hpdsa_big_passthru */

static int increment_passthru_count(struct ctlr_info *h)
{
	unsigned long flags;

	spin_lock_irqsave(&h->passthru_count_lock, flags);
	if (h->passthru_count >= HPVSA_MAX_CONCURRENT_PASSTHRUS-4) {
		spin_unlock_irqrestore(&h->passthru_count_lock, flags);
		return -1;
	}
	h->passthru_count++;
	spin_unlock_irqrestore(&h->passthru_count_lock, flags);
	return 0;

}

static void decrement_passthru_count(struct ctlr_info *h)
{
	unsigned long flags;

	spin_lock_irqsave(&h->passthru_count_lock, flags);
	if (h->passthru_count <= 0) {
		spin_unlock_irqrestore(&h->passthru_count_lock, flags);
		/* not expecting to get here. */
		printk("Bug detected, passthru_count seems to be incorrect.\n");
		return;
	}
	h->passthru_count--;
	spin_unlock_irqrestore(&h->passthru_count_lock, flags);
}

/**
 * @brief ioctl interface to the driver, func pointer passed to scsi host
 * template.
 * @param[in] scsidev pointer to the scsi dev.
 * @param[in] cmd ioctl number.
 * @param[in] arg userspace pointer to read / write data from/ to.
 * @detail TODO need to figure out if this is the ciss.h ioctl stuff.
 *
 */
int hpdsa_ioctl(struct scsi_device *scsidev, int cmd,
			void __user *arg)
{

	struct Scsi_Host	*shost = scsidev->host;
	struct ctlr_info	*ci;
	void __user 		*argp = (void __user *)arg;
	int			rc = 0;

	ci = (struct ctlr_info *) shost->hostdata[0];

	switch (cmd) {
	case CCISS_GETPCIINFO:
		{
			cciss_pci_info_struct pciinfo;

			if (!arg)
				return -EINVAL;
			pciinfo.domain = pci_domain_nr(ci->pcidev->bus);
			pciinfo.bus = ci->pcidev->bus->number;
			pciinfo.dev_fn = ci->pcidev->devfn;
			pciinfo.board_id = ci->board_id;
			pciinfo.domain = 0x1f;
			pciinfo.domain = 0x00;
			if (copy_to_user
				(argp, &pciinfo, sizeof(cciss_pci_info_struct)))
				return -EFAULT;
			return 0;
		}
	case CCISS_GETINTINFO:
		{
			cciss_coalint_struct intinfo;
			if (!arg)
				return -EINVAL;
			intinfo.delay = 0;
			intinfo.count = 0;
			if (copy_to_user
				(argp, &intinfo, sizeof(cciss_coalint_struct)))
				return -EFAULT;
			return 0;
		}
	case CCISS_SETINTINFO:
		{
			cciss_coalint_struct intinfo;

			if (!arg)
				return -EINVAL;
			if (!capable(CAP_SYS_ADMIN))
				return -EPERM;
			if (copy_from_user
				(&intinfo, argp, sizeof(cciss_coalint_struct)))
				return -EFAULT;
			if ((intinfo.delay == 0) && (intinfo.count == 0)) {
				return -EINVAL;
			}
			return 0;
		}
	case CCISS_GETNODENAME:
		{
			NodeName_type NodeName;
			int i;

			if (!arg)
				return -EINVAL;
			for (i = 0; i < 16; i++)
				NodeName[i] = '\0';
			if (copy_to_user(argp, NodeName, sizeof(NodeName_type)))
				return -EFAULT;
			return 0;
		}
	case CCISS_SETNODENAME:
		{
			NodeName_type NodeName;

			if (!arg)
				return -EINVAL;

			if (!capable(CAP_SYS_ADMIN))
				return -EPERM;

			if (copy_from_user (NodeName, argp,
						sizeof(NodeName_type)))
				return -EFAULT;

			return 0;
		}

	case CCISS_GETHEARTBEAT:
		{
			Heartbeat_type heartbeat;

			if (!arg)
				return -EINVAL;
			heartbeat = 0;
			if (copy_to_user
				(argp, &heartbeat, sizeof(Heartbeat_type)))
				return -EFAULT;
			return 0;
		}
	case CCISS_GETBUSTYPES:
		{
			BusTypes_type BusTypes;

			if (!arg)
				return -EINVAL;
			BusTypes = 0;
			if (copy_to_user
				(argp, &BusTypes, sizeof(BusTypes_type)))
				return -EFAULT;
			return 0;
		}
	case CCISS_GETFIRMVER:
		{
			FirmwareVer_type firmware;

			if (!arg)
				return -EINVAL;

			if (ci->hba_inquiry_data)
				memcpy(firmware, &ci->hba_inquiry_data[32], 4);
			else
				memset(firmware, 0, 4);

			if (copy_to_user
				(argp, firmware, sizeof(FirmwareVer_type)))
				return -EFAULT;
			return 0;
		}
	case CCISS_GETDRIVVER:
		{
			DriverVer_type DriverVer;

			sscanf(HPVSA_DRIVER_VERSION, "%d", &DriverVer);

			if (!arg)
				return -EINVAL;

			if (copy_to_user
				(argp, &DriverVer, sizeof(DriverVer_type)))
				return -EFAULT;
			return 0;
		}

	case CCISS_REVALIDVOLS:
		hpdsa_update_disk_devices(ci, 1);
		return 0;

	case CCISS_GETLUNINFO:{
			LogvolInfo_struct luninfo;

			luninfo.LunID = shost->host_no;
			/* Kludged. To get number of opens:*/
			luninfo.num_opens = 1;
			luninfo.num_parts = 0;
			if (copy_to_user(argp, &luninfo,
					 sizeof(LogvolInfo_struct)))
				return -EFAULT;
			return 0;
		}
	case CCISS_DEREGDISK:
		hpdsa_update_disk_devices(ci, 1);
		return 0;

	case CCISS_REGNEWD:
		hpdsa_update_disk_devices(ci, 1);
		return 0;

	case CCISS_PASSTHRU:
		if (increment_passthru_count(ci))
			return -EAGAIN;
		rc = do_hpdsa_passthru(ci, arg);
		decrement_passthru_count(ci);
		return rc;
		break;
	case CCISS_BIG_PASSTHRU:
		if (increment_passthru_count(ci))
			return -EAGAIN;
		rc = do_hpdsa_big_passthru(ci, arg);
		decrement_passthru_count(ci);
		return rc;
		break;
	default:
		return -ENOTTY;
	}

	return -ENOIOCTLCMD;
}
/*
 * =============================================================================
 * Compat ioctls (32bit apps calling into 64bit driver
 * =============================================================================
 */
static int do_ioctl(struct scsi_device *dev, unsigned cmd, void __user *arg)
{
	int ret;
	LOCK_KERNEL
	ret = hpdsa_ioctl(dev, cmd, arg);
	UNLOCK_KERNEL
	return ret;
}

#ifdef CONFIG_COMPAT
static int hpdsa_ioctl32_passthru(struct scsi_device *dev, int cmd,
					void __user *arg);
static int hpdsa_ioctl32_big_passthru(struct scsi_device *dev, int cmd,
					void *arg);

/**
 * @brief 32bit comapt for the ciss ioctl interface
 * @param[in] dev the scsi device poitner from the mid layer
 * @param[in] cmd the ioctl command
 * @param[in] arg the pointer to the ioctl command
 */
static int hpdsa_compat_ioctl(struct scsi_device *dev, int cmd, void *arg)
{
	switch (cmd) {
	case CCISS_GETPCIINFO:
	case CCISS_GETINTINFO:
	case CCISS_SETINTINFO:
	case CCISS_GETNODENAME:
	case CCISS_SETNODENAME:
	case CCISS_GETHEARTBEAT:
	case CCISS_GETBUSTYPES:
	case CCISS_GETFIRMVER:
	case CCISS_GETDRIVVER:
	case CCISS_REVALIDVOLS:
	case CCISS_DEREGDISK:
	case CCISS_REGNEWDISK:
	case CCISS_REGNEWD:
	case CCISS_RESCANDISK:
	case CCISS_GETLUNINFO:
		DEBUGPRINT((0, "%s calling do_ioctl\n", __func__));
		return do_ioctl(dev, cmd, (void *)arg);
	case CCISS_PASSTHRU32:
		DEBUGPRINT((0, "hpdsa_compat_ioctl: calling"
					" hpdsa_ioctl32_passthru "
					"dev:%p cmd:%p arg:%p\n", dev, cmd,
					arg));
		return hpdsa_ioctl32_passthru(dev, cmd, arg);
	case CCISS_BIG_PASSTHRU32:
		DEBUGPRINT((0, "hpdsa_compat_ioctl: "
					"calling hpdsa_ioctl32_big_passthru"
					"dev:%p cmd:%p arg:%p\n", dev, cmd,
					arg));
		return hpdsa_ioctl32_big_passthru(dev, cmd, arg);
	default:
		DEBUGPRINT((0, "%s: BAD Ioctl cmd = 0x%x\n", __func__, cmd));
		return -ENOIOCTLCMD;
	}
}

static int hpdsa_ioctl32_passthru(struct scsi_device *dev, int cmd,
					void __user *arg)
{
	IOCTL32_Command_struct __user *arg32 = (IOCTL32_Command_struct __user *) arg;
	IOCTL_Command_struct arg64;
	IOCTL_Command_struct __user *p = hpdsa_alloc_user_space(sizeof(arg64));
	int err;
	u32 cp;

	err = 0;
	err |=
		copy_from_user(&arg64.LUN_info, &arg32->LUN_info,
				sizeof(arg64.LUN_info));
	err |=
		copy_from_user(&arg64.Request, &arg32->Request,
				sizeof(arg64.Request));
	err |=
		copy_from_user(&arg64.error_info, &arg32->error_info,
				sizeof(arg64.error_info));
	err |= get_user(arg64.buf_size, &arg32->buf_size);
	err |= get_user(cp, &arg32->buf);
	arg64.buf = compat_ptr(cp);
	err |= copy_to_user(p, &arg64, sizeof(arg64));

	if (err)
		return -EFAULT;

	DEBUGPRINT((0, "hpdsa_ioctl32_passthru: calling do_ioctl\n"));
	err = do_ioctl(dev, CCISS_PASSTHRU, (void *)p);
	if (err)
		return err;
	err |=
		copy_in_user(&arg32->error_info, &p->error_info,
			 sizeof(arg32->error_info));
	if (err)
		return -EFAULT;
	return err;
}

static int hpdsa_ioctl32_big_passthru(struct scsi_device *dev, int cmd,
						void __user *arg)
{
	BIG_IOCTL32_Command_struct __user *arg32 =
		(BIG_IOCTL32_Command_struct __user *) arg;
	BIG_IOCTL_Command_struct arg64;
	BIG_IOCTL_Command_struct __user *p = hpdsa_alloc_user_space(sizeof(arg64));
	int err;
	u32 cp;

	DEBUGPRINT((0, "%s: starting\n", __func__));

	err = 0;
	err |=
		copy_from_user(&arg64.LUN_info, &arg32->LUN_info,
				sizeof(arg64.LUN_info));
	err |=
		copy_from_user(&arg64.Request, &arg32->Request,
				sizeof(arg64.Request));
	err |=
		copy_from_user(&arg64.error_info, &arg32->error_info,
				sizeof(arg64.error_info));
	err |= get_user(arg64.buf_size, &arg32->buf_size);
	err |= get_user(arg64.malloc_size, &arg32->malloc_size);
	err |= get_user(cp, &arg32->buf);
	arg64.buf = compat_ptr(cp);
	err |= copy_to_user(p, &arg64, sizeof(arg64));

	if (err)
		return -EFAULT;

	DEBUGPRINT((0, "%s: calling real big passthru\n", __func__));
	err = do_ioctl(dev, CCISS_BIG_PASSTHRU, (void *)p);
	DEBUGPRINT((0, "%s: called real big passthru\n", __func__));
	if (err)
		return err;
	err |=
		copy_in_user(&arg32->error_info, &p->error_info,
				sizeof(arg32->error_info));
	DEBUGPRINT((0, "%s: returning\n", __func__));
	if (err)
		return -EFAULT;
	return err;
}
#endif /* COMPAT */

/*
 * Revectored raidstack functions
 * ACCESS functions start here
 * Send the command to the RAID stack
*/
static void hpdsa_submit_command(struct ctlr_info *h, struct CommandList *c)
{
	int co;
	int mo = h->max_outstanding;

	c->busaddr = (u32)c;
	raidstack.process_cmd(c);
	co = __sync_add_and_fetch(&h->commands_outstanding, 1);
	if (co > mo)
		(void) __sync_val_compare_and_swap(&h->max_outstanding,
				h->max_outstanding, h->commands_outstanding);
}

/*
 *   0 turns interrupts on...
 *   0x08 turns them off...
 */
static void hpdsa_intr_mask(struct ctlr_info *h, unsigned long val)
{
	if (val) { /* Turn interrupts on */
		h->interrupts_enabled = 1;
	} else { /* Turn them off */
		h->interrupts_enabled = 0;
	}
}

/*
 *  Returns true if fifo is full.
 *
 */
static unsigned long hpdsa_fifo_full(struct ctlr_info *h)
{
	if (h->commands_outstanding >= h->nr_cmds)
		return 1;
	else
		return 0;
}

/*
 *   returns value read from hardware.
 *     returns FIFO_EMPTY if there is nothing to read
 */
static unsigned long hpdsa_completed(struct ctlr_info *h)
{
	return 0;
}

unsigned long hpdsa_lock(struct ctlr_info *h)
{
	unsigned long flags = 0;

	OS_int_global_disable();
	return flags;
}

void hpdsa_unlock(struct ctlr_info *h, unsigned long flags)
{
	OS_int_global_enable();
}

/*
 *	Returns true if an interrupt is pending..
 */
static  int hpdsa_intr_pending(struct ctlr_info *h)
{
	return 0 ;
}


#ifdef HPBUILDTYPE
void HpDebugPrint(unsigned int DebugPrintLevel, char *DebugMessage, ...)
{
#ifdef CPU_64_BIT
	va_list ap;
	char		buffer[256];
	unsigned int	len = 0;

	va_start(ap, DebugMessage);

	len = vsnprintf(buffer, 256, DebugMessage, ap);

	if (len < 256) {
		if ((DebugPrintLevel == 0) ||
			((1 << DebugPrintLevel) & DEBUG_DRIVER_MASK))
			printk("%s: %s\n", __func__, buffer);
	} else {
		printk("debug buffer too long %d\n", len);
	}

	va_end(ap);
#else /* 32bit is broken */
#define DBG_BUFF_SIZE 120
	char		buffer[DBG_BUFF_SIZE];
	unsigned int	len = 0;
	va_list ap;

	if (DebugMessage && (strlen(DebugMessage) < DBG_BUFF_SIZE)) {
		va_start(ap, DebugMessage);
		len = vsnprintf(buffer, DBG_BUFF_SIZE, DebugMessage, ap);
	if ((len > 0) && (len <= DBG_BUFF_SIZE)) {
		if ((DebugPrintLevel == 0) ||
			((1 << DebugPrintLevel) & DEBUG_DRIVER_MASK))
			printk("%s: %s",  __func__, buffer);
	} else {
		printk("%s: invalid debug buffer size %d\n", __func__, len);
	}
	va_end(ap);
} else
	printk("%s: no debug buffer was passed\n", __func__);
#endif
}

#else

#endif /* HPBBUILDTYPE */

void interrupt_control(int flag, int msix_vector)
{
	int rq = 0;

	/*
	 * Need to find out which ReplyQueue interrupt came in on.
	 */

	switch (flag) {
	case 0:
		OS_int_global_disable();
		break;
	case 1:
		OS_int_global_enable();
		break;
	case 2:
		/* MSI-X disk interrupt */
#if !defined(OSUSE11SP1)
		rq = msix_vector;
#else
		rq = 0;
#endif
		PAL_LISR(0, rq);
		break;
	case 3:
		/*
		 * Cache interrupt. There are only 2 cache vectors.
		 * Do not have a cache device...yet.
		 */
		/* HAL_LISR(0, rq); */
		break;
	case 4:
		/* IOAPIC interrupts. */
		PAL_LISR(0, 0xff);
		break;
	default:
		printk("hpdsa: interrupt_control: Unknown flag of %d\n", flag);
	}
}
/*
 * To process Cache msix intr 0
 */
DECLARE_INTERRUPT_HANDLER(process_cache_adapter_msix_intr0)
{
	interrupt_control(0, 0);	/* Get raidstack lock */
	/* interrupt_control(3, 0); */	/* Let raidstack process interrupt */
	/* HAL_LISR(0, 1); */
	interrupt_control(1, 0);	/* Release raidstack lock */
	return IRQ_HANDLED;
};

/*
 * To process Cache msix intr 1, call stack_dump?
 */
DECLARE_INTERRUPT_HANDLER(process_cache_adapter_msix_intr1)
{
	interrupt_control(0, 0);	/* Get raidstack lock */
	/*interrupt_control(3, 0);	 Let raidstack process interrupt */
	/* HAL_LISR(0,0); */
	interrupt_control(1, 0);	/* Release raidstack lock */
	return IRQ_HANDLED;
};
/*
 * To process Cache APIC interrupt
 */
DECLARE_INTERRUPT_HANDLER(process_cache_adapter_ioapic_intr)
{
	struct ctlr_info *h = dev_id;
	unsigned int int_status;
	unsigned int *reg_ptr;

	/* Check if we have virtual mapped cache adapter register space */
	if (!h->cache_vaddr)
		return IRQ_NONE;

	/* Read wallace interrupt status register and determine if interrupt is
	 * ours
	 */
	reg_ptr = (unsigned int *) ((PTR_DTYPE)h->cache_vaddr +
		WALLACE_INT_STATUS_REG_OFFSET);
	int_status = readl(reg_ptr);
	if (!(int_status & WALLACE_INT_STATUS_MASK))
		return IRQ_NONE;

	interrupt_control(0, 0);        /* Get raidstack lock */
	/*
	 * since we had to read status register here,
	 * pass reg value so HAL layer does not have to re-read
	 *
	 * Note: There is a bug in raidstack process_cache_adapter
	 *       function. It does not clear the interrupt after
	 *       it is processed resulting in an interrupt storm
	 *       that impacts performance and cause a crash during
	 *       shutdown.
	 *
	 *       Thus by passing down 0 for the value of the status
	 *       register, the raidstack reads the register and
	 *       clears it.
	 */
	/*HAL_LISR(0, 0); */  /* Call HAL ISR handler */
	interrupt_control(1, 0);        /* Release raidstack lock */
	return IRQ_HANDLED;
} /* process_cache_adapter_ioapic_intr */

/*
 * Initialize B140I and Controller devices
 */

int hpdsa_init_raidstack(struct ctlr_info *h)
{
	int rc = 0;
	struct pci_dev *dev;
	int i = 0;

	h->flags = CTRL_INFO_FLAG_SW_RAID;

	if (is_sas_adapter(h->board_id)) {
#ifdef ASYNC_COMPLETION
		h->flags |= CTRL_INFO_FLAG_ASYNC_COMPLETION;
#endif
		found_sas_adapter = 1;
	}


	if (is_disk_adapter(h->board_id)) {
		if (vsa_lock_addr == NULL) {
			spin_lock_init(&vsa_lock);
			vsa_lock_addr = &vsa_lock;
		}

		/*
		* Get space for config table
		*/
		h->cfgtable = kzalloc(sizeof(CfgTable_struct), GFP_KERNEL);
		if (!h->cfgtable) {
			printk("%s: Couldn't get memory for" " cfgtable\n",
				__func__);
			return -1;
		} else {
			DEBUGPRINT((0, "%s: Got memory for cfgtable, address"
						" is 0x%p\n", __func__,
						h->cfgtable));
		}
	}

	DEBUGPRINT((0, "finish_init: found_ahci_adapter %d, "
			"found_sas_adapter %d, raid_application_loaded %d, "
			"h->board_id 0x%x\n",
			found_ahci_adapter, found_sas_adapter,
			raid_application_loaded, h->board_id));

	if ((initialized_cache_adapter || (!found_cache_adapter)) &&
		!raid_application_loaded) {
#ifdef SW_RAID_IBANEZ
		if (found_cache_adapter)
			enable_cache_adapter_intr(cache_ctlr_info->cache_vaddr);
#endif
		raidstack.init();
		get_ciss_config_table(h->cfgtable, sizeof(CfgTable_struct));
		printk("%s: h->cfgtable->Max_SG_Elements = %d\n", __func__,
			h->cfgtable->Max_SG_Elements);

		raid_application_loaded = 1;

		/*
		 * Wait for smart array fw to start.
		 */
		wait_for_sa_start();

		return 1;
	}
	return 0;
} /* hpdsa_init_raidstack */

/*
 * Allocate memory for commands and error info pools
 * Expects config table to have been mapped info memory
 */
static int hpdsa_alloc_mem(struct pci_dev *pdev,
					struct ctlr_info *h)
{
	int err = 0;
	int i = 0;

	h->cmd_pool = pci_alloc_consistent(pdev, sizeof(*h->cmd_pool) *
			h->nr_cmds,
			&h->CommandList_dhandle);

	h->pool_bits = kmalloc(((h->nr_cmds + BITS_PER_LONG - 1) /
			BITS_PER_LONG) * sizeof(unsigned long),
			GFP_KERNEL);


	h->errinfo_pool = pci_alloc_consistent(pdev, sizeof(*h->errinfo_pool) *
			h->nr_cmds, &h->ErrorInfo_dhandle);

	if (h->cmd_pool == NULL || h->errinfo_pool == NULL || h->pool_bits ==
		NULL) {
		printk("Unable to get memory for command lists.\n");
		return 0;
	}

	memset(h->pool_bits, 0, ((h->nr_cmds + BITS_PER_LONG-1)/BITS_PER_LONG) *
			sizeof(unsigned long));

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK) || !defined(CPU_64_BIT)
	/*
	 * 32bit XEN kernels need a local bounce buffer for the data.
	 */
	for (i = 0; i < h->nr_cmds; i++) {
		struct CommandList *c = h->cmd_pool + i;
		c->sg_buffer = kmalloc(XEN_32_SG_BUFSIZE, GFP_KERNEL);
	}
#endif

	err = hpdsa_alloc_sg_chain_blocks(h);
	if (!err)
		return -1;

	/*
	 * Need to track virtual addresses of each command
	 */
	err = hpdsa_alloc_sg_virtual_addresses(h);
	if (!err)
		return -1;

	err = hpdsa_alloc_scatterlist_buffers(h);
	if (!err)
		return -1;

	h->hba_inquiry_data = kmalloc(HBA_INQUIRY_BYTE_COUNT, GFP_KERNEL);
	if (!h->hba_inquiry_data)
		return -1;

	return 1;
}

static int hpdsa_alloc_scatterlist_buffers(struct ctlr_info *h)
{
	int i;
	int j;

	h->scatterlist_buffers = kzalloc((sizeof(*h->scatterlist_buffers) * h->nr_cmds), GFP_KERNEL);
	if (!h->scatterlist_buffers) {
		printk("%s: Cannot get sg buffers\n", __func__);
		return 0;
	}

	for (i = 0; i < h->nr_cmds; i++) {
		h->scatterlist_buffers[i] = kzalloc((sizeof(struct scatterlist) * h->maxsgentries),
							GFP_KERNEL);
		if (h->scatterlist_buffers[i] == NULL) {
			hpdsa_free_scatterlist_buffers(h);
			return 0;
		}
	}

	return 1;
} /* hpdsa_alloc_scatterlist_buffers */

static int hpdsa_alloc_sg_virtual_addresses(struct ctlr_info *h)
{
	int i;
	int j;

	h->sg_virtual_addresses = kzalloc(sizeof(*h->sg_virtual_addresses) *
						h->nr_cmds, GFP_KERNEL);
	if (!h->sg_virtual_addresses) {
		printk("%s: Cannot get sg virt. addresses\n", __func__);
		return 0;
	}

	for (i = 0; i < h->nr_cmds; i++) {
		h->sg_virtual_addresses[i] = kzalloc(
					(sizeof(void *) * h->maxsgentries),
					GFP_KERNEL); /* Chain pointer */
		if (h->sg_virtual_addresses[i] == NULL) {
			hpdsa_free_sg_virtual_addresses(h);
			return 0;
		}
	}

	for (i = 0; i < h->nr_cmds; i++)
		for (j = 0; j < h->maxsgentries; j++)
			h->sg_virtual_addresses[i][j] = (unsigned long)NULL;

	return 1;
} /* hpdsa_alloc_sg_virtual_addresses */

static void hpdsa_free_sg_virtual_addresses(struct ctlr_info *h)
{
	int i;

	if (h->sg_virtual_addresses == NULL)
		return;

	for (i = 0; i < h->nr_cmds; i++) {
		if (h->sg_virtual_addresses[i] != NULL) {
			kfree(h->sg_virtual_addresses[i]);
		}
	}

	kfree(h->sg_virtual_addresses);
	h->sg_virtual_addresses = NULL;
}

static void hpdsa_free_scatterlist_buffers(struct ctlr_info *h)
{
	int i;

	if (h->scatterlist_buffers == NULL)
		return
;
	for (i = 0; i < h->nr_cmds; i++) {
		if (h->scatterlist_buffers[i] != NULL) {
			kfree(h->scatterlist_buffers[i]);
		}
	}

	kfree(h->scatterlist_buffers);
	h->scatterlist_buffers = NULL;
}

static int hpdsa_alloc_sg_chain_blocks(struct ctlr_info *h)
{
	int i;

	if (h->chainsize <= 0)
		return 0;

	h->chained_sg_blocks = kzalloc(sizeof(*h->chained_sg_blocks) *
			h->nr_cmds, GFP_KERNEL);
	if (h->chained_sg_blocks == NULL)
		return 1;
	for (i = 0; i < h->nr_cmds; i++) {
		h->chained_sg_blocks[i] = kmalloc(
			sizeof(*h->chained_sg_blocks[i]) * h->chainsize,
			GFP_KERNEL);
		if (h->chained_sg_blocks[i] == NULL) {
			hpdsa_free_sg_chain_blocks(h);
			return 0;
		}
	}

	return 1;
}

static void hpdsa_free_sg_chain_blocks (struct ctlr_info *h)
{

	int i;

	if (h->chainsize <= 0)
		return;

	for (i = 0; i < h->nr_cmds; i++) {
		kfree(h->chained_sg_blocks[i]);
		h->chained_sg_blocks[i] = NULL;
	}

	kfree(h->chained_sg_blocks);
	h->chained_sg_blocks = NULL;
}

static int hpdsa_register_scsi_host(struct ctlr_info *h)
{
	struct		Scsi_Host *sh;
	int		error;

	sh = scsi_host_alloc(&hpdsa_driver_template,
			sizeof(struct ctlr_info *));
	if (sh == NULL)
		goto fail;

	sh->io_port = 0;
	sh->n_io_port = 0;
	sh->this_id = -1;
	sh->max_channel = 3;
	sh->max_cmd_len = MAX_COMMAND_SIZE;
	sh->max_lun = HPVSA_MAX_SCSI_DEVS_PER_HBA;
	sh->max_id = HPVSA_MAX_SCSI_DEVS_PER_HBA;

	/*
	 * Stupid AHCI cannot do more than 32 scatter/gather entries
	 */
	if (is_ahci_adapter(h->board_id)) {
		sh->sg_tablesize = MAXSGENTRIES;
		sh->max_sectors = 256;
	} else {
		sh->sg_tablesize = h->maxsgentries;
		sh->max_sectors = 2016; /* Some overhead for raidstack cache alg. */
	}

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK) || !defined(CPU_64_BIT)
	/*
	 * Tell scsi mid-layer that the max I/O size we can handle.
	 */
	sh->sg_tablesize = MAXSGENTRIES;
	sh->max_sectors = XEN_32_NUM_SECTORS;
#endif

	sh->can_queue = h->nr_cmds;
	sh->cmd_per_lun = h->nr_cmds;

	h->scsi_host = sh;	/* Store scsi host pointer. */

	sh->hostdata[0] = (unsigned long)h;
	sh->irq = h->intr[h->intr_mode];
	sh->unique_id = sh->irq;

	/*
	 * Make the device be the AHCI6 so s/g mapping is easier?
	 * Needs investigated. Use &ahci_6_ctlr_info->pcidev-dev?
	 */
	error = scsi_add_host(sh, &h->pcidev->dev);
	if (error)
		goto fail_host_put;

	hpdsa_initial_update_scsi_devices(h);

	scsi_scan_host(sh);

	return 1;

fail_host_put:
	scsi_host_put(sh);
fail:
	return 0;
}

/*
 * ===========================================================================
 * IO Functions
 *
 * scsi_queue_command
 * Complete SCSI requests
 *
 * ===========================================================================
 */

/*
 * This function will map the memory for the chain block into the dma
 * region of memory.
 */
static inline void
hpdsa_map_sg_chain_block(struct ctlr_info *h, struct CommandList *d)
{
	struct SGDescriptor *sg_block, *sg_link;
	union u64bit temp64;

	sg_link = &d->SG[h->max_cmd_sg_entries - 1];
	sg_block = h->chained_sg_blocks[d->cmdindex];
	sg_link->Ext = HPVSA_SG_CHAIN;
	sg_link->Len = sizeof(*sg_link) * (d->Header.SGTotal -
			h->max_cmd_sg_entries);

#if defined(GET_CISS_VIRT_ADDR_SUPPORT)
	temp64.val = (PTR_DTYPE)sg_block;
#else
#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
	/*
	 * Init or driver load time, these commands stay within the raidstack so
	 * we do not need to map them for DMA.
	 */
	temp64.val = virt_to_bus(sg_block);
#else
	if (likely(!iommu_is_enabled)) {
		temp64.val = pci_map_single(h->pdev, sg_block, sg_link->Len,
				PCI_DMA_TODEVICE);
		DMA_MAPPING_ERROR(&h->pdev->dev, temp64.val);
	} else
		temp64.val = sg_block;
#endif
#endif
	sg_link->Addr.upper = (u32) temp64.val32.upper;
	sg_link->Addr.lower = (u32) temp64.val32.lower;
}

static void hpdsa_unmap_sg_chain_blocks(struct ctlr_info *h,
					struct CommandList *d)
{
	struct SGDescriptor *sg_link;
	u64bit temp64;

	if (d->Header.SGTotal <= h->max_cmd_sg_entries)
		return;
	sg_link = &d->SG[h->max_cmd_sg_entries - 1];
	temp64.val32.lower = sg_link->Addr.lower;
	temp64.val32.upper = sg_link->Addr.upper;
#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
	/*
	 * We did not map, so no need to unmap.
	 */
#else
#if !defined(GET_CISS_VIRT_ADDR_SUPPORT)
	if (likely(!iommu_is_enabled)) {
		pci_unmap_single(h->pdev, temp64.val, sg_link->Len, PCI_DMA_TODEVICE);
	}
#endif
#endif
}
/*
 * =============================================================================
 * Translate linux s/g elements to sa interface.
 * =============================================================================
 */
#if KERNEL_HAS_SCSI_DMA_FUNCTIONS
static inline int
hpdsa_scatter_gather(struct CommandList *d,	struct scsi_cmnd *cmd,
						struct ctlr_info *h)
{
	unsigned int len;
	struct scatterlist *sg;
	union u64bit addr64;
	int use_sg = 0, i = 0, chained = 0;
	struct SGDescriptor *curr_sg;

	BUG_ON(scsi_sg_count(cmd) > h->maxsgentries);

	d->orig_use_sg = scsi_sg_count(cmd);
	if (likely(!iommu_is_enabled)) {
		use_sg = scsi_dma_map(cmd); /*how many are sent by scsi mid-layer */
	} else {
		use_sg = d->orig_use_sg;
	}

	if (use_sg < 0) {
		h->sg_virtual_addresses[d->cmdindex][0] = (unsigned long) NULL;
		return use_sg;
	}

	if (!use_sg) {
		h->sg_virtual_addresses[d->cmdindex][0] = (unsigned long) NULL;
		goto sglist_finished;
	}
	/* We need to know if we should chain a block or not
	 * if use_sg > h->max_sg_entries then we need to chain
	 */

	curr_sg = d->SG;
	chained = 0;

	/* cmd = the list
	 * sg =  current element in the list
	 * use_sg = number of segments
	 */
	d->used_sg_buffer = 0;
	scsi_for_each_sg(cmd, sg, use_sg, i) {
		if (i == h->max_cmd_sg_entries - 1 &&
			use_sg > h->max_cmd_sg_entries) {
			chained = 1;
			curr_sg = h->chained_sg_blocks[d->cmdindex];
		}
		/* curr_sg is now pointing into the arr of chain blocks
		 * via the array of ptrs
		 */
		h->sg_virtual_addresses[d->cmdindex][i] =
						(unsigned long) sg_virt(sg);
		if (iommu_is_enabled) {
			addr64.val = (__u64) sg_virt(sg);
			len  = sg->length;
		} else {
			addr64.val = (__u64) sg_dma_address(sg);
			len  = sg_dma_len(sg);
		}
		curr_sg->Addr.lower = addr64.val32.lower;
		curr_sg->Addr.upper = addr64.val32.upper;
		curr_sg->Len = len;
		curr_sg->Ext = 0;
		curr_sg++;
	}

	if (use_sg + chained > h->maxSG)
		h->maxSG = use_sg + chained;

	if (chained) {
		d->Header.SGList = h->max_cmd_sg_entries;
		d->Header.SGTotal = (u16) (use_sg + 1);
		hpdsa_map_sg_chain_block(h, d);
		return 0;
	}

sglist_finished:

	d->Header.SGList = (__u8) use_sg;   /* no. SGs contig in this cmd */
	d->Header.SGTotal = (__u16) use_sg; /* total sgs in this cmd list */
	return 0;

} /* hpdsa_scatter_gather */
#endif
/*
 * =============================================================================
 * Translate linux scsi commands to one that can be used by the sa interface
 * =============================================================================
 */
static int linux_scsi_middle_man(struct ctlr_info *h, struct scsi_cmnd *cmd,
					struct CommandList *d)
{
	int			rc = 0;

	/* Set the DMA direction */
	switch (cmd->sc_data_direction) {
	case DMA_TO_DEVICE:
		d->direction = XFER_WRITE;
		break;
	case DMA_FROM_DEVICE:
		d->direction = XFER_READ;
		break;
	case DMA_NONE:
		d->direction = XFER_NONE;
		break;
	case DMA_BIDIRECTIONAL:
		/*
		 * This can happen if a buggy application does a scsi passthru
		 * and sets both inlen and outlen to non-zero.
		 * (see * ../scsi/scsi_ioctl.c:scsi_ioctl_send_command())
		 */

		d->direction = XFER_RSVD;

		/*
		 * This is technically wrong, and cciss controllers should
		 * reject it with CMD_INVALID, which is the most correct
		 * response, but non-fibre backends appear to let it
		 * slide by, and give the same results as if this field
		 * were set correctly.  Either way is acceptable for
		 * our purposes here.
		 */

		break;

	default:
		printk("hpdsa: unknown data direction: %d\n",
			cmd->sc_data_direction);
		BUG();
		break;
	}

	d->Request.Type.Direction = d->direction;

	rc = hpdsa_scatter_gather(d, cmd, h);

	return rc;
} /* linux_scsi_middle_man */
/**
 * @brief scsi mid-layer calls this function to send I/O to the host
 * @detail The declaration of this function has changed as the kernel has been
 * updated. The formal declaration is in hvsa_kerenel_compat.h.
 * @param[in] cmd a pointer to the command to be processed.
 * @param[in] done a function pointer,I don't think it is used.
 */

DECLARE_QUEUECOMMAND(hpdsa_scsi_queue_command)
{
	int			rc = 0;
	struct ctlr_info	*h;
	__u8			scsi3addr[8];
	struct CommandList	*d;
	unsigned long		flags = 0;
	struct scsi_device	*scsidev = cmd->device;
	struct Scsi_Host	*shost = scsidev->host;
	struct hpdsa_scsi_dev_t *dev;

	if (unlikely(raid_shutting_down)) {
		cmd->result = DID_NO_CONNECT << 16;
		done(cmd);
		return 0;
	}

	if (bail_on_report_luns_if_no_scan_start(cmd, done))
		return 0;

	h = scsi_device_to_hba(cmd->device);

	if (!h) {
		printk("%s: no controller found\n", __func__);
		return 0;
	}

	/*
	 * Translate from scsi addr to cciss addr.
	 * Need to double check this function
	 */
	rc = lookup_scsi3addr(h, cmd->device->channel,
				cmd->device->id, cmd->device->lun, scsi3addr);

	/* did we find the device in our mapping? */
	if (rc != 0) {
		/* no, device is not in our mapping. */
		cmd->result = DID_NO_CONNECT << 16;
		done(cmd);
		return 0;
	}

	spin_lock_irqsave(&h->lock, flags);
	d = alloc_command(h, 1);
	spin_unlock_irqrestore(&h->lock, flags);

	if (!d) {
		printk(DRIVERNAME "%d: FIFO_FULL\n", h->ctlr_num);
		return SCSI_MLQUEUE_HOST_BUSY;
	}

	cmd->scsi_done = done; /* Save for later. */
	cmd->host_scribble = (unsigned char *)d;
	d->scsi_cmnd = cmd;
	d->done = (void *)done;
	d->cmd_type = CMD_SCSI;

	/*
	 * Use same processor to complete the command
	 * All this does is get us a number that is between 0 and the number of
	 * interrupts.
	 */
#if !defined(OSUSE11SP1)
	d->Header.ReplyQueue = ((h->num_msix_vectors > 1) ?
				(smp_processor_id() % h->num_msix_vectors) : 0);
#else
	d->Header.ReplyQueue = 0;
#endif
	memcpy(d->Header.LUN.LunAddrBytes, scsi3addr, 8);
	d->Request.Timeout = 0;
	memset(d->Request.CDB, 0, sizeof(d->Request.CDB));
	d->Request.CDBLen = cmd->cmd_len;
	memcpy(d->Request.CDB, cmd->cmnd, cmd->cmd_len);
	d->Request.Type.Type = TYPE_CMD;
	d->Request.Type.Attribute = ATTR_SIMPLE;

	d->cmd_aborted = 0;
	d->h = h;
	d->timeout = cmd->request->timeout;

	rc = linux_scsi_middle_man(h, cmd, d);
	if (rc) {
		free_hpdsa_command(h, d, 1);
		return SCSI_MLQUEUE_HOST_BUSY;
	}

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
	/*
	 * Since we are using our own local data buffer (local to driver)
	 * we set a flag to tell the raidstack not to do kmap_atomic
	 */
#endif
	hpdsa_submit_command(h, d);

	return 0;

} /* hpdsa_scsi_queue_command */

static void hpdsa_complete_scsi_command(struct CommandList *d)
{
	ErrorInfo_struct *ei = NULL;
	struct scsi_cmnd *cmd = NULL;
	struct ctlr_info *h = NULL;
	u64bit addr64;
	u64bit *paddr64;
	unsigned long flags = 0;
	int i;

	unsigned char sense_key = 0;
	unsigned char asc = 0;      /* additional sense code */
	unsigned char ascq = 0;     /* additional sense code qualifier */

	cmd = d->scsi_cmnd;
	h = d->h;
	ei = d->err_info;

#if defined(KERNEL_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK)
	/*
	 * We complete the 32bit XEN commands differently than the others.
	 * See hpdsa_kernel_compat.h
	 */
	complete_xen_command(h, d);
#else

#if !defined(CPU_64_BIT)
	if (d->used_sg_buffer)
		complete_xen_command(h, d);
#endif
	if (likely(!iommu_is_enabled))
		scsi_dma_unmap(cmd); /* undo the DMA mappings */
#endif

	if (d->Header.SGTotal > h->max_cmd_sg_entries)
		hpdsa_unmap_sg_chain_blocks(h, d);

	cmd->result = (DID_OK << 16);		/* host byte */
	cmd->result |= (COMMAND_COMPLETE << 8); /* msg byte */
	cmd->result |= (ei->ScsiStatus);

	memcpy(cmd->sense_buffer, ei->SenseInfo, ei->SenseLen > SCSI_SENSE_BUFFERSIZE ?
					SCSI_SENSE_BUFFERSIZE : ei->SenseLen);
					scsi_set_resid(cmd, ei->ResidualCnt);

	if (ei->CommandStatus == 0) {
		free_hpdsa_command(h, d, 1);
		cmd->scsi_done(cmd);
		return;
	}

	switch (ei->CommandStatus) {
	case CMD_TARGET_STATUS:
		/* Pass it up to upper layers */
		if (ei->ScsiStatus) {
			sense_key = 0xf & ei->SenseInfo[2];
			asc = ei->SenseInfo[12];
			ascq = ei->SenseInfo[13];
		}

		if (ei->ScsiStatus == SAM_STAT_CHECK_CONDITION) {
			if (sense_key == ILLEGAL_REQUEST) {
				/*
				 * SCSI REPORT_LUNS is commonly unsupported on
				 * Smart Array.  Suppress noisy complaint.
				 */
				if (cmd->cmnd[0] == REPORT_LUNS)
					break;

				/* If ASC/ASCQ indicate Logical Unit
				 * Not Supported condition,
				 */
				if (asc == 0x25 && (ascq == 0x00)) {
					printk("cmd %p has check condition\n",
						 d);
					break;
				}
			}
			if (sense_key == NOT_READY) {
				/* Optical Devices */
				if (asc == 0x3a && (ascq == 0x01))
					break;
				/* If Sense is Not Ready, Logical Unit
				 * Not ready, Manual Intervention
				 * required
				 */
				if ((asc == 0x04) && (ascq == 0x03)) {
					printk("cmd %p has check condition:"
						"unit not ready, manual "
						"intervention required\n", d);
					break;
				}
			}
			if (sense_key == ABORTED_COMMAND) {
				/* TUR */
				if ((asc == 0x28) && (ascq == 0x00))
					break;
				/* Aborted command is retryable */
				printk("cmd %p has check condition: aborted command: "
					"ASC: 0x%x, ASCQ: 0x%x\n",
					d, asc, ascq);
				cmd->result = DID_SOFT_ERROR << 16;
				break;
			}
			/* Must be some other type of check condition */
			break;
		}
		/* Problem was not a check condition
		 * Pass it up to the upper layers...
		 */
		if (ei->ScsiStatus) {
			printk("cmd %p has status 0x%x "
				"Sense: 0x%x, ASC: 0x%x, ASCQ: 0x%x, "
				"Returning result: 0x%x\n",
				d, ei->ScsiStatus,
				sense_key, asc, ascq,
				cmd->result);
		} else {
			printk("cmd %p SCSI status was 0. "
				"Returning no connection.\n", d);
			cmd->result = DID_NO_CONNECT << 16;
		}
		break;
	case CMD_DATA_UNDERRUN: /* let mid layer handle it */
		break;
	case CMD_DATA_OVERRUN: /* let mid layer handle it */
		printk("cmd %p has completed with data overrun "
				"reported\n", d);

		break;
	case CMD_INVALID:
		printk(DRIVERNAME ": invalid scsi command\n");
		cmd->result = DID_NO_CONNECT << 16;
		break;
	case CMD_PROTOCOL_ERR:
		cmd->result = DID_ERROR << 16;
		printk(DRIVERNAME ": command %p has protocol error\n", d);
		break;
	case CMD_HARDWARE_ERR:
		cmd->result = DID_ERROR << 16;
		printk(KERN_WARNING DRIVERNAME ": command %p had hardware error\n", d);
		break;
	case CMD_CONNECTION_LOST:
		cmd->result = DID_ERROR << 16;
		printk(KERN_WARNING DRIVERNAME ": command %p had connection lost\n", d);
		break;
	case CMD_ABORTED:
		cmd->result = DID_ABORT << 16;
		printk(KERN_WARNING DRIVERNAME ": command %p was aborted\n", d);
		break;
	case CMD_ABORT_FAILED:
		cmd->result = DID_ERROR << 16;
		printk(KERN_WARNING DRIVERNAME ": command %p reports abort failed\n", d);
		break;
	case CMD_UNSOLICITED_ABORT:
		cmd->result = DID_RESET << 16;
		printk(KERN_WARNING DRIVERNAME ": cmd %p aborted "
					"do to an unsolicited abort\n", d);
		break;
	case CMD_TIMEOUT:
		cmd->result = DID_TIME_OUT << 16;
		printk(KERN_WARNING DRIVERNAME ": command %p timedout\n", d);
		break;
	case CMD_UNABORTABLE:
		cmd->result = DID_ERROR << 16;
		break;
	default:
		cmd->result = DID_ERROR << 16;
		printk(KERN_WARNING DRIVERNAME ": cmd %p returned unknown status %x\n", d,
					ei->CommandStatus);
		for (i = 0; i < ei->SenseLen; i++)
			printk("%02x", cmd->sense_buffer[i]);
		printk("\nCDB:");
		for (i = 0; i < MAX_COMMAND_SIZE; i++)
			printk("%02x", cmd->cmnd[i]);
		printk("\n");
	} /* switch */

	/* This is called from interrupt context. */

	free_hpdsa_command(h, d, 1);

	cmd->scsi_done(cmd);

	return;
}

static inline void hpdsa_finish_cmd(struct CommandList *c, u32 raw_tag)
{
	if (likely(c->cmd_type == CMD_SCSI))
		hpdsa_complete_scsi_command(c);
	else if (c->cmd_type == CMD_IOCTL_PEND)
		complete(c->waiting);
} /* hpdsa_finish_cmd */

static inline u32 hpdsa_tag_contains_index(u32 tag)
{
#define DIRECT_LOOKUP_BIT 0x10
	return tag & DIRECT_LOOKUP_BIT;
}

static inline u32 hpdsa_tag_to_index(u32 tag)
{
#define DIRECT_LOOKUP_SHIFT 5
	return tag >> DIRECT_LOOKUP_SHIFT;
}

void linux_SaCompleteSrb(struct ctlr_info  *h, struct CommandList *c)
{

	unsigned long			flags = 0;
	u32				cmd_raw_tag = 0;

	/*
	 * FW returns pointer to the completed command
	 * So we should not have to search for it.
	 * But this may not be correct.
	 */


	(void) __sync_sub_and_fetch(&h->commands_outstanding, 1);

	spin_lock_irqsave(&h->lock, flags);

	hpdsa_finish_cmd(c, cmd_raw_tag);

	spin_unlock_irqrestore(&h->lock, flags);

	return;

} /* linux_SaCompleteSrb */

static void hpdsa_wake_up_scan_waiters(struct ctlr_info *h)
{
	unsigned long flags;

	spin_lock_irqsave(&h->scan_lock, flags);
	h->scan_finished = 1; /* mark scan as finished. */
	wake_up_all(&h->scan_wait_queue);
	spin_unlock_irqrestore(&h->scan_lock, flags);
} /* hpdsa_wake_up_scan_waiters */

static void hpdsa_scan_start(struct Scsi_Host *sh)
{
	struct ctlr_info *h = shost_to_hba(sh);
	unsigned long flags;

	/* wait until any scan already in progress is finished. */
	while (1) {
		spin_lock_irqsave(&h->scan_lock, flags);
		if (h->scan_finished)
			break;
		spin_unlock_irqrestore(&h->scan_lock, flags);
		wait_event(h->scan_wait_queue, h->scan_finished);
		/* Note: We don't need to worry about a race between this
		 * thread and driver unload because the midlayer will
		 * have incremented the reference count, so unload won't
		 * happen if we're in here.
		 */
	}

	h->scan_finished = 0; /* mark scan as in progress */
	spin_unlock_irqrestore(&h->scan_lock, flags);

	hpdsa_update_disk_devices(h, h->scsi_host->host_no);

	hpdsa_wake_up_scan_waiters(h);
}

static int hpdsa_scan_finished(struct Scsi_Host *sh,
	unsigned long elapsed_time)
{
	struct ctlr_info *h = shost_to_hba(sh);
	unsigned long flags;
	int finished;

	spin_lock_irqsave(&h->scan_lock, flags);
	finished = h->scan_finished;
	spin_unlock_irqrestore(&h->scan_lock, flags);
	return finished;
}
/*
 * =========================================================================
 * Initialization code
 * =========================================================================
 */
static int hpdsa_cache_pci_init(struct ctlr_info *h, struct pci_dev *pdev)
{
	ushort command = 0;
	u32 board_id;
	int err = 0;
	int i = 0;
	int dac = 0;
	int rc = 0;
	long curtime;
	PTR_DTYPE *paddr;
	ulong base_page_addr, offset;
	unsigned long register_value;
	unsigned long flags;
	char region[10];

	board_id = get_board_id(pdev);

	h->cache_pdev = cache_pdev;
	h->pdev = pdev;
	h->pcidev = pdev;
	cache_ctlr_info = h;

	/*
	 * Check to see if controller has been disabled
	 * BEFORE trying to enable it
	 */

	DEBUGPRINT((0, "%s: processing cache adapter ctlr_num = %d.\n",
			__func__, h->ctlr_num));

	err = pci_enable_device(pdev);
	if (err) {
		printk("%s: unable to enable PCI device\n", __func__);
		return err;
	}

	/* Enable bus mastering,could be disabled by pci_disable_device */
	pci_set_master(pdev);

	(void)pci_read_config_word(pdev, PCI_COMMAND, &command);

	if (!(command & 0x02)) {
		printk("%s: controller appears to be disabled 0x%x\n",
			__func__, command);
		return -ENODEV;
	}

	pci_set_drvdata(pdev, h);

	sprintf(region, "hpdsa%01d", h->ctlr_num);
	err = pci_request_regions(pdev, DRIVER_NAME);
	if (err) {
		printk("%s: cannot obtain PCI resources, aborting\n", __func__);
		return err;
	}

	/* configure PCI DMA stuff */
	err = pci_set_dma_mask(pdev, DMA_BIT_MASK(64));
	if (err == 0) {
		printk("%s: Using 64bit DMA\n", __func__);
		dac = 1;
	} else {
		err = pci_set_dma_mask(pdev, DMA_BIT_MASK(32));
		if (err == 0) {
			printk("%s: Using 32bit DMA\n", __func__);
			dac = 0;
		} else {
			printk("no suitable DMA available\n");
			return err;
		}
	} /* else */

	/* find the memory BAR */
	for (i = 0; i < DEVICE_COUNT_RESOURCE; i++) {
		if (pci_resource_flags(pdev, i) & IORESOURCE_MEM)
			break;
	}

	if (i == DEVICE_COUNT_RESOURCE) {
		printk("%s: no memory BAR found\n", __func__);
		err = -ENODEV;
		pci_release_regions(pdev);
		return err;
	}

	i = 2; /* Always do BAR 2 for Cache */
	/* addressing mode bits * already removed */
	paddr = (PTR_DTYPE *)pci_resource_start(pdev, i);
	if (!paddr)
		return -ENODEV;
	if (pci_resource_len(pdev, 2) <= 0)
		return -ENODEV;

	base_page_addr = ((ulong)paddr) & PAGE_MASK;
	offset = ((ulong)paddr) - base_page_addr;

	h->cache_vaddr = ioremap_mem(base_page_addr, pci_resource_len(pdev, 2));

	if (pci_find_capability(pdev, PCI_CAP_ID_MSIX)) {

		err = pci_enable_msix(pdev, cache_msix_entries, 2);
		if (!err) {
			DEBUGPRINT((0, "%s: MSIX capabilities enabled\n",
					__func__));
			err = request_irq(cache_msix_entries[1].vector,
					process_cache_adapter_msix_intr1,
					CACHE_MSIX_REQUEST_IRQ_FLAGS,
					h->devname, h);
			if (err)
				printk("%s:Can't get irq %d for msix vec1\n",
					__func__, cache_msix_entries[1].vector);

			err = request_irq(cache_msix_entries[0].vector,
					process_cache_adapter_msix_intr0,
					CACHE_MSIX_REQUEST_IRQ_FLAGS, h->devname, h);
			if (err)
				printk("%s: Cant get irq %d for msix vec 0\n",
					__func__,
					cache_msix_entries[0].vector);
			h->msix_vector = 1;
			goto hpdsa_cache_intr_success;
		}
	}

	printk("%s: pci_enable_msix failed, err is %d using IOAPIC\n",
		 __func__, err);
	h->msix_vector = 0;
	h->intr[0] = pdev->irq;
	h->intr[1] = pdev->irq;
	err = request_irq(h->intr[0],
				process_cache_adapter_ioapic_intr,
				CACHE_IOAPIC_REQUEST_IRQ_FLAGS,
				h->devname, h);
	if (err) {
		DEBUGPRINT((0, "%s: Unable to get irq %d "
				"for board id 0x%x\n",
			__func__, h->intr[1], h->board_id));
		return -1;
	}
hpdsa_cache_intr_success:
	cache_adapter_init_passed = 1;

	return 0;
} /* hpdsa_cache_pci_init */

/*
 * Initialize disk adapter pci information
 */

static int hpdsa_b140i_request_irq(struct ctlr_info *h)
{
	int i = 0;
	int rc = 0;
	int count = 0;

	if (h->msix_vector) {
		int count = 0;
		for (i = 0; i < h->num_msix_vectors; i++) {
			rc = request_irq(h->intr[i], do_hpdsa_b140i_hw_intr,
						0,
						h->devname, &h->q[i]);
			if (rc) {
				printk("%s: Can't get irq %d board id 0x%x\n",
					__func__, h->intr[i], h->board_id);
				continue;
			}

			++count;
		} /* for */

		if (!count)
			return -ENODEV;

		h->num_msix_vectors = count;

	} else if (h->msi_vector) {
		rc = request_irq(h->intr[h->intr_mode], do_hpdsa_b140i_hw_intr,
					0,
					h->devname, &h->q[h->intr_mode]);
		if (rc) {
			printk("%s: Unable to get irq %d for board id 0x%x\n",
				__func__, h->intr[i], h->board_id);
			return -ENODEV;
		}
	} else { /* IOAPIC */
		printk("%s: Setting up IOAPIC interrupts\n", __func__);
		rc = request_irq(h->intr[h->intr_mode],
					do_hpdsa_b140i_hw_intr,
					REQUEST_IRQ_FLAGS,
					h->devname, &h->q[h->intr_mode]);
		if (rc) {
			printk("%s: Unable to get irq %d for board id 0x%x\n",
				__func__, h->intr[h->intr_mode],
				h->board_id);
			return -ENODEV;
		}
	} /* else */

	return 0;

} /* hpdsa_b140i_request_irq */

static int hpdsa_b140i_interrupt_mode(struct ctlr_info *h)
{
	int i = 0;
	int pos = 0;
	int err = 0;
	int nr_entries = 0;
	u16 control = 0;

	for (i = 0; i < MAX_INTERRUPTS; i++) {
		h->hpdsa_msix_entries[i].vector = 0;
		h->hpdsa_msix_entries[i].entry = i;
		h->q[i] = i;
	}

	DEBUGPRINT((0, "%s: Calling pci_find_capability\n", __func__));
	pos = pci_find_capability(h->pdev, PCI_CAP_ID_MSIX);
	if (pos) {
		printk("%s: Iniializing MSIX\n", __func__);
		pci_read_config_word(h->pdev, msi_control_reg(pos), &control);
		h->num_msix_vectors = multi_msix_capable(control);

		/*
		 * Need only enough msi-x vectors for each CPU
		 */
		h->num_msix_vectors = min(h->num_msix_vectors,
					(unsigned int) num_online_cpus());

hpdsa_enable_b140i_msix:

		nr_entries = h->num_msix_vectors;

		printk("%s: number of msix entries is %d\n",
			__func__, nr_entries);

		err = pci_enable_msix(h->pdev, h->hpdsa_msix_entries,
					h->num_msix_vectors);
		if (!err) {
			h->msix_vector = 1;
		} else if (err > 0) {
			h->num_msix_vectors = err;
			goto hpdsa_enable_b140i_msix;
		} else if (err < 0) {
			printk("%s: MSI-X init failed, err %d, using IOAPIC\n",
				__func__, err);
			h->num_msix_vectors = 0;
			h->msix_vector = 0;
		}

		if (h->msix_vector) {
			for (i = 0; i < h->num_msix_vectors; i++) {
				h->intr[i] = h->hpdsa_msix_entries[i].vector;
			}
		} else {
			printk("%s: Falling back to IOAPIC\n", __func__);
			h->intr[h->intr_mode] = h->pdev->irq;
			h->num_msix_vectors = 0;
			h->msix_vector = 0;
			h->msi_vector = 0;
		}
	} else {
		printk("%s: MSIX not supported on 0x%x, using IOAPIC\n",
			__func__, get_board_id(h->pdev));
		h->num_msix_vectors = 0;
		h->msix_vector = 0;
		h->msi_vector = 0;
		h->intr[h->intr_mode] = h->pdev->irq;
	}

	return 0;

} /* hpdsa_b140i_interrupt_mode */

static int hpdsa_get_b140i_memory_BAR(struct ctlr_info *h)
{
	int i = 0;
	u32 size = 0;
	u32 end_address = 0;

	/* find the memory B140I BAR */
	for (i = 0; i < DEVICE_COUNT_RESOURCE; i++) {
		if (pci_resource_flags(h->pdev, i) & IORESOURCE_MEM)
		break;
	}

	if (i == DEVICE_COUNT_RESOURCE) {
		printk("%s: no memory BAR found for B140I adapter.\n", __func__);
		return  -ENODEV;
	}

	/* Setup memory BAR for B140I */
	h->paddr = pci_resource_start(h->pdev, i);
	end_address = pci_resource_end(h->pdev, i);
	size = pci_resource_len(h->pdev, i);

	h->vaddr = ioremap_mem(h->paddr, size);

	if (!h->vaddr) {
		printk("%s: Could not map memory BAR\n", __func__);
		return -ENODEV;
	}

	return 0;
} /* hpdsa_get_b140i_memory_BAR */

static int hpdsa_b140i_adapter_pci_init(struct ctlr_info *h)
{
	int num_vecs = 4;
	int pos, err = 0;
	u16 control;
	int i = 0;
	int dac = 0;
	int rc = 0;
	int return_value = 0;

	rc = pci_enable_device(h->pdev);
	if (rc) {
		printk("%s: pci_enable_device failure on board %x",
			 __func__, h->board_id);
		return_value = rc;
		goto b140i_adapter_pci_init_return;
	}

	/* Enable bus mastering,could be disabled by pci_disable_device */
	pci_set_master(h->pdev);

	rc = pci_request_regions(h->pdev, DRIVER_NAME);
	if (rc) {
		printk("%s: pci_request_regions failure", __func__);
		return_value = rc;
		goto b140i_adapter_pci_init_return;
	}

	rc = hpdsa_b140i_interrupt_mode(h);
	if (rc) {
		printk("%s: could not get interrupts\n", __func__);
		return_value = rc;
		goto b140i_adapter_pci_init_return;
	}

	rc = hpdsa_get_b140i_memory_BAR(h);
	if (rc) {
		printk("%s: could not get memory bar\n", __func__);
		return_value = rc;
		goto b140i_adapter_pci_init_return;
	}


	h->product_name = "B140i";
	h->access = hpdsa_access;

	rc = pci_set_dma_mask(h->pdev, DMA_BIT_MASK(64));
	if (rc == 0) {
		printk("%s: Using 64bit DMA\n", __func__);
		dac = 1;
	} else {
		rc = pci_set_dma_mask(h->pdev, DMA_BIT_MASK(32));
		if (rc == 0) {
			printk("%s: Using 32bit DMA\n", __func__);
			dac = 0;
		} else {
			printk("no suitable DMA available\n");
			return_value = rc;
			goto b140i_adapter_pci_init_return;
		}
	} /* else */

	pci_set_drvdata(h->pdev, h);

	return_value = hpdsa_b140i_request_irq(h);

	printk("%s: ====>Done with setting up board id 0x%x<====\n", __func__, h->board_id);

b140i_adapter_pci_init_return:

	return return_value;

} /* hpdsa_b140i_adapter_pci_init */

/*
 * Initialize disk adapter pci information
 */

static int hpdsa_sas_adapter_pci_init(struct ctlr_info *h)
{
	int num_vecs = 4;
	int nr_entries;
	int pos, err = 0;
	u16 control = 0;
	int i = 0;
	int dac = 0;
	int rc = 0;
	int return_value = 0;
	u32 end_address = 0;
	u32 size = 0;

	if (found_ahci_adapter) {
		DEBUGPRINT((0, "%s: LSI found and rejected, we have "
		"already found an HBA\n", __func__));
		return_value = -1;
		goto sas_adapter_pci_init_return;
	}

	for (i = 0; i < MAX_INTERRUPTS; i++) {
		h->hpdsa_msix_entries[i].vector = 0;
		h->hpdsa_msix_entries[i].entry = i;
		h->q[i] = i;
	}

	DEBUGPRINT((0, "%s: Initializing sas adpter pci info\n", __func__));

	pci_set_drvdata(h->pdev, h);

	rc = pci_enable_device(h->pdev);
	if (rc) {
		printk("%s: pci_enable_device failure on board %x",
			__func__, h->board_id);
		return_value = rc;
		goto sas_adapter_pci_init_return;
	}

	/* Enable bus mastering,could be disabled by pci_disable_device */
	pci_set_master(h->pdev);

	rc = pci_request_regions(h->pdev, DRIVER_NAME);
	if (rc) {
		printk("%s: pci_request_regions failure", __func__);
		return_value = rc;
		goto sas_adapter_pci_init_return;
	}
	DEBUGPRINT((0, "%s: Calling pci_find_capability\n", __func__));

	pos = pci_find_capability(h->pdev, PCI_CAP_ID_MSIX);
	if (pos) {
		DEBUGPRINT((0, "%s: Iniializing MSIX\n", __func__));

		pci_read_config_word(h->pdev, msi_control_reg(pos), &control);
		h->num_msix_vectors = multi_msix_capable(control);
		/*
		 * Need only enough msi-x vectors for each CPU
		 */
		h->num_msix_vectors = min(h->num_msix_vectors, (unsigned int) num_online_cpus());
hpdsa_enable_msix:
		nr_entries = h->num_msix_vectors;

		printk("%s: number of msix entries is %d\n", __func__, nr_entries);

		err = pci_enable_msix(h->pdev, h->hpdsa_msix_entries,
			 h->num_msix_vectors);
		if (!err) {
			DEBUGPRINT((0, "%s: line %d pci_enable_msix successful\n", __func__, __LINE__));
			h->msix_vector = 1;
		} else if (err > 0) {
			DEBUGPRINT((0, "%s: only %d MSI-X vectors " "available\n", __func__, err));
			h->num_msix_vectors = err;
			goto hpdsa_enable_msix;
		} else if (err < 0) {
			printk("%s: MSI-X init failed, err %d, using IOAPIC\n", __func__, err);
			h->num_msix_vectors = 0;
			h->msix_vector = 0;
		}

		if (h->msix_vector) {
			for (i = 0; i < h->num_msix_vectors; i++) {
				h->intr[i] = h->hpdsa_msix_entries[i].vector;
				DEBUGPRINT((0, "%s: h->intr[%d] = %d\n",
					 __func__, i, h->intr[i]));
			}
		} else {
			printk("%s: Falling back to IOAPIC\n", __func__);
			h->intr[h->intr_mode] = h->pdev->irq;
			h->num_msix_vectors = 0;
			h->msix_vector = 0;
			h->msi_vector = 0;
		}
	} else {
		printk("%s: MSIX not supported on this Dynamic Smart Array controller, using IOAPIC\n", __func__);
		h->num_msix_vectors = 0;
		h->msix_vector = 0;
		h->msi_vector = 0;
		h->intr[h->intr_mode] = h->pdev->irq;
	}

	if (h->msix_vector) {
		int count = 0;
		for (i = 0; i < h->num_msix_vectors; i++) {
			rc = request_irq(h->intr[i], do_hpdsa_hw_intr,
						SAS_MSIX_REQUEST_IRQ_FLAGS,
						h->devname, &h->q[i]);
			if (rc) {
				printk("%s: Unable to get irq %d"
					" for board id 0x%x\n",
					__func__, h->intr[i], h->board_id);
				continue;
			}

			++count;
		} /* for */

		h->num_msix_vectors = count;

	} else { /* IOAPIC */
			printk("%s: Setting up IOAPIC interrupts\n", __func__);
			rc = request_irq(h->intr[h->intr_mode],
						do_hpdsa_hw_intr,
						SAS_IOAPIC_REQUEST_IRQ_FLAGS,
						h->devname, &h->q[0]);
			if (rc) {
				printk("%s: Unable to get irq %d"
					" for board id 0x%x\n",
					__func__, h->intr[h->intr_mode],
					 h->board_id);
				return_value = -1;
				goto sas_adapter_pci_init_return;
			}
	}

	/* find the memory BAR */
	for (i = 0; i < DEVICE_COUNT_RESOURCE; i++) {
		if (pci_resource_flags(h->pdev, i) & IORESOURCE_MEM)
		break;
	}

	if (i == DEVICE_COUNT_RESOURCE) {
		printk("%s: no memory BAR found for SAS adapter.\n", __func__);
		return_value = -ENODEV;
		goto sas_adapter_pci_init_return;
	}

	/* Setup memory BAR for SAS adapter */
	h->paddr = pci_resource_start(h->pdev, i);
	end_address = pci_resource_end(h->pdev, i);
	size = end_address - h->paddr;

	h->vaddr = ioremap_mem(h->paddr, size);

	DEBUGPRINT((0, "%s: Setting up board id 0x%x\n", __func__, h->board_id));

	h->product_name = "B320i";
	h->access = hpdsa_access;

	rc = pci_set_dma_mask(h->pdev, DMA_BIT_MASK(64));
	if (rc == 0) {
		printk("%s: Using 64bit DMA\n", __func__);
		dac = 1;
	} else {
		rc = pci_set_dma_mask(h->pdev, DMA_BIT_MASK(32));
		if (rc == 0) {
			printk("%s: Using 32bit DMA\n", __func__);
			dac = 0;
		} else {
			printk("no suitable DMA available\n");
			return_value = rc;
			goto sas_adapter_pci_init_return;
		}
	} /* else */

	DEBUGPRINT((0, "%s: Done with setting up board id 0x%x\n",
			 __func__, h->board_id));

sas_adapter_pci_init_return:

	return return_value;

} /* hpdsa_sas_adapter_pci_init */

struct ctlr_info *alloc_hba_structure(struct pci_dev *pdev)
{
	int i;
	struct ctlr_info *h = NULL;
	ushort command;
	u32 board_id;

	board_id = get_board_id(pdev);
	printk("%s: board_id = 0x%x\n", __func__, board_id);

	/* Find the first hba[] slot that's empty. */
	for (i = 0; i < MAX_CTLRS; i++)
		if (hpdsa_hba[i] == NULL)
			break;

	if (i >= MAX_CTLRS) {
		printk(DRIVERNAME ": could not allocate controller memory.\n");
		return NULL;
	}

	/* Allocate an hba structure */
	h = kzalloc(sizeof(struct ctlr_info), GFP_KERNEL);

	if (h == NULL) {
		printk("%s: Could not get memory for controller.\n", __func__);
		return NULL;
	}

	hpdsa_hba[i] = h;

	h->board_id = board_id;
	h->ctlr_num = i;
	h->ctlr = i;
	h->pcidev = h->pdev = pdev;
	h->hba_pdev = pdev;
	h->intr_mode = PERF_MODE_INT; /* Vector 0 */
	hpdsa_scsi[h->ctlr_num].ndevices = 0;

	sprintf(h->devname, "hpdsa%d", i);

	return h;
} /* alloc_hba_structure */

static u32 get_board_id(struct pci_dev *pdev)
{
	return ((u32) (pdev->subsystem_device << 16) & 0xffff0000) |
			pdev->subsystem_vendor;
} /* get_board_id */

static int hpdsa_init_scsi_driver(struct pci_dev *pdev, struct ctlr_info *h)
{
	int rc;
	unsigned long flags = 0;

	if (raid_application_loaded == 0) {
		printk(DRIVERNAME ": raidstack did not load\n");
		return -1;
	}

	set_config_data(h);

	if (!hpdsa_alloc_mem(pdev, h)) {
		printk(DRIVERNAME ": Unable to get memory, exiting\n");
		return -ENOMEM;
	}

	/* Register host with SCSI. */
	rc = hpdsa_register_scsi_host(h);

	if (!rc) {
		printk("hpahcisr: Unable to register scsi host\n");
		goto cleanup4;
	}

	hpdsa_procinit();

	hpdsa_driver_loaded = 1;

	hpdsa_hba_inquiry(h);

	printk("hpdsa - driver version:%s\n", HPVSA_DRIVER_VERSION);
	if (h->hba_inquiry_data)
		printk("hpdsa - raidstack version:%c%c%c%c%c\n",
		h->hba_inquiry_data[32],
		h->hba_inquiry_data[33],
		h->hba_inquiry_data[34],
		h->hba_inquiry_data[35],
		h->hba_inquiry_data[36]);

	DEBUGPRINT((0, DRIVERNAME "%d: init completed.\n", h->ctlr_num));

	return 1; /* succeed */

cleanup4:
	return -1;
} /* hpdsa_init_scsi_driver */

static void hpdsa_init_error_cleanup(struct pci_dev *pdev, struct ctlr_info *h)
{

	hpdsa_shutdown_raidstack_and_cleanup(h);

	hpdsa_cleanup_interrupts_and_msix(h);

	/* TBD - cleanup drive queues */
	if (cache_pdev) {
		pci_release_regions(cache_pdev);
		cache_pdev = NULL;
	}

	if (proc_hpdsa)
		hpdsa_cleanup_procfs();

	pci_release_regions(pdev);
	pci_set_drvdata(pdev, NULL);

	hpdsa_cleanup_memory(h);

	kfree(h);
} /* hpdsa_init_error_cleanup */

/*
 * Find out if iommu is enabled
 */
static void determine_if_iommu_is_enabled(struct ctlr_info *h)
{
	struct ctlr_info *iommu1 = NULL;;
	struct ctlr_info *iommu2 = NULL;;

	iommu_is_enabled = 0;

	if (b140i_ctlr_info) {
		iommu1 = b140i_ctlr_info;
		printk("%s: using GLP4\n", __func__);
	} else if (ahci_8_ctlr_info) {
		iommu1 = ahci_8_ctlr_info;
		printk("%s: using WB8\n", __func__);
	} else if (ahci_6_ctlr_info) {
		iommu1 = ahci_6_ctlr_info;
		printk("%s: using WB6\n", __func__);
	}

	if (ahci_4_ctlr_info) {
		iommu2 = ahci_4_ctlr_info;
		printk("%s: using WB4\n", __func__);
	} else if (ahci_6_ctlr_info) {
		iommu2 = ahci_6_ctlr_info;
		printk("%s: using WB6\n", __func__);
	} else {
		iommu2 = NULL;
		printk("%s: using NULL\n", __func__);
	}

	if (iommu1 && iommu2) {
		if (is_iommu_enabled(iommu1, iommu2)) {
			iommu_is_enabled = 1;
			printk("%s: IOMMU is enabled.\n", __func__);
		} else
			printk("%s: IOMMU is not enabled.\n", __func__);
	} else {
		printk("%s: Could not tell if IOMMU is enabled/disabled.",
			DRIVERNAME);
	}
} /* determine_if_iommu_is_enabled */

/*
* Initialize one instance of the PCI device
*/

static void hpdsa_init_spin_locks(struct ctlr_info *h)
{
	spin_lock_init(&cache_flush_lock);
	spin_lock_init(&h->lock);
	spin_lock_init(&h->scan_lock);
	spin_lock_init(&h->passthru_count_lock);
} /* hpdsa_init_spin_locks */


static void hpdsa_init_ctlr_variables_and_waitqueue(struct ctlr_info *h)
{
	unsigned long flags;

	spin_lock_irqsave(&h->lock, flags);
	h->busy_initializing = 0;
	h->passthru_count = 0;
	init_waitqueue_head(&h->scan_wait_queue);
	spin_unlock_irqrestore(&h->lock, flags);
	spin_lock_irqsave(&h->scan_lock, flags);
	h->scan_finished = 1;
	spin_unlock_irqrestore(&h->scan_lock, flags);
} /* hpdsa_init_ctlr_variables_and_waitqueue */

static int hpdsa_cache_init_one(struct pci_dev *pdev,
		const struct pci_device_id *ent)
{
	u32 board_id;
	int rc = 0;
	struct ctlr_info *h = NULL;

	board_id = get_board_id(pdev);

	initialized_cache_adapter = 0;

#if 0
#if !defined(RHEL5)
	if (!efi_enabled) {
		printk(DRIVERNAME ": EFI is not enabled, turn on efi\n");
		return -ENODEV;
	}
#endif
#endif
	/*
	 * Leaving in CACHE adapter for now. Seems like they will want
	 * to add one later on.
	 */

	h = alloc_hba_structure(pdev);
	if (!h) { /* FIXME: No cache device: return value of 1 is an error. */
		printk("%s: Could not get hba pointer\n", __func__);
		return -ENOMEM;
	}

	cache_ctlr_info = h;
	cache_ctlr_info->cache_pdev = pdev;
	cache_ctlr_info->pcidev = pdev;
	cache_h_ptr = h;
	cache_hba_number = h->ctlr_num;

	rc = hpdsa_cache_pci_init(cache_ctlr_info, cache_pdev);
	if (rc == 0) {
		printk("%s: Initialized cache controller\n", __func__);
		initialized_cache_adapter = 1;
		found_cache_adapter = 1;
	}

	/*
	 * No cache device...yet...
	 */
	return 1;
} /* hpdsa_cache_init_one */

static int hpdsa_ahci_init_one(struct pci_dev *pdev,
		const struct pci_device_id *ent)
{
	struct pci_dev *b140i_pdev = NULL;
	struct ctlr_info *h = NULL;
	u32 board_id;
	int rc = 0;

	board_id = get_board_id(pdev);

#if 0
#if !defined(RHEL5)
	if (!efi_enabled) {
		printk(DRIVERNAME ": EFI is not enabled, turn on efi\n");
		return -ENODEV;
	}
#endif
#endif

	b140i_pdev = pci_discovery_storage_adapter(B140I_VENDOR_ID, B140I_PCI_DEVICE_ID,
				B140I_PCI_SUBVENDOR_ID,
				B140I_PCI_SUBDEVICE_ID);

	h = alloc_hba_structure(pdev);
	if (!h) {
		printk("%s: Could not get hba pointer\n", __func__);
		return -ENOMEM;
	}

	rc = hpdsa_ahci_pci_init(h);
	if (rc < 0)
		goto hpdsa_ahci_init_one_err;

	h->is_b140i = 0; /* This is a AHCI controller */

#ifdef USE_NEW_INIT_DEVICE_SCHEME
	h->board_id = board_id;
#endif

	if (is_ahci_4(board_id)) {
		ahci_4_pdev = pdev;
		ahci_4_ctlr_info = h;
		found_ahci_4 = 1;
		printk("%s: Initialized ahci 4 port adapter\n", __func__);
	} else if (is_ahci_6(board_id)) {
		ahci_6_pdev = pdev;
		ahci_6_ctlr_info = h;
		found_ahci_6 = 1;
		printk("%s: Initialized ahci 6 port adapter\n", __func__);
	} else if (is_ahci_8(board_id)) {
		ahci_8_pdev = pdev;
		ahci_8_ctlr_info = h;
		found_ahci_8 = 1;
		printk("%s: Initialized ahci 8 port adapter\n", __func__);
	} else {
		printk("%s: Cannot determin what this board is 0x%x\n",__func__, board_id);
		return -1;
	}

	if (b140i_pdev) {
		printk("%s: B140I found, allowing it to control ahci devices.\n", __func__);
		return 0; /* success */
	}

	/*
	 * No B140I device means just initialize over ahci 6 port
	 * Note: There should not be a 4 port to initialize over if
	 *       No B140I. Just be sure.
	 */

	if (is_ahci_4(board_id)) {
		printk(DRIVERNAME ": Need a AHCI6 or AHCI8 when no B140I is present\n");
		return -ENODEV;
	}

	disk_h_ptr = h;

	hpdsa_init_spin_locks(h);

	hpdsa_init_ctlr_variables_and_waitqueue(h);

	determine_if_iommu_is_enabled(h);

	rc = hpdsa_init_raidstack(h);
	if (rc < 0)
		goto hpdsa_ahci_init_one_err;

	rc = hpdsa_init_scsi_driver(pdev, h);
	if (rc < 0)
		goto hpdsa_ahci_init_one_err;

	found_disk_adapter = 1;

	return 0; /* Success */

hpdsa_ahci_init_one_err:

	hpdsa_init_error_cleanup(pdev, h);

	return -ENODEV;

} /* hpdsa_ahci_init_one */

static int hpdsa_ctlr_init_one(struct pci_dev *pdev,
					const struct pci_device_id *ent)
{
	unsigned long flags;
	struct ctlr_info *h;
	int rc = 0;
	u32 board_id;

	board_id = get_board_id(pdev);

#define COMMANDLIST_ALIGNMENT 32
	BUILD_BUG_ON(sizeof(struct CommandList) % COMMANDLIST_ALIGNMENT);

#if 0
#if !defined(RHEL5)
	if (!efi_enabled) {
		printk(DRIVERNAME ": EFI is not enabled, turn on efi\n");
		return -ENODEV;
	}
#endif
#endif

	h = alloc_hba_structure(pdev);
	if (!h) {
		printk("%s: Could not get hba pointer\n", __func__);
		return -ENOMEM;
	}

	b140i_ctlr_info = h;
	disk_h_ptr = h;
	h->is_b140i = 1;

	determine_if_iommu_is_enabled(h);

	hpdsa_init_spin_locks(h);

	hpdsa_init_ctlr_variables_and_waitqueue(h);

	spin_lock_irqsave(&h->lock, flags);
	h->busy_initializing = 1;
	spin_unlock_irqrestore(&h->lock, flags);

	rc = hpdsa_b140i_adapter_pci_init(h);
	if (rc < 0)
		goto ctlr_cleanup4;

	/* Initialize the pdev private data. */
	pci_set_drvdata(pdev, h);

	spin_lock_irqsave(&h->lock, flags);
	h->busy_initializing = 0;
	spin_unlock_irqrestore(&h->lock, flags);

	rc = hpdsa_init_raidstack(h);
	if (rc < 0)
		goto ctlr_cleanup4;

	if (raid_application_loaded == 0) {
		printk("hpdsa: raidstack did not load\n");
		goto ctlr_cleanup4;
	}

	found_b140i = 1;
	found_disk_adapter = 1;

	rc = hpdsa_init_scsi_driver(pdev, h);
	if (rc < 0)
		goto ctlr_cleanup4;
	
	return 0; /* succeed */

ctlr_cleanup4:
	hpdsa_init_error_cleanup(pdev, h);

	return -ENODEV;
} /* hpdsa_ctlr_init_one */

static void hpdsa_cache_shutdown(struct pci_dev *pdev)
{
	unsigned long register_value;
	u32 board_id;
	unsigned long flags = 0;

	struct ctlr_info *h = cache_ctlr_info;

	board_id = get_board_id(pdev);

	DEBUGPRINT((0, "%s: board_id 0x%x\n", __func__, board_id));

	spin_lock_irqsave(&cache_flush_lock, flags);
	if (!cache_flushed && raid_application_loaded && found_cache_adapter) {
		hpdsa_flush_cache(disk_h_ptr);
		cache_flushed = 1;
	}
	spin_unlock_irqrestore(&cache_flush_lock, flags);

	/*
	 * Need to call this if initiated from controller shutdown sequence
	 */
	if (hpdsa_remove_one_calls_cache_shutdown)
		hpdsa_cache_remove_one(pdev);

} /* hpdsa_cache_shutdown */

/*
 * Reboot path and shutdown path (i.e. init 0, init 6, reboot)
 */

static void hpdsa_ahci_shutdown(struct pci_dev *pdev)
{
	/*
	 * If B140I is controlling the I/O operations
	 * we need to allow it to shut down everything
	 */

	/* Flag to avoid touching sysfs and profs on shutdown/reboot */

	if (!found_b140i) {
		u32 board_id = get_board_id(pdev);
		printk("%s: Shutdown started, board_id=0x%x\n", __func__, board_id);
		flag_hpdsa_shutdown_started = 1;
		hpdsa_ahci_remove_one(pdev);
	}

} /* hpdsa_ahci_shutdown */

static void hpdsa_ctlr_shutdown(struct pci_dev *pdev)
{
	u32 board_id;

	struct ctlr_info *h = disk_h_ptr;
	//struct ctlr_info *h = pci_get_drvdata(pdev);

	board_id = get_board_id(pdev);

	printk("%s: Starting board_id=0x%x.\n", __func__, board_id);
	printk("%s: 0x%x - Shuting down raidstack.\n", __func__, board_id);

	/* Flag to avoid touching sysfs and profs on shutdown/reboot */
	flag_hpdsa_shutdown_started = 1;

	hpdsa_shutdown_raidstack_and_cleanup(h);

} /* hpdsa_ctlr_shutdown */

static void hpdsa_cleanup_procfs(void)
{
	/* Should not touch profs on shutdown/reboot */
	if (flag_hpdsa_shutdown_started)
		return;

	char pname[32];

	sprintf(pname, "%s/%s", HPDSA_PROC_ENTRY, HPDSA_PROC_READ_ENTRY);
	DEBUGPRINT((0, "%s: removing proc entry [%s]\n", __func__, pname));
	remove_proc_entry(pname, NULL);
	DEBUGPRINT((0, "%s: removed proc entry\n", __func__));

	sprintf(pname, "%s", HPDSA_PROC_ENTRY);
	DEBUGPRINT((0, "%s: removing proc entry [%s]\n", __func__, pname));
	remove_proc_entry(pname, NULL);
	DEBUGPRINT((0, "%s: removed proc entry\n", __func__));
}

static int hpdsa_disable_msix(struct ctlr_info *h)
{
#ifdef CONFIG_PCI_MSI
	if (h->msix_vector) {
		if (MSIX_ENABLED(h->pdev)) {
			pci_disable_msix(h->pdev);
			MSIX_DISABLE(h->pdev);
		}
	} else if (h->msi_vector) {
		if (MSI_ENABLED(h->pdev)) {
			pci_disable_msi(h->pdev);
			MSI_DISABLE(h->pdev);
		}
	}
#endif
	return 0;
} /* hpdsa_disable_msix */

static void hpdsa_cleanup_memory_BAR(struct ctlr_info *h)
{
	iounmap(h->vaddr);
} /* hpdsa_cleanup_memory_BAR */

static void hpdsa_cleanup_interrupts_and_msix(struct ctlr_info *h)
{
	hpdsa_cleanup_irq(h);

	hpdsa_disable_msix(h);
} /* hpdsa_cleanup_interrupts_and_msix */

static void hpdsa_disable_device(struct ctlr_info *h)
{
	pci_set_drvdata(h->pdev, NULL);
	pci_release_regions(h->pdev);

#if !defined(SLES10)
	pci_clear_master(h->pdev);
	pci_disable_device(h->pdev);
#endif

} /* hpdsa_disable_device */

static void hpdsa_shutdown_raidstack_and_cleanup(struct ctlr_info *h)
{

	raid_shutting_down = 1;
	/*
	 * If we failed during init, then the raidstack did not load
	 */
	if (!raid_application_loaded)
		return;
	/*
	 * Flush cache, this also stops the storage devices.
	 *
	 */
	hpdsa_flush_cache(h);

	if (h->scsi_host && !flag_hpdsa_shutdown_started) {
		scsi_remove_host(h->scsi_host);
		scsi_host_put(h->scsi_host);
		h->scsi_host = NULL;
		DEBUGPRINT((0, "hpdsa: %s: Removed scsi host\n", __func__));
	}

	hpdsa_driver_loaded = 0;

	/*
	 * No more background task using the cache adapter
	 * and the cache has been flushed.
	 *
	 * Shutdown the cache adapter.
	 * Indicate that we want the cache shutdown to occur.
	 */
	/*
	 * If the controller shutdown is called first, we do not want
	 * the cache shutdown to get upset. So stop it from happening.
	 */
	hpdsa_remove_one_calls_cache_shutdown = 0;

	printk(DRIVERNAME ": Shutting down 0x%x\n", h->board_id);

} /* hpdsa_shutdown_raidstack_and_cleanup */

static void hpdsa_cache_remove_one(struct pci_dev *pdev_cache)
{
	int i;
	u32 board_id_cache;
	static int did_shutdown;
	unsigned long flags = 0;

	struct ctlr_info *h_disk = disk_h_ptr;
	struct ctlr_info *h_cache = cache_ctlr_info;

	if ((NULL == h_disk) || (NULL == h_cache) || (NULL == pdev_cache)) {
		cache_flushed = 1;
		return;
	}

	board_id_cache = get_board_id(pdev_cache);

	/*
	 * Should only go thru this if the controller shutdown sequence is
	 * initiated.
	 */

	if (!hpdsa_remove_one_calls_cache_shutdown)
		return;

	DEBUGPRINT((0, "%s: Starting board_id=0x%x.\n", __func__, board_id_cache));

	if (did_shutdown) {
		cache_flushed = 1;
		return;
	}

	printk(DRIVERNAME ": shutting down cache adapter 0x%x.\n", board_id_cache);

	spin_lock_irqsave(&cache_flush_lock, flags);
	if (!cache_flushed && raid_application_loaded && found_cache_adapter) {
		hpdsa_flush_cache(h_disk);
		cache_flushed = 1;
	}
	spin_unlock_irqrestore(&cache_flush_lock, flags);

#ifdef SW_RAID_IBANEZ
	disable_cache_adapter_intr(h_cache->cache_vaddr);
#endif

	if (h_cache->msix_vector)
		free_irq(h_cache->intr[1], h_cache);
	free_irq(h_cache->intr[0], h_cache);

	hpdsa_disable_msix(h_cache);

	iounmap(h_cache->cache_vaddr);

	/*
	 * Tell system we are done shutting down the cache adapter.
	 */

	did_shutdown = 1;
	pci_release_regions(cache_pdev);
	pci_clear_master(cache_pdev);
	pci_disable_device(cache_pdev);
	kfree(h_cache);

} /* hpdsa_cache_remove_one */

/*
 * This is called first during a rmmod.
 *
 * There are two ahci controllers.
 * This function is called for each registered wb controller.
 *
 * I need the AHCI6 to be removed first to flush cache.
 * Nothing is ever clean. Sigh.
 */
static void hpdsa_ahci_remove_one(struct pci_dev *pdev)
{
	static int done;

	if (done)
		return;

	/*
	 * Remove AHCI8 controller
	 */
	if (ahci_8_ctlr_info)
		hpdsa_remove_ctlr(ahci_8_ctlr_info);
	/*
	 * Remove AHCI6 controller
	 */
	if (ahci_6_ctlr_info)
		hpdsa_remove_ctlr(ahci_6_ctlr_info);

	/*
	 * Remove AHCI4 controller
	 */
	if (ahci_4_ctlr_info)
		hpdsa_remove_ctlr(ahci_4_ctlr_info);

	done = 1;
} /* hpdsa_ahci_remove_one */

static void hpdsa_remove_ctlr(struct ctlr_info *h)
{
	u32 board_id = 0;
	struct pci_dev *pdev = h->pdev;

	if (!h) {
		return;
	}

	if (!pdev) {
		printk("%s: no pdev.\n", __func__);
		return;
	}

	board_id = get_board_id(pdev);

	if (!found_b140i && (is_ahci_6(board_id) || is_ahci_8(board_id))) {
		printk("%s: shutting down raidstack\n", __func__);
		hpdsa_shutdown_raidstack_and_cleanup(h);
	}

	hpdsa_cleanup_interrupts_and_msix(h);
	hpdsa_cleanup_memory_BAR(h);
	hpdsa_disable_device(h);

	if (!found_b140i && (is_ahci_6(board_id) || is_ahci_8(board_id))) {
		hpdsa_cleanup_memory(h);
		hpdsa_cleanup_procfs();
	}

	kfree(h);
} /* hpdsa_remove_ctlr */

/*
 * Called from rmmod
 */
static void hpdsa_ctlr_remove_one(struct pci_dev *pdev)
{
	int i;
	u32 board_id_disk;
	unsigned long flags = 0;

	struct ctlr_info *h = pci_get_drvdata(pdev);

	board_id_disk = get_board_id(pdev);

	printk("%s: Starting. board_id = 0x%x\n", __func__, board_id_disk);
	printk("%s: pdev_disk = %p\n", __func__, pdev);
	printk("%s: h=%p\n", __func__, h);

	hpdsa_shutdown_raidstack_and_cleanup(h);
	hpdsa_cleanup_interrupts_and_msix(h);
	hpdsa_cleanup_memory_BAR(h);
	hpdsa_disable_device(h);
	hpdsa_cleanup_memory(h);
	hpdsa_cleanup_procfs();
	kfree(h);

} /* hpdsa_ctlr_remove_one */

static int hpdsa_suspend(__attribute__((unused)) struct pci_dev *pdev,
			__attribute__((unused)) pm_message_t state)
{
	return -ENOSYS;
}

static int hpdsa_resume(__attribute__((unused)) struct pci_dev *pdev)
{
	return -ENOSYS;
}

static void hpdsa_procinit(void)
{
	hpdsa_proc_init();
} /* hpdsa_procinit */

static struct pci_driver hpdsa_ctlr_pci_driver = {
	.name = B140I_DRIVER_NAME,
	.probe = hpdsa_ctlr_init_one,
	.remove = __devexit_p(hpdsa_ctlr_remove_one), /* rmmod path */
	.id_table = hpdsa_ctlr_pci_device_id, /* id_table */
	.shutdown = hpdsa_ctlr_shutdown,
	.suspend = hpdsa_suspend,
	.resume = hpdsa_resume,
};

static struct pci_driver hpdsa_ahci_pci_driver = {
	.name = AHCI_DRIVER_NAME,
	.probe = hpdsa_ahci_init_one,
	.remove = __devexit_p(hpdsa_ahci_remove_one), /* rmmod path */
	.id_table = hpdsa_ahci_pci_device_id, /* id_table */
	.shutdown = hpdsa_ahci_shutdown,
	.suspend = hpdsa_suspend,
	.resume = hpdsa_resume,
};

static struct pci_driver hpdsa_cache_pci_driver = {
	.name = CACHE_DRIVER_NAME,
	.probe = hpdsa_cache_init_one,
	/* only executes if called from controller rmmod path */
	.remove = __devexit_p(hpdsa_cache_remove_one),
	.id_table = hpdsa_cache_pci_device_id, /* id_table */
	/* only executes if called from controller shutdown path */
	.shutdown = hpdsa_cache_shutdown,
	.suspend = hpdsa_suspend,
	.resume = hpdsa_resume,
};

/*
 * Driver entry point
 */
static int __init raidstack_init(void)
{
	struct pci_dev pdev;
	int rc = 0;

	DEBUGPRINT((0, "hpdsa: %s: In raidstack_init\n", __func__));
	raidstack.process_cmd = (void *)CISS_NewCommand;
	raidstack.intr_control = interrupt_control;
	raidstack.shutdown = stop_background_ios;
	raidstack.init = raid_application_define;

	memset(hpdsa_hba, 0, sizeof(hpdsa_hba));

	initialize_pal();

	/*
	 * Have to guarantee the init order
	 */
	rc = pci_register_driver(&hpdsa_cache_pci_driver);

	rc = pci_register_driver(&hpdsa_ahci_pci_driver);

	rc = pci_register_driver(&hpdsa_ctlr_pci_driver);

	DEBUGPRINT((0, "hpdsa: %s: Done with raidstack_init\n", __func__));
	return rc;
} /* raidstack_init */

void hpdsa_flush_cache(struct ctlr_info *h)
{
	char *flush;
	int rc;


	if (NULL == h) {
		printk("%s: Could not flush cache, no controller\n", __func__);
		return;
	}

	if (!raid_application_loaded) {
		printk("%s: Could not flush cache,\n", __func__);
		return;
	}

	flush = kzalloc(4, GFP_KERNEL);
	if (flush == NULL) {
		printk("%s: Could not flush cache (oom)\n", __func__);
		return;
	}

	printk(DRIVERNAME ": flushing cache...\n");

	flush[0] = 0x01; /* DISABlE */
	flush[1] = 0x04; /* SHUTDOWN */
	rc = linux_hpdsa_scsi_do_inquiry_one(h, HPVSA_CACHE_FLUSH,
			RAID_CTLR_LUNID, flush, 4, 0, TYPE_CMD);

	if (rc)
		printk("%s: Controller flush failed\n", __func__);
	else
		printk(DRIVERNAME ": Controller cache flushed\n");

	/*
	 * system is now shutdown
	 */
	raid_application_loaded = 0;

	kfree(flush);

	hpdsa_shutdown_adapter();

	free_os_resources();

} /* hpdsa_flush_cache */

void hpdsa_cleanup_irq(struct ctlr_info *h)
{
	int j = 0;

	DEBUGPRINT((0, "%s: calling free_irq %s\n", __func__, h->msix_vector ?
		 "msi" : "ioapic"));

	/*
	 * Turn of interrupts
	 */
	hpdsa_intr_mask(h, 0);

	DEBUGPRINT((0, "%s: Removing interrupts\n", __func__));

	if (h->msix_vector) {
		for (j = 0; j < h->num_msix_vectors; j++) {
			DEBUGPRINT((0, "%s: a - calling free_irq for %d\n",
				 __func__, h->intr[j]));
			free_irq(h->intr[j], &h->q[j]);
		}
	} else {
		DEBUGPRINT((0, "%s: b - calling free_irq for %d\n", __func__,
			 h->intr[j]));
		free_irq(h->intr[h->intr_mode], &h->q[0]);
	}
} /* hpdsa_cleanup_irq */

static void __exit raidstack_cleanup(void)
{
	DEBUGPRINT((0, "%s: Starting.\n", __func__));
	DEBUGPRINT((0, "%s: Removing entry %s\n", __func__, "hpdsa"));
	pci_unregister_driver(&hpdsa_ctlr_pci_driver);
	pci_unregister_driver(&hpdsa_cache_pci_driver);
	pci_unregister_driver(&hpdsa_ahci_pci_driver);
}
module_init(raidstack_init);
module_exit(raidstack_cleanup);
