/*
 *    hpdsa.h -- definitions for the swr driver
 *
 *    Disk Array driver for HP SA Controllers
 *    Copyright 2014-2015 PMC-Sierra, Inc.
 *    Portions Copyright 2008-2014 Hewlett-Packard Development Company, L.P.
 *
 *    HP End User License Agreement – Enterprise Version (the "Agreement")
 *    governs the use of accompanying software, unless it is subject to a
 *    separate agreement between you and Hewlett-Packard Company and its
 *    subsidiaries ("HP").
 *
 *    Please refer to the terms and conditions of this software in the
 *    separate "EULA.txt" file, which governs the use of this software.
 *
 *    By downloading, copying, or using the software you agree to
 *    this Agreement.
 *
 *    Questions/Comments/Bugfixes to iss_storagedev@hp.com
 *
 */

#ifndef _HPVSA_H_
#define _HPVSA_H_

/* Size of PCI config space stored in primary_adapter_params. */

#ifndef BYTE
#	define BYTE      unsigned char
#	define HWORD     unsigned short int
#	define WORD      unsigned short int
#	ifdef SW_RAID
#		define CHAR      char
#		define DWORD    unsigned int
#	else  /* until pmcfw_types.h is modified */
#		define DWORD    unsigned long
#	endif
#	define QWORD     unsigned long long
#endif

/* files related to ZMR */
#include <linux/mm.h>
#include <linux/mman.h>
#include "hpdsa_cmd.h"

#define RAIDDRVR_PCI_CONFIG_SIZE    256
#define MAXSGENTRIES                32

#ifndef U8
#define U8        unsigned char
#endif
#ifndef U16
#define U16       unsigned short int
#endif
#ifndef U32
#define U32      unsigned int
#endif

typedef struct _vals32 {
	__u32   lower;
	__u32   upper;
} vals32;

typedef union _u64bit {
	vals32  val32;
	__u64   val;
} u64bit;


#define  QWORD_TO_U64(u64, qword) {u64.lower = (DWORD)qword; u64.upper = (DWORD) ((QWORD)(qword) >> 32); }

struct access_method {
	void (*submit_command)(struct ctlr_info *h,
		struct CommandList *c);
	void (*set_intr_mask)(struct ctlr_info *h, unsigned long val);
	unsigned long (*fifo_full)(struct ctlr_info *h);
	int (*intr_pending)(struct ctlr_info *h);
	unsigned long (*command_completed)(struct ctlr_info *h);
	unsigned long (*lock)(struct ctlr_info *h);
	void (*unlock)(struct ctlr_info *h, unsigned long flags);
};

#define FIFO_EMPTY		0xffffffff
#define SA5_INTR_PENDING	0x08

#define MAX_CTLRS 6
#define MAX_LUNS 8
#define MAX_TAPE_DEVICES 0
#define MAX_DVD_DEVICES 4
#define HPVSA_MAX_SCSI_DEVS_PER_HBA (MAX_LUNS + MAX_TAPE_DEVICES + MAX_DVD_DEVICES + MAX_CTLRS)

struct ctlr_info {
	int ctlr;
	unsigned char devname[20];
	unsigned char *hba_inquiry_data;
	char *product_name;
	struct semaphore sem;     /* mutual exclusion semaphore     */
	struct pci_dev *pcidev;   /* pci device id */
	int ctlr_num;	/* Index into hba[] */
#define CTRL_INFO_FLAG_SW_RAID              0x01
#define CTRL_INFO_FLAG_ASYNC_COMPLETION     0x02
	unsigned int flags;
	int nr_cmds;
	int maxsgentries;
	int maxSG;
	u8 max_cmd_sg_entries;/*will be int soon */
	int chainsize;
	__u32 board_id;
	char firmver[5];
	spinlock_t lock;
	spinlock_t devlock;
#define MAX_INTERRUPTS 24
	struct msix_entry hpdsa_msix_entries[MAX_INTERRUPTS];
	unsigned int intr[MAX_INTERRUPTS];
	unsigned int num_msix_vectors;
	unsigned int msix_vector;
	unsigned int msi_vector;
	unsigned int ioapic;
	unsigned int intr_mode;
	unsigned char q[MAX_INTERRUPTS];
	struct access_method access;
	void __iomem *vaddr;
	void __iomem *cache_vaddr;
	unsigned long paddr;
	unsigned long cache_paddr;
	struct completion *waiting;
# define PERF_MODE_INT 0
# define DOORBELL_INT 1
# define SIMPLE_MODE_INT 2

	struct Scsi_Host *scsi_host;
	int	nlogical_devices;
	int	curr_commands;
	CfgTable_struct *cfgtable;

# define BUSY_INIT_IDLE 0
# define BUSY_INIT_BUSY 1
# define BUSY_INIT_SHUTDOWN 2
	unsigned int busy_initializing;
	unsigned int busy_configuring;
	int commands_outstanding;
	int max_outstanding;
	int max_commands;
	int interrupts_enabled;
	int busy_scanning;
	int scan_finished;
	int is_b140i;
	spinlock_t scan_lock;
	wait_queue_head_t scan_wait_queue;

	struct CommandList	*cmd_pool;
	ErrorInfo_struct	*errinfo_pool;
	unsigned long		*pool_bits;
	dma_addr_t		CommandList_dhandle;
	dma_addr_t		ErrorInfo_dhandle;

	struct SGDescriptor **chained_sg_blocks;
	unsigned long **sg_virtual_addresses;
	struct scatterlist **scatterlist_buffers;
	struct pci_dev *pdev;
	struct pci_dev *hba_pdev;
	struct pci_dev *cache_pdev;
	struct pci_device_id *hba_ent;
	/*List Head pointers  */
	struct list_head	waiting_list;
	struct list_head	submitted_list;
	int ndevices;
# define MAX_SCSI_DEVS_PER_HBA 25
	struct hpdsa_scsi_dev_t *dev[HPVSA_MAX_SCSI_DEVS_PER_HBA];

	/* cap concurrent passthrus at some reasonable maximum */
#if defined(COMPILE_XEN)
#define HPVSA_MAX_CONCURRENT_PASSTHRUS (1)
#else
#define HPVSA_MAX_CONCURRENT_PASSTHRUS (8)
#endif
	spinlock_t passthru_count_lock; /* protects passthru_count */
	int passthru_count;

#ifdef VIRTUAL_PAL
	void *pal_root;
	int (*isr)(void *, int);
#endif
};

struct hpdsa_scsi_dev_t {
	int devtype;
	int bus, target, lun;		/* as presented to the OS */
	unsigned char scsi3addr[8];	/* as presented to the HW */
#define RAID_CTLR_LUNID "\0\0\0\0\0\0\0\0"
	u32		scsi2addr;
	unsigned char device_id[16];    /* from inquiry pg. 0x83 */
	unsigned char vendor[8];        /* bytes 8-15 of inquiry data */
	unsigned char model[16];        /* bytes 16-31 of inquiry data */
	unsigned char raid_level;	/* from inquiry page 0xC1 */
};

/*
 * Macros to help debugging
 */

#undef PDEBUG             /* undef it, just in case */
#ifdef HPDSA_DEBUG
#  ifdef __KERNEL__
     /* This one if debugging is on, and kernel space */
#    define PDEBUG(fmt, args...) printk(KERN_DEBUG "hpahcisr: " fmt, ## args)
#  else
     /* This one for user space */
#    define PDEBUG(fmt, args...) fprintf(stderr, fmt, ## args)
#  endif
#else
#  define PDEBUG(fmt, args...) /* not debugging: nothing */
#endif

#undef PDEBUGG
#define PDEBUGG(fmt, args...) /* nothing: it's a placeholder */

struct scsi3addr_map {
	u32		scsi2addr;
	u8		scsi3addr[8];
	u8		scsi_device_type;
};

/*typedef struct struct_hpdsa_scsi_dev_t {
	int		devtype;
	int		bus;
	int		target;
	int		lun;
	u32		scsi2addr;
	unsigned char	scsi3addr[8];
	unsigned char	device_id[16];
	unsigned char	vendor[8];
	unsigned char	model[16];
	unsigned char 	raid_level;
} hpdsa_scsi_dev_t;
*/
typedef struct hpdsa_scsi_hba_t {
	char		*name;
	int		ndevices;
	struct		hpdsa_scsi_dev_t dev[HPVSA_MAX_SCSI_DEVS_PER_HBA+1];
} hpdsa_scsi_hba_t;

#define SCSI3ADDR_EQ(a, b) ( \
	(a)[7] == (b)[7] && \
	(a)[6] == (b)[6] && \
	(a)[5] == (b)[5] && \
	(a)[4] == (b)[4] && \
	(a)[3] == (b)[3] && \
	(a)[2] == (b)[2] && \
	(a)[1] == (b)[1] && \
	(a)[0] == (b)[0])

struct scsi2map {
	char	scsi3addr[8];
	int	bus;
	int	target;
	int	lun;
};

#define REPORT_LOGICAL_LUNS	0xC2
#define REPORT_PHYSICAL_LUNS	0xC3


#define HPVSA_INTR_OFF	0
#define HPVSA_INTR_ON	1
#define WALLACE_INT_STATUS_REG_OFFSET 0x6400
#define WALLACE_INT_STATUS_MASK       0x80FFF

#if !defined(MAX_SCSI_DEVICE_CODE)
#define MAX_SCSI_DEVICE_CODE 16
static const char *const scsi_device_types[MAX_SCSI_DEVICE_CODE] = {
	"Direct-Access    ",
	"Sequential-Access",
	"Printer          ",
	"Processor        ",
	"WORM             ",
	"CD-ROM           ",
	"Scanner          ",
	"Optical Device   ",
	"Medium Changer   ",
	"Communications   ",
	"Controller       ",
	"                 ",
	"Controller       ",
	"                 ",
	"                 ",
	"                 ",
};
#endif
/* scsi_device_types comes from scsi.h */
#define DEVICETYPE(n) (n < 0 || n > MAX_SCSI_DEVICE_CODE - 1) ? \
	"Unknown" : scsi_device_types[n]

typedef struct _ReportLUNdata_struct {
  BYTE LUNListLength[4];
  DWORD reserved;
  BYTE LUN[MAX_LUNS+1][8];
} ReportLunData_struct;

#define HPVSA_ABORT_MSG 0
#define HPVSA_DEVICE_RESET_MSG 1
#define HPVSA_RESET_TYPE_CONTROLLER 0x00
#define HPVSA_RESET_TYPE_BUS 0x01
#define HPVSA_RESET_TYPE_TARGET 0x03
#define HPVSA_RESET_TYPE_LUN 0x04
#define HPVSA_MSG_SEND_RETRY_LIMIT 10
#define HPVSA_MSG_SEND_RETRY_INTERVAL_MSECS (10000)

/*
 * Split minors in two parts
 */
#define DTYPE(minor)	(((minor) >> 4) & 0xf)	/* high nibble */
#define NUM(minor)	((minor) & 0xf)		/* low  nibble */

/*
 * Prototypes for shared functions
 */
struct ctlr_info *get_hba(struct ctlr_info *);

int     hpdsa_p_init(dev_t dev);
void    hpdsa_p_cleanup(void);
int     hpdsa_access_init(dev_t dev);
void    hpdsa_access_cleanup(void);


/*
 * Ioctl definitions
 */

#define HPDSA_IOC_MAGIC  'B' /* Same as cciss, since we need to
				provide binary compatible ioctls. */

#define HPDSA_IOCRESET    _IO(HPDSA_IOC_MAGIC, 0)

/*
 * The other entities only have "Tell" and "Query", because they're
 * not printed in the book, and there's no need to have all six.
 * (The previous stuff was only there to show different ways to do it.
 */
#define HPDSA_P_IOCTSIZE _IO(HPDSA_IOC_MAGIC,   13)
#define HPDSA_P_IOCQSIZE _IO(HPDSA_IOC_MAGIC,   14)
/* ... more to come */

#define HPDSA_IOC_MAXNR 14

/*
 * MSI HELPER MACROS
 */
#define msi_control_reg(base)           (base + PCI_MSI_FLAGS)
#define multi_msix_capable msix_table_size
#define msix_table_size(control)  ((control & PCI_MSIX_FLAGS_QSIZE)+1)

char *get_hpdsa_driver_version(void);

#endif /* _HPVSA_H_ */
