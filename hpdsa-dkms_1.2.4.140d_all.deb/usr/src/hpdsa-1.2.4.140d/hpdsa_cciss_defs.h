/*
 *    Disk Array driver for HP SA Controllers
 *    Copyright 2014-2015 PMC-Sierra, Inc.
 *    Portions Copyright 2008-2014 Hewlett-Packard Development Company, L.P.
 *
 *    HP End User License Agreement – Enterprise Version (the "Agreement")
 *    governs the use of accompanying software, unless it is subject to a
 *    separate agreement between you and Hewlett-Packard Company and its
 *    subsidiaries ("HP").
 *
 *    Please refer to the terms and conditions of this software in the
 *    separate "EULA.txt" file, which governs the use of this software.
 *
 *    By downloading, copying, or using the software you agree to
 *    this Agreement.
 *
 *    Questions/Comments/Bugfixes to iss_storagedev@hp.com
 *
 */

#ifndef CCISS_DEFS_H
#define CCISS_DEFS_H

#include <linux/types.h>

/* general boundary definitions */
#define PRIVATE_SENSEINFOBYTES          32 /* note that this value may vary
				      between host implementations */

/* Command Status value */
#define CMD_SUCCESS             0x0000
#define CMD_TARGET_STATUS       0x0001
#define CMD_DATA_UNDERRUN       0x0002
#define CMD_DATA_OVERRUN        0x0003
#define CMD_INVALID             0x0004
#define CMD_PROTOCOL_ERR        0x0005
#define CMD_HARDWARE_ERR        0x0006
#define CMD_CONNECTION_LOST     0x0007
#define CMD_ABORTED             0x0008
#define CMD_ABORT_FAILED        0x0009
#define CMD_UNSOLICITED_ABORT   0x000A
#define CMD_TIMEOUT             0x000B
#define CMD_UNABORTABLE		0x000C

/* transfer direction */
#define XFER_NONE               0x00
#define XFER_WRITE              0x01
#define XFER_READ               0x02
#define XFER_RSVD               0x03

/* task attribute */
#define ATTR_UNTAGGED           0x00
#define ATTR_SIMPLE             0x04
#define ATTR_HEADOFQUEUE        0x05
#define ATTR_ORDERED            0x06
#define ATTR_ACA                0x07

/* cdb type */
#define TYPE_CMD				0x00
#define TYPE_MSG				0x01

#define CISS_MAX_LUN	1024

#define LEVEL2LUN   1 /* index into Target(x) structure, due to byte swapping */
#define LEVEL3LUN   0

#pragma pack(1)

/* Command List Structure */
typedef union hpdsa_SCSI3Addr_struct {
   struct {
    u8 Dev;
    u8 Bus:6;
    u8 Mode:2;        /* b00 */
  } PeripDev;
   struct {
    u8 DevLSB;
    u8 DevMSB:6;
    u8 Mode:2;        /* b01 */
  } LogDev;
   struct {
    u8 Dev:5;
    u8 Bus:3;
    u8 Targ:6;
    u8 Mode:2;        /* b10 */
  } LogUnit;
} hpdsa_SCSI3Addr_struct;

typedef struct hpdsa_PhysDevAddr_struct {
  u32             TargetId:24;
  u32             Bus:6;
  u32             Mode:2;
  hpdsa_SCSI3Addr_struct  Target[2]; /* 2 level target device addr */
} hpdsa_PhysDevAddr_struct;

typedef struct hpdsa_LogDevAddr_struct {
  u32            VolId:30;
  u32            Mode:2;
  u8             reserved[4];
} hpdsa_LogDevAddr_struct;

typedef union hpdsa_LUNAddr_struct {
  u8               LunAddrBytes[8];
  hpdsa_SCSI3Addr_struct   SCSI3Lun[4];
  hpdsa_PhysDevAddr_struct PhysDev;
  hpdsa_LogDevAddr_struct  LogDev;
} hpdsa_LUNAddr_struct;

typedef struct hpdsa_RequestBlock_struct {
  u8   CDBLen;
  struct {
    u8 Type:3;
    u8 Attribute:3;
    u8 Direction:2;
  } Type;
  u16  Timeout;
  u8   CDB[16];
} hpdsa_RequestBlock_struct;

typedef union hpdsa_MoreErrInfo_struct{
  struct {
    u8  Reserved[3];
    u8  Type;
    u32 ErrorInfo;
  } Common_Info;
  struct{
    u8  Reserved[2];
    u8  offense_size; /* size of offending entry */
    u8  offense_num;  /* byte # of offense 0-base */
    u32 offense_value;
  } Invalid_Cmd;
} hpdsa_MoreErrInfo_struct;
typedef struct hpdsa_ErrorInfo_struct {
  u8               ScsiStatus;
  u8               SenseLen;
  u16              CommandStatus;
  u32              ResidualCnt;
  hpdsa_MoreErrInfo_struct MoreErrInfo;
  u8               SenseInfo[PRIVATE_SENSEINFOBYTES];
} hpdsa_ErrorInfo_struct;

#pragma pack()

#endif /* CCISS_DEFS_H */
