/*
 *    Disk Array driver for HP SA Controllers
 *    Copyright 2014-2015 PMC-Sierra, Inc.
 *    Portions Copyright 2008-2014 Hewlett-Packard Development Company, L.P.
 *
 *    HP End User License Agreement – Enterprise Version (the "Agreement")
 *    governs the use of accompanying software, unless it is subject to a
 *    separate agreement between you and Hewlett-Packard Company and its
 *    subsidiaries ("HP").
 *
 *    Please refer to the terms and conditions of this software in the
 *    separate "EULA.txt" file, which governs the use of this software.
 *
 *    By downloading, copying, or using the software you agree to
 *    this Agreement.
 *
 *    Questions/Comments/Bugfixes to iss_storagedev@hp.com
 *
 */

#if !defined(__HPVSA_CMD_H)
#define __HPVSA_CMD_H

#ifndef U8
#define U8        unsigned char
#endif
#ifndef U16
#define U16       unsigned short int
#endif
#ifndef U32
#define U32      unsigned int
#endif

#define HPVSA_REPORT_LOG  0xc2   /* Report Logical LUNs */
#define HPVSA_REPORT_PHYS 0xc3   /* Report Physical LUNs */
#define HPVSA_INQUIRY 0x12

/* BMIC commands */
#define BMIC_READ         0x26
#define BMIC_WRITE        0x27
#define BMIC_CACHE_FLUSH  0xc2
#define HPVSA_CACHE_FLUSH 0x01  /* C2 was already being used by HPVSA */

/* Command types */
#define CMD_IOCTL_PEND  0x01
#define CMD_SCSI        0x03
#define HPVSA_SG_CHAIN                0x80000000

struct vals32 {
	u32   lower;
	u32   upper;
};

union u64bit {
	struct vals32 val32;
	u64 val;
};
#if defined(XEN_KERNEL) || defined(__XEN_INTERFACE_VERSION__)
#define MAX_CMDS		200
#else
#define MAX_CMDS		250
#endif

#define MAX_SG			32

/* general boundary defintions */
#ifdef ZMR
 #define SENSEINFOBYTES             56
#else
 #define SENSEINFOBYTES             256
#endif

#define MAXSGENTRIES            32
#define HVPSA_SG_CHAIN		0x80000000
#define MAXREPLYQS              256

/* Command Status value */
#define CMD_SUCCESS             0x0000
#define CMD_TARGET_STATUS       0x0001
#define CMD_DATA_UNDERRUN       0x0002
#define CMD_DATA_OVERRUN        0x0003
#define CMD_INVALID             0x0004
#define CMD_PROTOCOL_ERR        0x0005
#define CMD_HARDWARE_ERR        0x0006
#define CMD_CONNECTION_LOST     0x0007
#define CMD_ABORTED             0x0008
#define CMD_ABORT_FAILED        0x0009
#define CMD_UNSOLICITED_ABORT   0x000A
#define CMD_TIMEOUT             0x000B
#define CMD_UNABORTABLE		0x000C

/* Unit Attentions ASC's as defined for the MSA2012sa */
#define POWER_OR_RESET			0x29
#define STATE_CHANGED			0x2a
#define UNIT_ATTENTION_CLEARED		0x2f
#define LUN_FAILED			0x3e
#define REPORT_LUNS_CHANGED		0x3f

/* Unit Attentions ASCQ's as defined for the MSA2012sa */
/* These ASCQ's defined for ASC = POWER_OR_RESET */
#define POWER_ON_RESET			0x00
#define POWER_ON_REBOOT			0x01
#define SCSI_BUS_RESET			0x02
#define MSA_TARGET_RESET		0x03
#define CONTROLLER_FAILOVER		0x04
#define TRANSCEIVER_SE			0x05
#define TRANSCEIVER_LVD			0x06

/* These ASCQ's defined for ASC = STATE_CHANGED */
#define RESERVATION_PREEMPTED		0x03
#define ASYM_ACCESS_CHANGED		0x06
#define LUN_CAPACITY_CHANGED		0x09

/* transfer direction */
#define XFER_NONE               0x00
#define XFER_WRITE              0x01
#define XFER_READ               0x02
#define XFER_RSVD               0x03

/* task attribute */
#define ATTR_UNTAGGED           0x00
#define ATTR_SIMPLE             0x04
#define ATTR_HEADOFQUEUE        0x05
#define ATTR_ORDERED            0x06
#define ATTR_ACA                0x07

/* cdb type */
#define TYPE_CMD				0x00
#define TYPE_MSG				0x01

/* config space register offsets */
#define CFG_VENDORID            0x00
#define CFG_DEVICEID            0x02
#define CFG_I2OBAR              0x10
#define CFG_MEM1BAR             0x14

/* i2o space register offsets */
#define I2O_IBDB_SET            0x20
#define I2O_IBDB_CLEAR          0x70
#define I2O_INT_STATUS          0x30
#define I2O_INT_MASK            0x34
#define I2O_IBPOST_Q            0x40
#define I2O_OBPOST_Q            0x44
#define I2O_DMA1_CFG		0x214

/* Configuration Table */
#define CFGTBL_ChangeReq        0x00000001l
#define DOORBELL_CTLR_RESET	0x00000004l
#define DOORBELL_CTLR_RESET2	0x00000020l
#define CFGTBL_Trans_use_short_tags 0x20000000l

#pragma pack(1)

/* Command types */
#define CMD_IOCTL_PEND  0x01
#define CMD_SCSI	0x03

#define DIRECT_LOOKUP_SHIFT 5
#define DIRECT_LOOKUP_BIT 0x10
#define HPVSA_ERROR_BIT          0x02
#define RAID_CTLR_LUNID "\0\0\0\0\0\0\0\0"
#define CMD_TYPE_IO    0
#define CMD_TYPE_IOCTL 1

#define PTR_TO_STRUCT(ptr, tag) {                                        \
	(tag).upper = ((uint64_t)(ptr) >> 32);                 \
	(tag).lower = ((uint64_t)(ptr) & (0x00000000FFFFFFFF));\
}

#define STRUCT_TO_PTR(tag, ptr) { \
	(ptr) = (((uint64_t)(tag).h << (32)) | (tag).l);   \
}

/* The size of this structure needs to be divisible by 32
 * on all architectures because low 5 bits of the addresses
 * are used as follows:
 *
 * bit 0: to device, used to indicate "performant mode" command
 *        from device, indidcates error status.
 * bit 1-3: to device, indicates block fetch table entry for
 *          reducing DMA in fetching commands from host memory.
 * bit 4: used to indicate whether tag is "direct lookup" (index),
 *        or a bus address.
 */

struct ctlr_info; /* defined in hpdsa.h */

#pragma pack()

/*
 * Should this be packed?
 */
struct hpdsa_pci_info {
	unsigned char	bus;
	unsigned char	dev_fn;
	unsigned short	domain;
	u32		board_id;
};


/*
 * DEFINES and TYPEDEFS start here
 */
#define PCI_VENDOR_ID_HP_NEW		0x1590
#define CACHE_PCI_DEVICE_ID		0x005f
#define CACHE_PCI_SUBSYS_ID		0x005f1590
#define PCI_VENDOR_ID_LSI		0x1000
#define LSI_EMBEDDED_PCI_SUBSYS_ID	0x00451590
#define LSI_DAUGHTER_PCI_SUBSYS_ID	0x00471590
#define PATSBURG_PCI_SUBSYS_ID		0x00481590
#define B140I_PCI_DEVICE_ID		0x193f
#define B140I_PCI_SUBSYS_ID		0x3381103c
#define B140I_PCI_SUBVENDOR_ID		0x103c
#define B140I_PCI_SUBDEVICE_ID		0x3381
#define B140I_VENDOR_ID			0x103c
#define AHCI_VENDOR_ID		0x8086
#define AHCI_8P_PCI_DEVICE_ID	0xa107
#define AHCI_8P_PCI_SUBSYS_ID	0xc01590
#define AHCI_8P_PCI_SUBVENDOR_ID	0x1590
#define AHCI_8P_PCI_SUBDEVICE_ID	0x00c0
#define AHCI_8P_PCI_DEVICE_ID_ES2	0xa106
#define AHCI_8P_PCI_SUBSYS_ID_ES2	0xc01590
#define AHCI_8P_PCI_SUBVENDOR_ID_ES2	0x1590
#define AHCI_8P_PCI_SUBDEVICE_ID_ES2	0x00c0
#define AHCI_6P_PCI_DEVICE_ID	0x8d06
#define AHCI_6P_PCI_SUBSYS_ID	0x9c1590
#define AHCI_6P_PCI_SUBVENDOR_ID	0x1590
#define AHCI_6P_PCI_SUBDEVICE_ID	0x009c
#define AHCI_4P_PCI_DEVICE_ID	0x8d66
#define AHCI_4P_PCI_SUBSYS_ID	0x9d1590
#define AHCI_4P_PCI_SUBVENDOR_ID	0x1590
#define AHCI_4P_PCI_SUBDEVICE_ID	0x009d
#define VM_SUBSYSTEM_ID			0x00991590
#define COUGAR_POINT_PCI_SUBSYS_ID	0x006C1590
#define LYNX_POINT_PCI_SUBSYS_ID	0x00841590

#define MAX_COMMANDS_TO_QUEUE 256
#define FIFO_NEARLY_EMPTY 0xfffffffe

#define HPVSA_DRIVER_VERSION "1.2.4.140d"

#define DRIVERNAME "hpdsa"

#ifdef WARN_ON
#undef WARN_ON
#endif
#define WARN_ON(variable) 0	/* For RHEL5 */
#define SCSI_QDEPTH_DEFAULT 0   /* For RHEL5 */

/* Controller specific definitions */
#define SYS_MEM_SEG0_SIZE       0x04000000  /* 64MB */

/* Cache Adapter Memory Definitions */
#define CACHE_ADPTR_VIRT_MEM_SIZE       0x00400000

int is_cache_adapter(unsigned int);
int is_sas_adapter(unsigned int);
int is_ahci_adapter(unsigned int);
int is_disk_adapter(unsigned int);
int is_glp4_adapter(unsigned int board_id);
struct pci_dev *pci_discovery_found_cache_adapter(void);
void ciss_cmd_completion(void *ciss_cmd);

struct raidstack_function_table {
	void (*process_cmd)(void *c);
	void (*intr_control)(int flag, int msix_vector_num);
	void (*shutdown)(void);
	void (*init)(void);
};

unsigned long long hpdsa_get_raid_resources(char *type, u32 *length);

#define BEGIN_STRUCTURE_PACKING  _Pragma("pack(1)")
#define END_STRUCTURE_PACKING    _Pragma("pack()")

#ifndef TYPES_H
typedef struct    {U32 lower; U32 upper; } U64;
#endif

BEGIN_STRUCTURE_PACKING
union SCSI3Addr {
	struct {
		u8 Dev;
		u8 Bus:6;
		u8 Mode:2;        /* b00 */
	} PeripDev;
	struct {
		u8 DevLSB;
		u8 DevMSB:6;
		u8 Mode:2;        /* b01 */
	} LogDev;
	struct {
		u8 Dev:5;
		u8 Bus:3;
		u8 Targ:6;
		u8 Mode:2;        /* b10 */
	} LogUnit;
};

struct PhysDevAddr {
	u32             TargetId:24;
	u32             Bus:6;
	u32             Mode:2;
	/* 2 level target device addr */
	union SCSI3Addr  Target[2];
};

struct LogDevAddr {
	u32            VolId:30;
	u32            Mode:2;
	u8             reserved[4];
};

union LUNAddr {
	u8               LunAddrBytes[8];
	union SCSI3Addr    SCSI3Lun[4];
	struct PhysDevAddr PhysDev;
	struct LogDevAddr  LogDev;
};

#ifndef CISS_H
typedef union _SCSI3Addr_struct {
	struct {
		BYTE    Dev;
#ifndef CPU_LITTLE
		BYTE    Mode:2;
		BYTE    Bus:6;
#else
		BYTE    Bus:6;
		BYTE    Mode:2;
#endif
	} PeripDev;
	struct {
#ifndef CPU_LITTLE
		BYTE    DevLSB;
		BYTE    Mode:2;
		BYTE    DevMSB:6;
#else
		BYTE    DevLSB;
		BYTE    DevMSB:6;
		BYTE    Mode:2;
#endif
	} LogDev;
	struct {
#ifndef CPU_LITTLE
		BYTE    Bus:3;
		BYTE    Dev:5;
		BYTE    Mode:2;
		BYTE    Targ:6;
#else
		BYTE    Dev:5;
		BYTE    Bus:3;
		BYTE    Targ:6;
		BYTE    Mode:2;
#endif
	} LogUnit;
	struct {
		BYTE    One;
		BYTE    Zero;
	} Bytes;
} SCSI3Addr_struct;

typedef struct _LogDevAddr_struct {
	DWORD              VolId     : 8;
	DWORD              VolId_VSA : 8;
	DWORD              Bus_ID    : 8;
#ifndef CPU_LITTLE
	DWORD              Mode      : 2;
	DWORD              Rsvd1     : 6; /* diff due to Borg endianess */
#else
	DWORD              Rsvd1     : 6;
	DWORD              Mode      : 2;
#endif
	BYTE               Vol_Bus_Id;
	BYTE               reserved[3];
} LogDevAddr_struct;

typedef struct _PhysDevAddr_struct {
	DWORD              TargetId  : 8;
	DWORD              Rsvd0     : 16;
#ifndef CPU_LITTLE
	DWORD              Mode      : 2;
	WORD               Bus       : 6;
#else
	DWORD              Bus       : 6;
	DWORD              Mode      : 2;
#endif
	SCSI3Addr_struct   Target_Level_3;
	SCSI3Addr_struct   Target_Level_2;
} PhysDevAddr_struct;

typedef union _MoreErrInfo_struct {
	struct {
		BYTE    Reserved[3];
		BYTE    Type;
		DWORD   ErrorInfo;        /* 4 */
	} Common_Info;
	struct{
		BYTE    Reserved[2];
		BYTE    offense_size;     /* size of offending entry */
		BYTE    offense_num;      /* byte # of offense 0-base */
		DWORD   offense_value;
	} Invalid_Cmd;
	struct {
		DWORD   ownership;
		DWORD   reserved;
	} iLO_Command;
	struct {
		BYTE   EER_Status;
		BYTE   Retried;
		HWORD  Repl_CommandStatus;
		BYTE   iop_error;
		BYTE   Reserved[3];
	} Drive_Error_Info;
} MoreErrInfo_struct;  /* 8 */

typedef struct _ErrorInfo_struct {
	BYTE               ScsiStatus;
	BYTE               SenseLen;
	HWORD              CommandStatus;
	DWORD              ResidualCnt;                /* 4 */
	MoreErrInfo_struct MoreErrInfo;             /* 8 */
	BYTE               SenseInfo[SENSEINFOBYTES];  /* 256 */
} ErrorInfo_struct;              /* 272 */
#endif /* CISS_H */

struct CommandListHeader {
	u8                        ReplyQueue;
	u8                        SGList;
	u16                       SGTotal;
	struct vals32             Tag;
	union LUNAddr             LUN;
};

struct SGDescriptor {
	struct vals32 Addr;
	u32  Len;
	u32  Ext;
};

struct RequestBlock {
	BYTE      CDBLen;
	struct {
#ifndef CPU_LITTLE
	BYTE    Direction:2;
	BYTE    Attribute:3;
	BYTE    Type:3;
#else
	BYTE    Type:3;
	BYTE    Attribute:3;
	BYTE    Direction:2;
#endif
	} Type;
	HWORD     Timeout;
	BYTE      CDB[16];
};

struct ErrDescriptor {
	U64       Addr;
	DWORD     Len;
};

struct CommandList {
	struct CommandListHeader	Header;
	struct RequestBlock		Request;
	struct ErrDescriptor		ErrDesc;
	struct SGDescriptor		SG[MAXSGENTRIES];
	/* information associated with the command */
	u32				busaddr; /* bus addr of cmd */
	__u8				direction;
	__u8				CDB[16];
	ErrorInfo_struct *err_info; /* pointer to the allocated mem */
	struct ctlr_info		*h;
	int				cmd_type;
	long				cmdindex;
	dma_addr_t			cmd_dma_handle;
	dma_addr_t			err_dma_handle;
	void				*scsi_cmnd;
	struct				list_head list;
	struct				request *rq;
	struct				completion *waiting;
	void (*done)(void *);
	__u32				timeout;
	__u8				cmd_aborted;
	unsigned long			*sg_buffer;
	__u8				used_sg_buffer;
	unsigned long			*ioctl_sg_virtual_addresses[MAX_SG];
	struct SGDescriptor             CTLR_SG[MAXSGENTRIES];
	unsigned char                   dma_remapped_to_cache_device;
	struct device                   *dev_used_to_remap;
	unsigned short                  orig_use_sg;
#define COMMANDLIST_ALIGNMENT 32
} __attribute__((aligned(COMMANDLIST_ALIGNMENT)));
END_STRUCTURE_PACKING

#ifndef CISS_H
typedef struct _CfgTable_struct {
	BYTE   Signature[4];
	DWORD  SpecValence;
	DWORD  TransportSupport;
	DWORD  TransportActive;
	DWORD  TransportRequest;
	DWORD  Upper32Addr;
	DWORD  CoalIntDelay;
	DWORD  CoalIntCount;
	DWORD  CmdsOutMaxSimple;
	DWORD  BusTypes;
	DWORD  TransportMethodOffset;
	BYTE   ServerName[16];
	DWORD  HeartBeat;
	DWORD  HostSupport;   /* driver specific support bits */
	DWORD  Max_SG_Elements;
	DWORD  Max_LogicalUnits;
	DWORD  Max_PhysicalUnits;
	DWORD  Max_PhysicalsPerLogicalUnit;
	DWORD  CmdsOutMaxPerformant;
	DWORD  Max_BlockFetchCount;             /* EXTENDED_BLOCK_FETCH_COUNT */
	DWORD  PwrConsvSup;                     /* DL360_SHUT_DOWN_KLUDGE */
	DWORD  PwrConsvEnable;
	DWORD  TMF_Support_Flags;
	DWORD  TMF_Tag_Mask[2];
	DWORD  Periodic_Sampling_Support;       /* ILO_COMMAND_FETCH_SUPPORT */
	DWORD  Periodic_Sampling_Control;       /* ILO_COMMAND_FETCH_SUPPORT */
	DWORD  MiscSupportFlags;
	BYTE   OSDriverVersion[32];
	DWORD  Max_Cacheable_Write_Size;
	DWORD  DriverDebugScratchpad[4];
	DWORD  Max_Err_Info_Length_supported;
	DWORD  AccelMode_Max_EmbeddedSGs;
	DWORD  AccelMode_TransportMethodOffset;
	DWORD  EventNotify;
	DWORD  ClearEventNotify;
} CfgTable_struct;

/*
 * Macros to get/set U64 with a CPU(compiler) native ptr data type,
 *
 * 32 or 64-bit.
 *
 * For use with CPU virtual addresses
 */
#ifndef CPU_64_BIT
typedef unsigned int       PTR_DTYPE;
#define PTR_TO_U64(u64, ptr)    {u64.lower = (PTR_DTYPE)ptr; u64.upper = 0x0; }
#define U64_TO_PTR(u64)         ((void *)((PTR_DTYPE)u64.lower))
#else
typedef unsigned  long long PTR_DTYPE;
	#define PTR_TO_U64(u64, ptr) \
		{u64.lower = (DWORD)((PTR_DTYPE)ptr); \
		u64.upper = (DWORD)((PTR_DTYPE)(ptr) >> 32); }
	#define U64_TO_PTR(u64) \
	((void *)((PTR_DTYPE)(((PTR_DTYPE)u64.upper << 32) | u64.lower)))
#endif
#endif /* CISS_H */

#endif /* __HPVSA_CMD_H */
