/*
 *    Disk Array driver for HP SA Controllers
 *    Copyright 2014-2015 PMC-Sierra, Inc.
 *    Portions Copyright 2008-2014 Hewlett-Packard Development Company, L.P.
 *
 *    HP End User License Agreement – Enterprise Version (the "Agreement")
 *    governs the use of accompanying software, unless it is subject to a
 *    separate agreement between you and Hewlett-Packard Company and its
 *    subsidiaries ("HP").
 *
 *    Please refer to the terms and conditions of this software in the
 *    separate "EULA.txt" file, which governs the use of this software.
 *
 *    By downloading, copying, or using the software you agree to
 *    this Agreement.
 *
 *    Questions/Comments/Bugfixes to iss_storagedev@hp.com
 *
 */

#if !defined(__HPVSA_KERNEL_COMPAT_H)
#define __HPVSA_KERNEL_COMPAT_H

#define XEN_32_SG_BUFSIZE (64 * 1024)
/* must be equal to XEN_32_SG_BUFSIZE */
#define XEN_32_NUM_SECTORS 128

#define complete_xen_command hpcva_complete_xen_command
#define SATA_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
/*
 * =========================================================================
 * RHEL7
 * =========================================================================
 */
#if defined(RHEL7)
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			0
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#	define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			0
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			1
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#if !defined(CPU_64_BIT)
#define XEN_32_SG_BUFSIZE (64 * 1024)
#define XEN_32_NUM_SECTORS 128
#	define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	1
#	define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#endif
#	define hpdsa_alloc_user_space  arch_compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS			0
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      1
#	define __devinit
#	define __devexit
#	define __devexit_p(x) x
#	define do_mmap vm_mmap
#	define do_munmap(x, y, z) vm_munmap(y, z)
static inline void __user *compat_ptr(unsigned int uptr)
{
	return (void __user *)(unsigned long)uptr;
}

#if defined(CPU_64_BIT)
static inline void __user *arch_compat_alloc_user_space(long len)
{
	unsigned int sp;
	return (void __user *)round_down(sp - len, 16);
}
#else
static inline void __user *arch_compat_alloc_user_space(long len)
{
	struct pt_regs *regs = task_pt_regs(current);
	return (void __user *)regs->sp - len;

}
#endif

#else
/*
 * =========================================================================
 * RHEL6
 * =========================================================================
 */
#if defined(RHEL6) && !defined(RHEL64) && !defined(RHEL65) && !defined(RHEL66) && !defined(RHEL67) && !defined(RHEL68)
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			0
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	0
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			0
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	if !defined(CPU_64_BIT)
#		define XEN_32_SG_BUFSIZE (64 * 1024)
#		define XEN_32_NUM_SECTORS 128
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	1
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#	else
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#	endif
#	define hpdsa_alloc_user_space  arch_compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED | IRQF_SAMPLE_RANDOM)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			0
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <linux/compat.h>	/* for compat_ptr */
#	include <linux/smp_lock.h>
#else
/*
 * =========================================================================
 * RHEL64
 * =========================================================================
 */
#if defined(RHEL64) || defined(RHEL65) || defined(RHEL66) || defined(RHEL67) || defined(RHEL68)
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			0
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#	define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			0
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			0
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	if !defined(CPU_64_BIT)
#		define XEN_32_SG_BUFSIZE (64 * 1024)
#		define XEN_32_NUM_SECTORS 128
#	endif
#	define hpdsa_alloc_user_space  arch_compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			0
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <linux/compat.h>	/* for compat_ptr */
#if defined(USE_NEWER_KERNEL_DEFINITIONS)
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      1
#	define __devinit
#	define __devexit
#	define __devexit_p(x) x
#	define exitcall_t
#	define do_mmap vm_mmap
#	define do_munmap(x, y, z) vm_munmap(y, z)
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define INIT_COMPLETION(x)
#else
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED | IRQF_SAMPLE_RANDOM)
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#endif
#else
/*
 * =========================================================================
 * OpenSUSE11SP1
 * =========================================================================
 */
#ifdef OSUSE11SP1
#	define KERNEL_USES_IRQRETURN_T				0
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			0
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	if defined(COMPILE_XEN) && !defined(CPU_64_BIT)
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	1
#	else
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	endif
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	0
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			0
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define hpdsa_alloc_user_space  compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED | IRQF_SAMPLE_RANDOM)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		0
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <linux/compat.h>	/* for compat_ptr */
#	include <linux/smp_lock.h>
#else
/*
 * =========================================================================
 * SLES11
 * =========================================================================
 */
#ifdef SLES11
#	define KERNEL_USES_IRQRETURN_T				0
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			0
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			0
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			0
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_SCAN_START_IMPLEMENTED			0
#	define KERNEL_HAS_SHOST_PRIV				1
#	if defined(COMPILE_XEN) && !defined(CPU_64_BIT)
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	1
#	else
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	endif
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	0
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			0
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define hpdsa_alloc_user_space  compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED | IRQF_SAMPLE_RANDOM)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			0
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <linux/compat.h>	/* for compat_ptr */
#	include <linux/smp_lock.h>
#else
/*
 * =========================================================================
 * SLES11SP1
 * =========================================================================
 */
#ifdef SLES11SP1
#	define KERNEL_USES_IRQRETURN_T				0
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			0
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	if !defined(CPU_64_BIT)
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	1
#	else
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	endif
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	0
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			0
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define hpdsa_alloc_user_space  compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED | IRQF_SAMPLE_RANDOM)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <linux/compat.h>	/* for compat_ptr */
#	include <linux/smp_lock.h>
#else
/*
 * =========================================================================
 * SLES11SP2
 * =========================================================================
 */
#ifdef SLES11SP2
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	if !defined(CPU_64_BIT)
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	1
#	else
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	endif
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			1
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			0
#	define hpdsa_alloc_user_space  arch_compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED | IRQF_SAMPLE_RANDOM)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <asm/compat.h>	/* for compat_ptr */
#else
/*
 * =========================================================================
 * SLES11SP3/SLES11SP4
 * =========================================================================
 */
#if defined(SLES11SP3) || defined(SLES11SP4)
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	if !defined(CPU_64_BIT)
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	1
#	else
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	endif
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			1
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			0
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <asm/compat.h>	/* for compat_ptr */
#	if !defined(CPU_64_BIT)
#		include <linux/highmem.h>
#	endif
#if defined(USE_NEWER_KERNEL_DEFINITIONS)
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      1
#	define INIT_COMPLETION(x)
#	define do_mmap vm_mmap
#	define do_munmap(x, y, z) vm_munmap(y, z)
#	define __devinit
#	define __devexit
#	define __devexit_p(x) x
#	define hpdsa_alloc_user_space  ubuntu_arch_compat_alloc_user_space
#else
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED | IRQF_SAMPLE_RANDOM)
#	define hpdsa_alloc_user_space  arch_compat_alloc_user_space
#endif
#else
/*
 * =========================================================================
 * SLES12
 * =========================================================================
 */
#ifdef SLES12
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	if !defined(CPU_64_BIT)
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	1
#	else
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	endif
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			1
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			0
#	define hpdsa_alloc_user_space  sles12_arch_compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      1
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <asm/compat.h>		/* for compat_ptr */
#	if !defined(CPU_64_BIT)
#		include <linux/highmem.h>
#	endif
#	define __devinit
#	define __devexit
#	define __devexit_p(x) x
#	define exitcall_t
#	define do_mmap vm_mmap
#	define do_munmap(x, y, z) vm_munmap(y, z)
	static inline void __user *sles12_arch_compat_alloc_user_space(long len)
	{
		/*compat_uptr_t sp = this_cpu_read(old_rsp) - 128;*/
		compat_uptr_t sp = 0; /* FIXME!!! */

		return (void __user *)round_down(sp - len, 16);
	}
#else
/*
 * =========================================================================
 * UBUNTU
 * =========================================================================
 */
#ifdef UBUNTU
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#	define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			1
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			0
#include <linux/compat.h>	/* for compat_ptr */
#if defined(UBUNTU13) || defined(UBUNTU12) || defined(UBUNTU14)
#	define __devinit
#	define __devexit
#	define __devexit_p(x) x
#endif
#	define hpdsa_alloc_user_space  ubuntu_arch_compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define USE_UBUNTU_COMPAT_ALLOC				0
#if defined(UBUNTU1310)
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#else
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#endif
#	include <linux/compat.h>	/* for compat_ptr */
#if defined(UBUNTU1310)
#	include <linux/sched/rt.h>
#endif
#if defined(UBUNTU13)
#include <linux/mod_devicetable.h>
#endif
#if defined(USE_NEWER_KERNEL_DEFINITIONS)
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      1
#	define INIT_COMPLETION(x)
#	define do_mmap vm_mmap
#	define do_munmap(x, y, z) vm_munmap(y, z)
#else
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#endif
#else
/*
 * =========================================================================
 * SLACKWARE
 * =========================================================================
 */
#ifdef SLACKWARE
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#	define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			1
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			0
#	define alloc_user_space arch_compat_alloc_user_space
#	define hpdsa_alloc_user_space  alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <linux/compat.h>	/* for compat_ptr */
#else
/*
 * =========================================================================
 * FEDORA
 * =========================================================================
 */
#ifdef FEDORA
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#	define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			1
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			0
#	define USE_UBUNTU_COMPAT_ALLOC				1
#	include <linux/compat.h>	/* for compat_ptr */
#	include <linux/sched/rt.h>	/* for MAX_PRIO */
#	define do_mmap vm_mmap
#	define do_munmap(x, y, z) vm_munmap(y, z)
#	if defined(FEDORA19) || defined(FEDORA20)
#		define __devinit
#		define __devexit
#		define __devexit_p(x) x
#	endif
#	define hpdsa_alloc_user_space  ubuntu_arch_compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      1
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#else
/*
 * =========================================================================
 * RHEL5
 * =========================================================================
 */
#ifdef RHEL5
#	define KERNEL_USES_IRQRETURN_T				0
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			1
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			0
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		0
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			0
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			0
#	define KERNEL_HAS_SHOST_PRIV				1
#	if defined(CPU_64_BIT)
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	elif defined(COMPILE_XEN)
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS                    0
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK    1
#	else /* 32bit */
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	1
#	endif
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	0
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			0
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		0
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define ioremap_cache ioremap
#	define phys_addr_t unsigned long
	static inline void *sg_virt(struct scatterlist *sg)
	{
		return page_address(sg->page) + sg->offset;
	}
#	if !defined(CPU_64_BIT)
		static inline struct page *sg_page(struct scatterlist *sg)
		{
			return (struct page *)((sg)->page);
		}
#	endif
#	if !defined(RHEL55)
#		define hpdsa_alloc_user_space  arch_compat_alloc_user_space
#	else
#		define hpdsa_alloc_user_space  compat_alloc_user_space
#	endif
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		1
#	define REQUEST_IRQ_FLAGS (SA_INTERRUPT|SA_SHIRQ|SA_SAMPLE_RANDOM)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			0
#	define NEEDS_SEMAPHORE_DEFINITIONS                      0
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		0
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#else
/*
 * =========================================================================
 * SLES10
 * =========================================================================
 */
#ifdef SLES10
#	define KERNEL_USES_IRQRETURN_T				1
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			1
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			0
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		0
#	define PCI_MSIX_FLAGS_QSIZE				0x7FF
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			0
#	define KERNEL_SCAN_START_PRESENT			0
#	define KERNEL_SCAN_START_IMPLEMENTED			0
#	define KERNEL_HAS_SHOST_PRIV				0
#	if defined(COMPILE_XEN) && !defined(CPU_64_BIT)
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#		define XEN_32_SG_BUFSIZE (64 * 1024)
#		define XEN_32_NUM_SECTORS 128
#		if defined(complete_xen_command)
#			undef complete_xen_command
#			define complete_xen_command \
				hpcva_empty_complete_xen_command
#		endif
#	else
#		define KERNEL_HAS_SCSI_DMA_FUNCTIONS			0
#		define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	endif
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY	0
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL		1
#	define KERNEL_HAS_BIG_KERNEL_LOCK			1
#	define KERNEL_HAS_2011_03_QUEUECOMMAND			0
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		0
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define ioremap_cache ioremap
#	define scsi_sg_count(cmd) ((cmd)->use_sg)
#	define phys_addr_t unsigned long
#	define pci_set_master(x) hpdsa_pci_set_master(x, 1)
#	define pci_clear_master(x) hpdsa_pci_set_master(x, 0)
	static inline void scsi_set_resid(struct scsi_cmnd *cmd, int resid)
	{
		cmd->resid = resid;
	}
	static inline void *sg_virt(struct scatterlist *sg)
	{
		return page_address(sg->page) + sg->offset;
	}

#	ifdef CONFIG_X86_PAE
		typedef u64 resource_size_t;
#	else
		typedef unsigned long resource_size_t;
#	endif

#	if !defined(CPU_64_BIT)
		static inline struct page *sg_page(struct scatterlist *sg)
		{
			return (struct page *)((sg)->page);
		}
#	endif

#	ifndef DMA_BIT_MASK
#		define DMA_BIT_MASK(n) (((n) == 64) ? ~0ULL : ((1ULL<<(n))-1))
#	endif

	static inline int scsi_bufflen(struct scsi_cmnd *cmd)
	{
		return cmd->request_bufflen;
	}
	static inline struct scatterlist *scsi_sglist(struct scsi_cmnd *cmd)
	{
		return (struct scatterlist *)cmd->request_buffer;
	}

#	define for_each_sg(sglist, sg, nr, __i)        \
		for (__i = 0, sg = (sglist); __i < (nr); __i++, sg = (++sglist))

#	define hpdsa_alloc_user_space  arch_compat_alloc_user_space
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		1
#	define REQUEST_IRQ_FLAGS (SA_INTERRUPT|SA_SHIRQ|SA_SAMPLE_RANDOM)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (SA_SAMPLE_RANDOM)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (SA_SAMPLE_RANDOM | SA_SHIRQ)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (SA_SHIRQ | SA_SAMPLE_RANDOM)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (SA_SHIRQ | SA_SAMPLE_RANDOM)
#	define SEMAPHORE_INFO_GET_NEEDS_PORTED			1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      0
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		0
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	define DEFINE_PCI_DEVICE_TABLE(_tablex) struct pci_device_id _tablex[]
/*
 * =========================================================================
 * Kernel.org
 * =========================================================================
 */
#else
#	define LINUX_DO_KERNEL_ADVANCED_COMPAT			1
#	define KERNEL_HAS_2011_03_INTERRUPT_HANDLER		1
#	define KERNEL_CHANGE_QDEPTH_HAS_REASON			1
#	define KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR		1
#	define KERNEL_HAS_SCSI_QDEPTH_DEFAULT			1
#	define KERNEL_HAS_SCSI_FOR_EACH_SG			1
#	define KERNEL_HAS_SCSI_DEVICE_TYPE			1
#	define KERNEL_SCAN_START_PRESENT			1
#	define KERNEL_SCAN_START_IMPLEMENTED			1
#	define KERNEL_HAS_SHOST_PRIV				1
#	define KERNEL_HAS_SCSI_DMA_FUNCTIONS			1
#	define KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK	0
#	define KERNEL_HAS_SCSI_SET_RESID			1
#	define KERNEL_HAS_UACCESS_H_FILE			1
#	define KERNEL_HAS_ATOI_DEFINED				0
#	define KERNEL_HAS_SMP_LOCK_H 0 /* smp_lock.h removed 2.6.38, 2.6.39 */
#	define KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER		1
#	define USE_UBUNTU_COMPAT_ALLOC				0
#	define DRIVER_NEEDS_TO_PROTECT_CMD_ALLOCATION		0
#	define REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define CACHE_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define CACHE_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define SAS_MSIX_REQUEST_IRQ_FLAGS (IRQF_DISABLED)
#	define SAS_IOAPIC_REQUEST_IRQ_FLAGS (IRQF_SHARED)
#	define KERNEL_HAS_NEWER_SCSI_DEFINITIONS		1
#	define DRIVER_INIT_ONE_RETURN_VALUE			0
#	include <linux/mm.h>
#include <linux/compat.h>	/* for compat_ptr */
#if defined(USE_NEWER_KERNEL_DEFINITIONS)
#include <linux/vmalloc.h>
#include <linux/slab.h>
static inline void __user *kernel_org_arch_compat_alloc_user_space(long len)
{
	compat_uptr_t sp;
	return (void __user *)round_down(sp - len, 16);
}
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      1
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY   1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL          1
#	define KERNEL_USES_IRQRETURN_T                          1
#	define INIT_COMPLETION(x)
#	define do_mmap vm_mmap
#	define do_munmap(x, y, z) vm_munmap(y, z)
#	define __devinit
#	define __devexit
#	define __devexit_p(x) x
#	define hpdsa_alloc_user_space  kernel_org_arch_compat_alloc_user_space
#	define KERNEL_HAS_2011_03_QUEUECOMMAND                  1
#	define KERNEL_HAS_BIG_KERNEL_LOCK                       0
#else
#	define KERNEL_HAS_NEW_PROC_SUPPORT                      0
#	define KERNEL_USES_IRQRETURN_T                          0
#	define KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY   1
#	define KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL          1
#	define NEEDS_SEMAPHORE_DEFINITIONS                      0
#	define hpdsa_alloc_user_space  arch_compat_alloc_user_space
#	define KERNEL_HAS_2011_03_QUEUECOMMAND                  0
#	define KERNEL_HAS_BIG_KERNEL_LOCK                       1
#endif

#endif /* RHEL7 */
#endif /* RHEL6 */
#endif /* RHEL64 */
#endif /* SLES11 */
#endif /* SLES11SP1 */
#endif /* OSUSE11SP1 */
#endif /* SLES11SP2 */
#endif /* SLES11SP3/SLES11SP4 */
#endif /* SLES12 */
#endif /* UBUNTU */
#endif /* SLACKWARE */
#endif /* FEDORA */
#endif /* RHEL5 */
#endif /* SLES10 */

#if defined(SLES10)
	#define MSIX_ENABLED(p) 1
	#define MSIX_DISABLE(p) 1
	#define MSI_ENABLED(p) 1
	#define MSI_DISABLE(p) 1
#else
	#define MSIX_ENABLED(p) ((p)->msix_enabled)
	#define MSIX_DISABLE(p) ((p)->msix_enabled = 0)
	#define MSI_ENABLED(p) ((p)->msi_enabled)
	#define MSI_DISABLE(p) ((p)->msi_enabled = 0)
#endif

#include "hpdsa.h"

/*
 * For cli I/O
 */
static struct proc_dir_entry *proc_hpdsa;
static struct proc_dir_entry *pde;
static struct proc_dir_entry *pde_sob;
#define DRIVER_NAME "hpdsa"
#define B140I_DRIVER_NAME "hpdsag"
#define AHCI_DRIVER_NAME "hpdsaw"
#define CACHE_DRIVER_NAME "hpdsac"
#define HPDSA_PROC_ENTRY DRIVER_NAME
#define SOB_BUF_ON "enable serial output buffer"
#define SOB_BUF_OFF "disable serial output buffer"

#define HPDSA_PROC_READ_ENTRY "hpdsa0"
#define proc_root_driver NULL

extern int raidstack_sob_logging;

static ssize_t hpdsa_write_proc(struct file *file, const char __user *buffer,
					size_t count, loff_t *data);

static ssize_t hpdsa_proc_write(struct file *file, const char __user *buffer,
					size_t count, loff_t *data)
{
	return hpdsa_write_proc(file, buffer, count, data);
}

static ssize_t hpdsa_proc_get_info(struct file *f, char __user *buffer,
					size_t size, loff_t *offset)
{
	printk(KERN_INFO "hpdsa_proc_get_info: Not implemented yet\n");
	return 0;
} /* hpdsa_proc_get_info */

#if KERNEL_HAS_NEW_PROC_SUPPORT

/*
 * Get us a file in /proc/hpdsa that says something about each controller.
 * Create /proc/hpdsa if it doesn't exist yet.
 */
static int hpdsa_proc_open(struct inode *inode, struct file *filp)
{
	return 0;
}

static int hpdsa_proc_release(struct inode *inode, struct file *filp)
{
	return 0;
}

static const struct file_operations proc_operations_procfs = {
	.owner		= THIS_MODULE,
	.read		= hpdsa_proc_get_info,
	.write		= hpdsa_proc_write,
	.open		= hpdsa_proc_open,
	.release	= hpdsa_proc_release,
};

static void __devinit hpdsa_proc_init(void)
{
	if (proc_hpdsa == NULL) {
		proc_hpdsa = proc_mkdir(HPDSA_PROC_ENTRY, proc_root_driver);
		if (!proc_hpdsa)
			return;
	}
	pde = proc_create_data(HPDSA_PROC_READ_ENTRY,
				S_IWUSR | S_IRUSR | S_IRGRP | S_IROTH,
				proc_hpdsa,
				&proc_operations_procfs, NULL);
} /* hpdsa_procinit */

static ssize_t hpdsa_write_proc(struct file *file, const char __user *buffer,
					size_t count, loff_t *data)
{
	int err = -EFAULT;
	char buf[256] = "";

	if (copy_from_user(buf, buffer, count))
		goto hpvsa_write_proc_out;

	if (strncmp(buf, SOB_BUF_ON, min(strlen(SOB_BUF_ON), count)) == 0) {
		printk(KERN_INFO "hpvsa: Turning on ctlr logging\n");
		raidstack_sob_logging = 1;
	} else if (strncmp(buf,
			SOB_BUF_OFF, min(strlen(SOB_BUF_OFF), count)) == 0) {
		printk(KERN_INFO "hpvsa: Turning off ctlr logging\n");
		raidstack_sob_logging = 0;
	} else {
		if (host_cli_pass_through(buf, count))
			goto hpvsa_write_proc_out;
	}

	return count;

hpvsa_write_proc_out:

	return err;
} /* hpdsa_write_proc */

#else /* !KERNEL_HAS_NEW_PROC_SUPPORT (older proc support) */

static void __devinit hpdsa_proc_init(void)
{
	if (proc_hpdsa == NULL) {
		proc_hpdsa = proc_mkdir(HPDSA_PROC_ENTRY, proc_root_driver);
		if (!proc_hpdsa)
			return;
	}

	pde = create_proc_read_entry(HPDSA_PROC_READ_ENTRY,
					S_IWUSR | S_IRUSR | S_IRGRP | S_IROTH,
					proc_hpdsa, hpdsa_proc_get_info, NULL);
	if (!pde)
		return;
	pde->write_proc = hpdsa_proc_write;
} /* hpdsa_procinit */

static ssize_t hpdsa_write_proc(struct file *file, const char __user *buffer,
					size_t count, loff_t *data)
{
	int err = -EFAULT;
	char buf[256] = "";

	if (copy_from_user(buf, buffer, count))
		goto hpdsa_write_proc_out;

	if (strncmp(buf, SOB_BUF_ON, min(strlen(SOB_BUF_ON), count)) == 0) {
		printk(KERN_INFO "hpdsa: Turning on ctlr logging\n");
		raidstack_sob_logging = 1;
	} else if (strncmp(buf,
			SOB_BUF_OFF, min(strlen(SOB_BUF_OFF), count)) == 0) {
		printk(KERN_INFO "hpdsa: Turning off ctlr logging\n");
		raidstack_sob_logging = 0;
	} else {
		if (host_cli_pass_through(buf, count))
			goto hpdsa_write_proc_out;
	}

	return count;

hpdsa_write_proc_out:

	return err;
} /* hpdsa_write_proc */

#endif /* KERNEL_HAS_NEW_PROC_SUPPORT */
/*
 * Entry for VMWare
 */
#if defined(__VMKLNX__)
#       define SEMAPHORE_INFO_GET_NEEDS_PORTED                  1
#endif


static void hpcva_empty_complete_xen_command(struct ctlr_info *h, struct CommandList *c)
{
	return;
}

#if KERNEL_HAS_NEWER_SCSI_DEFINITIONS
#       define SGLIST(c)  scsi_sglist(c)
#       define SGCOUNT(c) scsi_sg_count(c)
#       define SGXFERLEN(c) scsi_bufflen(c)
#       define USESG(c) 1
#       define SETRESID(c, x) (c)->sdb.resid = (x)
#       define SGLISTPAGE(sgl, n) (sgl[n].page_link & ~0x3)
#else
#       define SGLIST(c)  ((struct scatterlist *)(c)->request_buffer)
#       define SGCOUNT(c) ((c)->use_sg)
#       define USESG(c) ((c)->use_sg)
#       define SGXFERLEN(c) ((c)->request_bufflen)
#       define SETRESID(c, x) ((c)->resid = (x))
#       define SGLISTPAGE(sgl, n) sgl->page
#endif

static void hpcva_complete_xen_command(struct ctlr_info *h,
					struct CommandList *c)
{
	struct scsi_cmnd *cmd = c->scsi_cmnd;
	int use_sg = SGCOUNT(cmd);
	size_t total_len = scsi_bufflen(cmd); /* Total length of command.*/
	void *p_buff = c->sg_buffer;
	void *p_sg = NULL;
	size_t ioleft = total_len;
	size_t len = ioleft;
	size_t offset = total_len - ioleft;
	unsigned long flags = 0;
	union u64bit temp64;

	if ((use_sg > 0)) {
		temp64.val32.upper = c->SG[0].Addr.upper;
		temp64.val32.lower = c->SG[0].Addr.lower;
		pci_unmap_single(h->pcidev, (dma_addr_t) temp64.val,
				c->SG[0].Len,
				cmd->sc_data_direction);
		if ((cmd->sc_data_direction == DMA_FROM_DEVICE) ||
			(cmd->sc_data_direction == DMA_BIDIRECTIONAL)) {
			while (ioleft) {
				len = ioleft;
				offset = total_len - ioleft;
				local_irq_save(flags);
				p_sg = scsi_kmap_atomic_sg(scsi_sglist(cmd),
							scsi_sg_count(cmd),
							&offset, &len);
				if (!p_sg) {
					local_irq_restore(flags);
					break;
				}

				if (len > total_len) {
					memcpy(p_sg + offset, p_buff,
						total_len);
					scsi_kunmap_atomic_sg(p_sg);
					local_irq_restore(flags);
					break;
				} else
					memcpy(p_sg + offset, p_buff, len);

				scsi_kunmap_atomic_sg(p_sg);
				local_irq_restore(flags);
				if (len > ioleft)
					break;
				p_buff += len;
				ioleft -= len;
			} /* while */
		} /* if */
	} /* if ( (use_sg > 0) */
} /* complete_xen_command */

#if !KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER
#include <linux/mm.h>

static inline int scsi_sg_copy_to_buffer(struct scsi_cmnd *cmd,
					void *buf, int buflen)
{
	struct scatterlist *sg = NULL;
	void *p_sg = NULL;
	unsigned long flags = 0;

	void *p_buff = NULL;
	size_t total_len = 0;
	size_t ioleft = 0;

	int i = 0;
	size_t offset = 0;
	size_t len = 0;

	p_buff = buf;
	total_len = scsi_bufflen(cmd);
	ioleft = total_len;

	if (!cmd->use_sg)
		return 0;

	while (ioleft > 0) {
		len = ioleft;
		offset = total_len - ioleft;
		local_irq_save(flags);
		p_sg = scsi_kmap_atomic_sg(scsi_sglist(cmd),
						scsi_sg_count(cmd),
						&offset, &len);
		if (!p_sg) {
			printk("%s: Unable to map buffer\n", __func__);
			return 0;
		}
		memcpy(p_buff, p_sg + offset, len);
		scsi_kunmap_atomic_sg(p_sg);
		local_irq_restore(flags);
		p_buff += len;
		ioleft -= len;
	} /* while */

	return 0;
}
#endif /* KERNEL_HAS_SCSI_SG_COPY_TO_BUFFER */

#if KERNEL_HAS_2011_03_QUEUECOMMAND
#	define DECLARE_QUEUECOMMAND(func) \
		static int func##_lck(struct scsi_cmnd *cmd, void (*done)(struct scsi_cmnd *))
#	define DECLARE_QUEUECOMMAND_WRAPPER(func) static DEF_SCSI_QCMD(func)
#else
#	define DECLARE_QUEUECOMMAND(func) \
		static int func(struct scsi_cmnd *cmd, \
				void (*done)(struct scsi_cmnd *))
#	define DECLARE_QUEUECOMMAND_WRAPPER(func)
#endif

#if KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR

#	define DECLARE_DEVATTR_SHOW_FUNC(func) \
		static ssize_t func(struct device *dev, \
			struct device_attribute *attr, char *buf)

#	define DECLARE_HOST_DEVICE_ATTR(xname, xmode, xshow, xstore) \
		DEVICE_ATTR(xname, xmode, xshow, xstore)

#	define DECLARE_HOST_ATTR_LIST(xlist) \
	static struct device_attribute *xlist[]

#else /* not KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR */

#	define DECLARE_DEVATTR_SHOW_FUNC(func) \
	static ssize_t func(struct class_device *dev, char *buf)


#	define DECLARE_HOST_DEVICE_ATTR(xname, xmode, xshow, xstore) \
	struct class_device_attribute dev_attr_##xname = {\
		.attr = { \
			.name = #xname, \
			.mode = xmode, \
		}, \
		.show = xshow, \
		.store = xstore, \
	};

#	define DECLARE_HOST_ATTR_LIST(xlist) \
	static struct class_device_attribute *xlist[]

#endif /* KERNEL_HAS_2011_03_STYLE_DEVICE_ATTR */


#if KERNEL_USES_IRQRETURN_T
	/* new style interrupt handler */
#       define DECLARE_INTERRUPT_HANDLER(handler) \
		static irqreturn_t handler(int irq, void *dev_id)
#       define INTERRUPT_HANDLER_TYPE(handler) \
		irqreturn_t (*handler)(int, void *)
#else
	/* old style interrupt handler */
#       define DECLARE_INTERRUPT_HANDLER(handler) \
		static irqreturn_t handler(int irq, void *dev_id, \
		struct pt_regs *regs)
#       define INTERRUPT_HANDLER_TYPE(handler) \
		irqreturn_t (*handler)(int, void *, struct pt_regs *)
#endif /* USES_IRQRETURN_T */

#if !KERNEL_HAS_SCSI_FOR_EACH_SG
#	define scsi_for_each_sg(cmd, sg, nseg, __i) \
	for (__i = 0, sg = scsi_sglist(cmd); __i < (nseg); __i++, (sg)++)
#endif

#if !KERNEL_HAS_SCSI_DEVICE_TYPE
	/*
	 * scsi_device_type - Return 17 char string indicating device type.
	 * @type: type number to look up
	 */

	static const char *scsi_device_type(unsigned type)
	{
		if (type == 0x1e)
			return "Well-known LUN   ";
		if (type == 0x1f)
			return "No Device        ";
		if (type >= ARRAY_SIZE(scsi_device_types))
			return "Unknown          ";
		return scsi_device_types[type];
	}
#endif /* KERNEL_HAS_SCSI_DEVICE_TYPE */

#if KERNEL_SCAN_START_PRESENT
	/* .scan_start is present in scsi host template */
#	define INITIALIZE_SCAN_START(funcptr) .scan_start = funcptr,
#	define INITIALIZE_SCAN_FINISHED(funcptr) .scan_finished = funcptr,
#else
	/* .scan start is not even present in scsi host template */
#	define INITIALIZE_SCAN_START(funcptr)
#	define INITIALIZE_SCAN_FINISHED(funcptr)
#endif /* KERNEL_SCAN_START_PRESENT */

#if KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY
#	define HPVSA_INITIALIZE_FOPS_IOCTL(funcptr) .unlocked_ioctl = funcptr,
#else
#	define HPVSA_INITIALIZE_FOPS_IOCTL(funcptr) .ioctl = funcptr,
#endif /* KERNEL_FILE_OPERATIONS_HAS_UNLOCKED_IOCTL_ONLY */

#if KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL
/* Some Beta kernels may not yet have this defined */
#if defined(CONFIG_COMPAT) && defined(HAVE_COMPAT_IOCTL)
#	define HPVSA_INITIALIZE_FOPS_COMPAT_IOCTL(funcptr) .compat_ioctl = funcptr,
#else
#	define HPVSA_INITIALIZE_FOPS_COMPAT_IOCTL(funcptr)
#endif
#endif /* KERNEL_FILE_OPERATIONS_HAS_COMPAT_IOCTL */

#if KERNEL_HAS_BIG_KERNEL_LOCK
#	define LOCK_KERNEL lock_kernel();
#	define UNLOCK_KERNEL unlock_kernel();
#else
#	define LOCK_KERNEL
#	define UNLOCK_KERNEL
#endif

#include <linux/ctype.h>

#if KERNEL_SCAN_START_IMPLEMENTED

	/* .scan_start is present in scsi host template AND implemented.
	* Used to bail out of queuecommand if no scan_start and REPORT_LUNS
	* encountered
	*/
	static inline int bail_on_report_luns_if_no_scan_start(
				__attribute__((unused)) struct scsi_cmnd *cmd,
				__attribute__((unused)) void (*done)(struct scsi_cmnd *))
	{
				return 0;
	}

	/* RHEL6, kernel.org have functioning ->scan_start() method in kernel
	 * so this is no-op.
	 */
	static inline void hpdsa_initial_update_scsi_devices(
		__attribute__((unused)) struct ctlr_info *h)
	{
		return;
	}
#else /* not KERNEL_SCAN_START_IMPLEMENTED */
	static inline int bail_on_report_luns_if_no_scan_start(
		struct scsi_cmnd *cmd, void (*done)(struct scsi_cmnd *))
	{
		/*
		 * This thing bails out of our queue command early on SCSI
		 * REPORT_LUNS This is needed when the kernel doesn't really
		 * support the scan_start method of the scsi host template.
		 *
		 * Since we do our own mapping in our driver, and we handle
		 * adding/removing of our own devices.
		 *
		 * We want to prevent the mid-layer from doing it's own
		 * adding/removing of drives which is what it would do
		 * if we allow REPORT_LUNS to be processed.
		 *
		 * On RHEL5, scsi mid-layer never calls scan_start and
		 * scan_finished even though they exist in scsi_host_template.
		 *
		 * On RHEL6 we use scan_start and scan_finished to tell
		 * mid-layer that we do our own device adding/removing
		 * therefore we can handle REPORT_LUNS.
		 */

		if (cmd->cmnd[0] == REPORT_LUNS) {
			cmd->result = (DID_OK << 16);           /* host byte */
			cmd->result |= (COMMAND_COMPLETE << 8); /* msg byte */
			cmd->result |= SAM_STAT_CHECK_CONDITION;
			memset(cmd->sense_buffer, 0, sizeof(cmd->sense_buffer));
			cmd->sense_buffer[2] = ILLEGAL_REQUEST;
			done(cmd);
			return 1;
		}
		return 0;
	}

	/* Need this if no functioning ->scan_start() method in kernel. */
	static int hpdsa_update_disk_devices(struct ctlr_info *h,
							int hostno);
	static inline void hpdsa_initial_update_scsi_devices(
							struct ctlr_info *h)
	{
		hpdsa_update_disk_devices(h, -1);
	}
#endif /* KERNEL_SCAN_START_IMPLEMENTED */

#if !KERNEL_HAS_SHOST_PRIV
	static inline void *shost_priv(struct Scsi_Host *shost)
	{
		return (void *) shost->hostdata;
	}
#endif /* KERNEL_HAS_SHOST_PRIV */

#if !KERNEL_HAS_SCSI_DMA_FUNCTIONS
/*
 * Does not have things like scsi_dma_map, scsi_dma_unmap, scsi_sg_count,
 * sg_dma_address, sg_dma_len...
 */
#if KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK
#include <linux/highmem.h>
#define XEN_32_SG_BUFSIZE (64 * 1024)
/* must be equal to XEN_32_SG_BUFSIZE */
#define XEN_32_NUM_SECTORS 128

/*
 * SLES11XX and SLES10 XEN kernels have hypervisor that does
 * not like to convert from DMA address * to virtual address
 * (in a different context).
 *
 * I Cannot get back to context of process that issued the
 * command from PARSE TASK context.
 *
 * To accomodate this I am limiting each 32bit XEN request
 * to 64K and building my own bounce buffers
 * like I did in Tanzanite driver :<.
 */

static int hpdsa_scatter_gather(struct CommandList *cp,
				struct scsi_cmnd *cmd, struct ctlr_info *h)
{
	union u64bit addr64;
	int use_sg = 0;
	void *sg_buff = NULL;
	int total_len = 0;


	use_sg = SGCOUNT(cmd); /* Start with all data buffer s/g elements */
	total_len = SGXFERLEN(cmd); /* Total length of command */


	if (!h) {
		printk("%s: no controller\n", __func__);
		h->sg_virtual_addresses[cp->cmdindex][0] = (unsigned long) NULL;
		return -1;
	}

	if (!cp->sg_buffer) {
		printk("%s: no sg_buffer\n", __func__);
		h->sg_virtual_addresses[cp->cmdindex][0] = (unsigned long) NULL;
		return -1;
	}

	sg_buff = cp->sg_buffer;

	if (use_sg > 0) {
		size_t len = SGXFERLEN(cmd);

		if ((cmd->sc_data_direction == DMA_TO_DEVICE) ||
				(cmd->sc_data_direction == DMA_BIDIRECTIONAL)) {
			scsi_sg_copy_to_buffer(cmd, sg_buff, XEN_32_SG_BUFSIZE);
			use_sg = 1; /* End up with only 1 s/g element. */
		} else if (cmd->sc_data_direction == DMA_FROM_DEVICE) {
			memset(sg_buff, 0, len);
			use_sg = 1; /* End up with only 1 s/g element. */
		}
	} else { /* if (use_sg > 0) */
		use_sg = 0;
	}

	if (use_sg) {
		h->sg_virtual_addresses[cp->cmdindex][0] = (unsigned long) sg_buff;
		cp->used_sg_buffer = 1;
		addr64.val = (u64) pci_map_single(h->pdev, sg_buff, total_len, cmd->sc_data_direction);
		cp->SG[0].Addr.upper = addr64.val32.upper;
		cp->SG[0].Addr.lower = addr64.val32.lower;
		cp->SG[0].Len = total_len;
		cp->SG[0].Ext = 0;  /* we are not chaining */
	}

	cp->Header.SGList = (u8) use_sg;   /* no. SGs contig in this cmd */
	cp->Header.SGTotal = (u16) use_sg; /* total sgs in this cmd list */

	return 0;
}

#else
static void hpdsa_map_sg_chain_block(struct ctlr_info *h,
	struct CommandList *c);

static void hpdsa_unmap_sg_chain_blocks(struct ctlr_info *h,
	struct CommandList *d);

/* It is not reasonably possible to retrofit the new scsi dma interfaces
 * onto the old code.  So we retrofit at a higher level, at the dma mapping
 * function of the hpsa driver itself.
 *
 * hpsa_scatter_gather takes a struct scsi_cmnd, (cmd), and does the pci
 * dma mapping  and fills in the scatter gather entries of the
 * hpsa command, cp.
 */
static int hpdsa_scatter_gather(struct CommandList *cp,
				struct scsi_cmnd *cmd, struct ctlr_info *h)
{
	unsigned int len;
	union u64bit addr64;
	int use_sg, i, sg_index, chained = 0;
	struct SGDescriptor *curr_sg;
	struct scatterlist *sg = (struct scatterlist *) cmd->request_buffer;

	if (!cmd->use_sg) {
		if (cmd->request_bufflen) { /* Just one scatter gather entry */
			h->sg_virtual_addresses[cp->cmdindex][0] = (unsigned long) cmd->request_buffer;
			addr64.val = (__u64) pci_map_single(h->pdev,
				cmd->request_buffer, cmd->request_bufflen,
				cmd->sc_data_direction);

			cp->SG[0].Addr.upper = addr64.val32.upper;
			cp->SG[0].Addr.lower = addr64.val32.lower;
			cp->SG[0].Len = cmd->request_bufflen;
			use_sg = 1;
		} else /* Zero sg entries */
			use_sg = 0;
	} else {
		BUG_ON(cmd->use_sg > h->maxsgentries);

		/* Many sg entries */
		use_sg = pci_map_sg(h->pdev, cmd->request_buffer, cmd->use_sg,
				cmd->sc_data_direction);

		if (use_sg < 0)
			return use_sg;

		sg_index = 0;
		curr_sg = cp->SG;

		for (i = 0; i < use_sg; i++) {
			if (i == h->max_cmd_sg_entries - 1 &&
				use_sg > h->max_cmd_sg_entries) {
				chained = 1;
				curr_sg = h->chained_sg_blocks[cp->cmdindex];
			}
			h->sg_virtual_addresses[cp->cmdindex][i] =
						(unsigned long) sg_virt(&sg[i]);
			addr64.val = (__u64) sg_dma_address(&sg[i]);
			len  = sg_dma_len(&sg[i]);
			curr_sg->Addr.upper = addr64.val32.upper;
			curr_sg->Addr.lower = addr64.val32.lower;
			curr_sg->Len = len;
			curr_sg->Ext = 0;  /* we are not chaining */
			curr_sg++;
		}
		if (use_sg + chained > h->maxSG)
			h->maxSG = use_sg + chained;

		if (chained) {
			cp->Header.SGList = h->max_cmd_sg_entries;
			cp->Header.SGTotal = (u16) (use_sg + 1);
			hpdsa_map_sg_chain_block(h, cp);
			return 0;
		}
	} /* else */

	cp->Header.SGList = (u8) use_sg;   /* no. SGs contig in this cmd */
	cp->Header.SGTotal = (u16) use_sg; /* total sgs in this cmd list */
	return 0;
}

static void hpdsa_scatter_gather_unmap(struct ctlr_info *h,
	struct CommandList *c, struct scsi_cmnd *cmd)
{
	struct SGDescriptor *sg_block, *sg_link;
	union u64bit addr64;

	if (cmd->use_sg) {
		pci_unmap_sg(h->pdev, cmd->request_buffer, cmd->use_sg,
			cmd->sc_data_direction);
		hpdsa_unmap_sg_chain_blocks(h, c);
		return;
	}
	if (cmd->request_bufflen) {
		addr64.val32.lower = c->SG[0].Addr.lower;
		addr64.val32.upper = c->SG[0].Addr.upper;
		pci_unmap_single(h->pdev, (dma_addr_t) addr64.val,
		cmd->request_bufflen, cmd->sc_data_direction);
	}
}

static inline void scsi_dma_unmap(struct scsi_cmnd *cmd)
{
	struct CommandList *c = (struct CommandList *) cmd->host_scribble;

	hpdsa_scatter_gather_unmap(c->h, c, cmd);
}
#endif /* KERNEL_OS_HAS_32BIT_XEN_ISSUES_WITH_RAIDSTACK */
#endif /* KERNEL_HAS_SCSI_DMA_FUNCTIONS */

#ifdef USE_UBUNTU_COMPAT_ALLOC
#	ifdef CPU_64_BIT
		static inline void __user
			*ubuntu_arch_compat_alloc_user_space(long len)
		{
			compat_uptr_t sp = 0; /* FIXME!!! */

			return (void __user *)round_down(sp - len, 16);
		}
#	else
		static inline void __user
			*ubuntu_arch_compat_alloc_user_space(long len)
		{
			struct pt_regs *regs = task_pt_regs(current);
			return (void __user *)regs->sp - len;
		}
#	endif
#endif

#endif /* __HPVSA_KERNEL_COMPAT_H */
