#!/usr/bin/env ruby

# update-build-scripts.rb
# Assumptions
#   * Script is run from directory which the RAID stack source code is in
#   * Hamer driver code is in repo given by HAMER_DRIVER_REPO
#   * Current user has read and write access to the Hamer driver code repo
#   * The current user has read access to the RAID stack driver code
#   * The user BuilderH has write access to the RAID stack driver code

require 'fileutils'
require 'nokogiri'
require 'tempfile'

HEADER = '*' * 80
LINUX_MAKEFILE = 'Makefile'
PMOR_MAKEFILE = 'pmor/Makefile'
UEFI_INF = 'HamerPkg.inf'
PMOR_MAKEFILE_INC = 'pmor/Makefile.inc'
WINDOWS_DIRS = 'dirs'
WINDOWS_SOURCES = 'sources'
HAMER_DRIVER_REPO = 'https://archer.cce.hp.com/svn/drivers/hpdsa/trunk'
RAID_STACK_WRITE_USER = 'BuilderH'
SVN_OPTIONS = '--non-interactive'
SOURCES_REGEX = /\[\W*Sources\W*\]/i # Regex for [Sources] section header in .ini file

class String
  def strip_heredoc
    indent = scan(/^[ \t]*(?=\S)/).min_by(&:size).size || 0
    gsub(/^[ \t]{#{indent}}/, '')
  end
end

class IO
  def self.writelines(filename, lines)
    File.open(filename, 'w') do |file|
      lines.each { |line| file.puts line }
    end
  end
end

def debug?(argv = ARGV)
  argv.include?('--debug') || argv.include?('-d')
end

def dry_run?(argv = ARGV)
  argv.include?('--dry-run') || argv.include?('-n')
end

def help?(argv = ARGV)
  argv.include?('--help') || argv.include?('-?')
end

def get_argument(name, argv=ARGV)
  i = argv.find_index { |arg| arg.match(/--#{name}/) }
  i.nil? ? nil : argv[i].split('=')[1]
end

def deep_copy(object)
  Marshal.load(Marshal.dump(object))
end

def tmp_prefix
  "/tmp/#{File.basename($PROGRAM_NAME)}"
end

def file_not_found(filename)
  $stderr.puts "#{filename} not found"
  false
end

def print_update_status(filename, unchanged)
  if unchanged
    puts "Did not update #{File.join(Dir.pwd, filename)}" if debug?
    false
  else
    puts "Updated #{File.join(Dir.pwd, filename)}" if debug?
    true
  end
end

def update_file(filename)
  puts "Processing #{filename}" if debug?
  return file_not_found(filename) unless File.exists?(filename)

  lines = IO.readlines(filename).each(&:chomp!)
  original_lines = deep_copy(lines)
  yield lines
  IO.writelines(filename, lines) if lines != original_lines

  print_update_status(filename, lines == original_lines)
end

def add_line(lines, text, regex, prefix)
  line_number = lines.index(lines.find_all { |line| line =~ prefix }.last)
  return $stderr.puts "Could not find #{prefix}" if line_number.nil?
  puts "Adding #{text}" if debug?
  lines.insert(line_number + 1, text) unless lines.any? { |s| s.match(regex) }
end

def remove_line(lines, regex)
  puts "Removing #{regex}" if debug?
  if regex[0] == "\t"
    regex = /\W*#{regex[1..-1]}/    # For UEFI INF
  else
    regex = Regexp.escape(regex)    # for Makefile
  end
  lines.delete_if { |s| s.match(regex) }
end

def change_line(lines, change, text, prefix)
  regex = text[-1] == '\\' ? text[1..-2] : text
  if change[:action] == 'A'
    add_line(lines, text, regex, prefix)
  elsif change[:action] == 'D'
    remove_line(lines, regex)
  end
end

# In the file specified by 'filename', search for lines which contain 'text',
# and change them as indicated by 'changes'. If changes[:action] == 'D', the
# line is deleted. If changes[:action] == 'A', a line is added after the last
# line which matches 'prefix'. The new line is composed of the 'text' followed
# by 'change[:name]'.
def replace_text(filename, changes, text, prefix)
  update_file(filename) do |lines|
    next if lines.nil?
    changes.each { |change| change_line(lines, change, "#{text}#{change[:name]}", prefix) }
  end
end

def replace_files(name, changes, text, prefix)
  changed = false
  changes.each do |change|
    *path, dir = change[:name].split('/')
    filename = File.join(path, name)
    changed |= update_file(filename) do |lines|
      lines = text if lines.nil?
      change_line(lines, change, "       #{dir} \\", prefix)
    end
  end
  changed
end

def make_object_filename(filename)
  filename.sub(/\.[^.]*$/, '.o')
end

def svn_checkout(repo, directory)
  cmd = "svn checkout #{SVN_OPTIONS} --ignore-externals --depth=files"
  version = get_argument('driver')
  cmd += " --revision #{version} " unless version.nil?
  cmd += " #{repo} #{directory}"
  puts cmd if debug?
  status = `#{cmd}`
  fail status if $?.exitstatus != 0 unless $?.nil?
end

def tmpname(prefix)
  file = Tempfile.new(prefix)
  name = file.path()
  file.close!
  name
end

def create_logfile
  log = <<-EOS.strip_heredoc.split("\n")
        Update build scripts for Linux, Windows, and PMOR drivers

        This automated change was made by update-build-scripts.

        [NOTRACKER]
        review:none
        EOS
  logfile = tmpname(tmp_prefix)
  IO.writelines(logfile, log)
  logfile
end

def svn_checkin(message, directory, user=nil)
  logfile = create_logfile
  user = "--username #{user}" unless user.nil?
  cmd = "svn commit #{SVN_OPTIONS} -F #{logfile} #{user} #{directory}"
  puts cmd if dry_run? || debug?
  if dry_run?
    puts "Updated #{message} files available in: #{directory}"
  else
    status = `#{cmd}`
    fail status if $?.exitstatus != 0 unless $?.nil?
  end
ensure
  FileUtils.rm_f logfile unless dry_run?
end

class Update
  def initialize
    @changed = false
    @error = false

    @files = get_affected_files
    return if @files.nil?

    @c_files = @files.select { |file| file[:name] =~ /\.c$/ }
    @o_files = deep_copy(@c_files)
    @o_files.each { |file| file[:name] = make_object_filename(file[:name]) }
    @inf_dirs = get_inf_dirs
    @inf_files = @c_files.select { |file| @inf_dirs.include?(File.dirname(file[:name])) }
    @dirs = @files.reject { |file| file[:name] =~ /\.(c|h)/ }
  end

  def dump_files
    $stderr.puts HEADER, 'Files:', @files
    $stderr.puts HEADER, '.c files:', @c_files
    $stderr.puts HEADER, 'INF files:', @inf_files
    $stderr.puts HEADER, '.o files:', @o_files
    $stderr.puts HEADER, 'dirs:', @dirs
  end

  def get_affected_files
    xml = `svn log --verbose --xml --limit 1`
    doc = Nokogiri::Slop(xml)
    files = []
    doc.css('log logentry paths path').each do |path|
      if path['action'] =~ /[AD]/
        files << { :action => path['action'], :name => path.content }
      end
    end
    files.each { |file| file[:name][%r{/trunk/src/}] = '' }
  end

  def get_inf_dirs
    return [] unless File.exists?(UEFI_INF)
    files = []
    File.open(UEFI_INF).each_line do |line|
      line.strip!
      files << File.dirname(line) if line.match(SOURCES_REGEX)...line.match(/\[.*\]/)
    end
    files.delete_if { |file| file.empty? || file[0] == '#' }
    files.uniq
  end

  def linux_driver
    directory = Dir.mktmpdir(tmp_prefix)
    svn_checkout(HAMER_DRIVER_REPO, directory)
    Dir.chdir(directory)
    changed =
      replace_text(LINUX_MAKEFILE, @dirs, 'EXTRA_CFLAGS += -I$(INC_PATH)/', /^EXTRA_CFLAGS \+= -I/) |
      replace_text(LINUX_MAKEFILE, @o_files, 'lib-m += $(RS_SRC_PATH)/', /^lib-m /)
    svn_checkin("Linux driver", directory) if changed
  rescue => e
    $stderr.puts e
    @error = true
  ensure
    FileUtils.rm_rf(directory) unless (dry_run? or directory.nil?)
  end

  def raid_stack
    @dirs.select! { |dir| File.directory?(dir[:name]) || dir[:action] == 'D' }
    @changed =
      replace_text(PMOR_MAKEFILE_INC, @dirs, 'INCLUDE_PATHS += -I$(HPSA_PATH)/', /^INCLUDE_PATHS /) |
      replace_text(PMOR_MAKEFILE, @o_files, 'rslib-objs += ../', /^rslib-objs /) |
      replace_text(UEFI_INF, @inf_files, "\t", SOURCES_REGEX) |
      replace_files(WINDOWS_DIRS, @dirs, 'DIRS= \\', /^\s*DIRS\s*=\s*\\/i) |
      replace_files(WINDOWS_SOURCES, @c_files, 'SOURCES= \\', /^\s*SOURCES\s*=\s*\\/i)
    svn_checkin("RAID stack", Dir.pwd, RAID_STACK_WRITE_USER) if @changed
  end

  def raid_stack_unchanged?
    !@changed && !@error
  end
end

def usage
  puts "usage: #{File.basename($PROGRAM_NAME, '.rb')}" \
       " [--debug|-d]" \
       " [--driver=#]" \
       " [--dry-run|-n]" \
       " [--help|-?]"
  exit 0
end

def main
  usage if help?
  update = Update.new
  update.dump_files if debug?
  update.raid_stack
  update.linux_driver
  update.raid_stack_unchanged?
rescue => exception
  puts exception, exception.backtrace.join("\n") if debug?
  false
end

main if __FILE__ == $PROGRAM_NAME
